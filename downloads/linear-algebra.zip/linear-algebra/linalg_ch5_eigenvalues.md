---
title: "Eigenvalues and Eigenvectors"
crumb: "Linear Algebra · Chapter 5"
meta:
  - "Est. study time: ~5–7 hours"
  - "MA 3113 · Mississippi State University"
  - "Lay §5.1–§5.3, §5.5, §5.7, §5.9"
source: "markdown"
---

## Overview

This is a no-calculator, written-work chapter: build every characteristic polynomial by hand, row-reduce every eigenspace, and justify each verdict. The idea begins with a simple question: are there special vectors that a matrix transformation stretches or shrinks — but does not rotate? These are **eigenvectors**, and the stretch factors are **eigenvalues**. They are the most computationally powerful concept in linear algebra, underlying everything from Google's PageRank to the vibration modes of a bridge to the long-run behavior of a Markov chain.

Sections covered: §5.1 (definition and finding eigenspaces), §5.2 (the characteristic equation), §5.3 (diagonalization), §5.5 (complex eigenvalues), §5.7 (first-order linear differential equations), §5.9 (Markov chains and steady-state).

:::callout-key[Prerequisites]
Determinants (Chapter 3) are essential — the characteristic polynomial is a determinant. Review §3.1–3.3 and the Invertible Matrix Theorem (§2.3).
:::


:::callout-tip[On a written exam]
Always show the chain: $A-\lambda I$; determinant expansion and factorization; eigenvalues (including multiplicity); RREF; pivot and free variables; eigenspace basis; conclusion. Write $AP=PD$ to check diagonalization without computing an inverse unless the question demands it.
:::

## 5.1 Eigenvectors and Eigenvalues


:::callout-intuition[Intuition]
When you apply most matrices to a vector, you get something pointing in a completely different direction. But some special vectors — eigenvectors — only get scaled: $A\mathbf{x}=\lambda\mathbf{x}$. The scalar $\lambda$ (the eigenvalue) tells you how much the stretching or shrinking occurs. Eigenvectors reveal the "natural axes" of a linear transformation.
:::

:::callout-connect[Back to Chapter 4: null spaces and the IMT]
Subtract $\lambda\mathbf{x}$ from $A\mathbf{x}=\lambda\mathbf{x}$. Because $\lambda\mathbf{x}=(\lambda I)\mathbf{x}$, you get $(A-\lambda I)\mathbf{x}=\mathbf{0}$. That is a homogeneous system, not a new kind of algebra. The eigenspace is exactly $\Nul(A-\lambda I)$, so the free variables control its dimension. By the Invertible Matrix Theorem, $0$ is an eigenvalue precisely when $A\mathbf{x}=\mathbf{0}$ has a nonzero solution, which is precisely when $A$ is singular.
:::

<figure class="fig">
<svg class="fig-hue-1" viewBox="0 0 440 240" role="img" aria-label="An upper triangular matrix stretches the horizontal eigenvector and turns a vertical vector.">
<line class="fig-axis" x1="87.0" y1="145.0" x2="340.0" y2="145.0"/><line class="fig-axis" x1="110.0" y1="168.0" x2="110.0" y2="30.0"/><line class="fig-curve" x1="110.0" y1="145.0" x2="156.0" y2="145.0"/><path class="fig-arrow" d="M147.0 141.0 L156.0 145.0 L147.0 149.0"/><line class="fig-curve-alt" x1="110.0" y1="145.0" x2="202.0" y2="145.0"/><path class="fig-arrow" d="M193.0 141.0 L202.0 145.0 L193.0 149.0"/><line class="fig-curve" x1="110.0" y1="145.0" x2="110.0" y2="99.0"/><path class="fig-arrow" d="M106.0 108.0 L110.0 99.0 L114.0 108.0"/><line class="fig-curve-alt" x1="110.0" y1="145.0" x2="156.0" y2="99.0"/><path class="fig-arrow" d="M146.8 102.5 L156.0 99.0 L152.5 108.2"/><text class="fig-label" x="156.0" y="154.2">e1</text><text class="fig-label" x="202.0" y="155.6">Ae1 = 2e1</text><text class="fig-label" x="98.5" y="89.8">e2</text><text class="fig-label" x="160.6" y="89.8">Ae2</text>
</svg>
<figcaption>For $A=\begin{bmatrix}2&1\\0&1\end{bmatrix}$, $A(1,0)^T=(2,0)^T$ stays on the same line, but $A(0,1)^T=(1,1)^T$ turns. Only the first displayed direction is an eigen-direction.</figcaption>
</figure>

:::callout-tip[The three questions are different]
To test a **given vector** $\mathbf{v}$, compute $A\mathbf{v}$ and see whether every coordinate uses the same multiplier. To test a **given number** $c$, row-reduce $A-cI$ and look for a free variable. To find **all eigenvalues**, use $\det(A-\lambda I)=0$.
:::

:::definition[Definition 5.1 — Eigenvalue and Eigenvector]
Let $A$ be an $n\times n$ matrix. A scalar $\lambda$ is an **eigenvalue** of $A$ if there exists a *nonzero* vector $\mathbf{x}\in\R^n$ such that

$$
A\mathbf{x} = \lambda\mathbf{x}
$$

Such a nonzero vector $\mathbf{x}$ is called an **eigenvector** of $A$ corresponding to $\lambda$.

*Note: $\mathbf{x}=\mathbf{0}$ is never an eigenvector (by definition), even though $A\mathbf{0}=\lambda\mathbf{0}$ trivially.*
:::

:::callout-key[Rewriting the Eigenvector Equation]
$A\mathbf{x}=\lambda\mathbf{x}$ iff $(A-\lambda I)\mathbf{x}=\mathbf{0}$. So $\lambda$ is an eigenvalue iff $A-\lambda I$ is *not invertible*, i.e., $\det(A-\lambda I)=0$.
:::

:::definition[Definition 5.2 — Eigenspace]
The **eigenspace** of $A$ corresponding to $\lambda$ is

$$
E_\lambda = \Nul(A-\lambda I) = \{\mathbf{x}: (A-\lambda I)\mathbf{x}=\mathbf{0}\}
$$

It is a subspace of $\R^n$ containing all eigenvectors for $\lambda$ together with $\mathbf{0}$.
:::

<figure class="fig">
<svg class="fig-hue-2" viewBox="0 0 440 240" role="img" aria-label="Two eigenvector subspaces are perpendicular lines through the origin.">
<line class="fig-axis" x1="72.0" y1="116.0" x2="348.0" y2="116.0"/><line class="fig-axis" x1="210.0" y1="208.0" x2="210.0" y2="24.0"/><line class="fig-curve" x1="81.2" y1="116.0" x2="338.8" y2="116.0"/><line class="fig-curve-alt" x1="210.0" y1="208.0" x2="210.0" y2="24.0"/><line class="fig-curve" x1="210.0" y1="116.0" x2="302.0" y2="116.0"/><path class="fig-arrow" d="M293.0 112.0 L302.0 116.0 L293.0 120.0"/><line class="fig-curve-alt" x1="210.0" y1="116.0" x2="210.0" y2="47.0"/><path class="fig-arrow" d="M206.0 56.0 L210.0 47.0 L214.0 56.0"/><text class="fig-label" x="302.0" y="97.6">E2</text><text class="fig-label" x="219.2" y="42.4">E3</text>
</svg>
<figcaption>For $A=\operatorname{diag}(2,3)$, $E_2=\operatorname{span}\{(1,0)^T\}$ and $E_3=\operatorname{span}\{(0,1)^T\}$. Each eigenspace is a whole line through the origin, including zero.</figcaption>
</figure>

:::example[Example 5.1 — Verifying an Eigenvalue/Eigenvector Pair]
Is $\lambda=7$ an eigenvalue of $A=\begin{bmatrix}1&6\\5&2\end{bmatrix}$? If so, find an eigenvector.

::::answer[Answer]
**Answer:** Yes, $\lambda=7$; one eigenvector is $(1,1)^T$.

1. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

2. Form $A-\lambda I=\begin{bmatrix}1 - \lambda&6\\5&2 - \lambda\end{bmatrix}$.

3. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=(1-\lambda)(2-\lambda)-(6)(5)
   $$

4. Expand, simplify, and factor the preceding expression.

   $$
   =\lambda^{2} - 3 \lambda - 28=\left(\lambda - 7\right) \left(\lambda + 4\right).
   $$

5. Eigenspace for $\lambda=7$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

6. Row-reduce the homogeneous system: start with $A-(7)I=\begin{bmatrix}-6&6\\5&-5\end{bmatrix}$.

7. Multiply row 1 by $- \frac{1}{6}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (- \frac{1}{6})R_{1}}\begin{bmatrix}1&-1\\5&-5\end{bmatrix}
   $$

8. Replace row 2 by itself plus $-5$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (-5)R_{1}}\begin{bmatrix}1&-1\\0&0\end{bmatrix}
   $$

9. The pivot columns are 1; the free variable is $x_2$.

10. The pivot equations give $x_1=x_{2}$.

11. Choose one free variable at a time and set the others to zero.

12. Clear fractions where necessary.

13. The resulting basis is $\left\{\begin{bmatrix}1\\1\end{bmatrix}\right\}$.

14. Hence $\dim E_{7}=1$.

15. The roots of the factored polynomial are $\lambda=7$ (algebraic multiplicity 1), $\lambda=-4$ (algebraic multiplicity 1).

16. Check: $A\begin{bmatrix}1\\1\end{bmatrix}=\begin{bmatrix}7\\7\end{bmatrix}=7\begin{bmatrix}1\\1\end{bmatrix}$.
::::

:::


### Worked examples: Finding All Eigenspaces for a $3\times 3$ Matrix

:::example[Example 5.2 — Finding All Eigenspaces for a $3\times 3$ Matrix]
Given $\lambda=2$ is an eigenvalue of $A=\begin{bmatrix}4&0&1\\-2&1&0\\-2&0&1\end{bmatrix}$, find a basis for $E_2$.

::::answer[Answer]
**Answer:** $E_2=\span\{(-1,2,2)^T\}$, so its dimension is one.

1. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

2. Form $A-\lambda I=\begin{bmatrix}4 - \lambda&0&1\\-2&1 - \lambda&0\\-2&0&1 - \lambda\end{bmatrix}$.

3. Expand along column 2, which has the most zeros (ties favor columns).

4. The cofactor signs alternate $+,-,+$ across the first row.

5. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=(1 - \lambda)\left[(4 - \lambda)(1 - \lambda)-(1)(-2)\right]
   $$

6. Expand, simplify, and factor the preceding expression.

   $$
   =- \lambda^{3} + 6 \lambda^{2} - 11 \lambda + 6=- \left(\lambda - 3\right) \left(\lambda - 2\right) \left(\lambda - 1\right).
   $$

7. Eigenspace for $\lambda=2$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

8. Row-reduce the homogeneous system: start with $A-(2)I=\begin{bmatrix}2&0&1\\-2&-1&0\\-2&0&-1\end{bmatrix}$.

9. Multiply row 1 by $\frac{1}{2}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (\frac{1}{2})R_{1}}\begin{bmatrix}1&0&\frac{1}{2}\\-2&-1&0\\-2&0&-1\end{bmatrix}
   $$

10. Replace row 2 by itself plus $2$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (2)R_{1}}\begin{bmatrix}1&0&\frac{1}{2}\\0&-1&1\\-2&0&-1\end{bmatrix}
   $$

11. Replace row 3 by itself plus $2$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{3}\leftarrow R_{3} + (2)R_{1}}\begin{bmatrix}1&0&\frac{1}{2}\\0&-1&1\\0&0&0\end{bmatrix}
   $$

12. Multiply row 2 by $-1$ to normalize its leading entry.

   $$
   \xrightarrow{R_{2}\leftarrow (-1)R_{2}}\begin{bmatrix}1&0&\frac{1}{2}\\0&1&-1\\0&0&0\end{bmatrix}
   $$

13. The pivot columns are 1, 2; the free variable is $x_3$.

14. The pivot equations give $x_1=- \frac{x_{3}}{2}$, $x_2=x_{3}$.

15. Choose one free variable at a time and set the others to zero.

16. Clear fractions where necessary.

17. The resulting basis is $\left\{\begin{bmatrix}-1\\2\\2\end{bmatrix}\right\}$.

18. Hence $\dim E_{2}=1$.

19. The roots of the factored polynomial are $\lambda=3$ (algebraic multiplicity 1), $\lambda=2$ (algebraic multiplicity 1), $\lambda=1$ (algebraic multiplicity 1).

20. Check: $A\begin{bmatrix}-1\\2\\2\end{bmatrix}=\begin{bmatrix}-2\\4\\4\end{bmatrix}=2\begin{bmatrix}-1\\2\\2\end{bmatrix}$.
::::

:::

:::theorem[Theorem 5.1 — Eigenvalues of Triangular Matrices]
The eigenvalues of a triangular matrix (upper or lower) are the entries on the main diagonal.
:::

:::theorem[Theorem 5.2 — Eigenvectors from Distinct Eigenvalues are Independent]
If $\mathbf{v}_1,\ldots,\mathbf{v}_r$ are eigenvectors corresponding to *distinct* eigenvalues $\lambda_1,\ldots,\lambda_r$ of $A$, then $\{\mathbf{v}_1,\ldots,\mathbf{v}_r\}$ is linearly independent.
:::


:::example[Example 5.3 — All eigenspaces of a simple two by two]
For $A=\begin{bmatrix}2&1\\1&2\end{bmatrix}$, find **both** eigenspaces, not only the eigenvalues.

::::answer[Answer]
**Answer:** Eigenvalues $1$, $3$.  Eigenspace bases: $E_{1}=\span\left\{\begin{bmatrix}-1\\1\end{bmatrix}\right\}$, $E_{3}=\span\left\{\begin{bmatrix}1\\1\end{bmatrix}\right\}$.

1. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

2. Form $A-\lambda I=\begin{bmatrix}2 - \lambda&1\\1&2 - \lambda\end{bmatrix}$.

3. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=(2-\lambda)(2-\lambda)-(1)(1)
   $$

4. Expand, simplify, and factor the preceding expression.

   $$
   =\lambda^{2} - 4 \lambda + 3=\left(\lambda - 3\right) \left(\lambda - 1\right).
   $$

5. Eigenspace for $\lambda=1$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

6. Row-reduce the homogeneous system: start with $A-(1)I=\begin{bmatrix}1&1\\1&1\end{bmatrix}$.

7. Replace row 2 by itself plus $-1$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (-1)R_{1}}\begin{bmatrix}1&1\\0&0\end{bmatrix}
   $$

8. The pivot columns are 1; the free variable is $x_2$.

9. The pivot equations give $x_1=- x_{2}$.

10. Choose one free variable at a time and set the others to zero.

11. Clear fractions where necessary.

12. The resulting basis is $\left\{\begin{bmatrix}-1\\1\end{bmatrix}\right\}$.

13. Hence $\dim E_{1}=1$.

14. Eigenspace for $\lambda=3$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

15. Row-reduce the homogeneous system: start with $A-(3)I=\begin{bmatrix}-1&1\\1&-1\end{bmatrix}$.

16. Multiply row 1 by $-1$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (-1)R_{1}}\begin{bmatrix}1&-1\\1&-1\end{bmatrix}
   $$

17. Replace row 2 by itself plus $-1$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (-1)R_{1}}\begin{bmatrix}1&-1\\0&0\end{bmatrix}
   $$

18. The pivot columns are 1; the free variable is $x_2$.

19. The pivot equations give $x_1=x_{2}$.

20. Choose one free variable at a time and set the others to zero.

21. Clear fractions where necessary.

22. The resulting basis is $\left\{\begin{bmatrix}1\\1\end{bmatrix}\right\}$.

23. Hence $\dim E_{3}=1$.

24. The roots of the factored polynomial are $\lambda=3$ (algebraic multiplicity 1), $\lambda=1$ (algebraic multiplicity 1).

25. Check: $A\begin{bmatrix}-1\\1\end{bmatrix}=\begin{bmatrix}-1\\1\end{bmatrix}=1\begin{bmatrix}-1\\1\end{bmatrix}$.

26. Check: $A\begin{bmatrix}1\\1\end{bmatrix}=\begin{bmatrix}3\\3\end{bmatrix}=3\begin{bmatrix}1\\1\end{bmatrix}$.
::::

:::


### Worked examples: A zero eigenvalue is allowed

:::example[Example 5.4 — A zero eigenvalue is allowed]
For $A=\begin{bmatrix}1&2\\2&4\end{bmatrix}$, show why 0 is an eigenvalue and find all eigenspace bases.

::::answer[Answer]
**Answer:** Eigenvalues $0$, $5$.  Eigenspace bases: $E_{0}=\span\left\{\begin{bmatrix}-2\\1\end{bmatrix}\right\}$, $E_{5}=\span\left\{\begin{bmatrix}1\\2\end{bmatrix}\right\}$.

1. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

2. Form $A-\lambda I=\begin{bmatrix}1 - \lambda&2\\2&4 - \lambda\end{bmatrix}$.

3. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=(1-\lambda)(4-\lambda)-(2)(2)
   $$

4. Expand, simplify, and factor the preceding expression.

   $$
   =\lambda \left(\lambda - 5\right)=\lambda \left(\lambda - 5\right).
   $$

5. Eigenspace for $\lambda=0$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

6. Row-reduce the homogeneous system: start with $A-(0)I=\begin{bmatrix}1&2\\2&4\end{bmatrix}$.

7. Replace row 2 by itself plus $-2$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (-2)R_{1}}\begin{bmatrix}1&2\\0&0\end{bmatrix}
   $$

8. The pivot columns are 1; the free variable is $x_2$.

9. The pivot equations give $x_1=- 2 x_{2}$.

10. Choose one free variable at a time and set the others to zero.

11. Clear fractions where necessary.

12. The resulting basis is $\left\{\begin{bmatrix}-2\\1\end{bmatrix}\right\}$.

13. Hence $\dim E_{0}=1$.

14. Eigenspace for $\lambda=5$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

15. Row-reduce the homogeneous system: start with $A-(5)I=\begin{bmatrix}-4&2\\2&-1\end{bmatrix}$.

16. Multiply row 1 by $- \frac{1}{4}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (- \frac{1}{4})R_{1}}\begin{bmatrix}1&- \frac{1}{2}\\2&-1\end{bmatrix}
   $$

17. Replace row 2 by itself plus $-2$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (-2)R_{1}}\begin{bmatrix}1&- \frac{1}{2}\\0&0\end{bmatrix}
   $$

18. The pivot columns are 1; the free variable is $x_2$.

19. The pivot equations give $x_1=\frac{x_{2}}{2}$.

20. Choose one free variable at a time and set the others to zero.

21. Clear fractions where necessary.

22. The resulting basis is $\left\{\begin{bmatrix}1\\2\end{bmatrix}\right\}$.

23. Hence $\dim E_{5}=1$.

24. The roots of the factored polynomial are $\lambda=5$ (algebraic multiplicity 1), $\lambda=0$ (algebraic multiplicity 1).

25. Check: $A\begin{bmatrix}-2\\1\end{bmatrix}=\begin{bmatrix}0\\0\end{bmatrix}=0\begin{bmatrix}-2\\1\end{bmatrix}$.

26. Check: $A\begin{bmatrix}1\\2\end{bmatrix}=\begin{bmatrix}5\\10\end{bmatrix}=5\begin{bmatrix}1\\2\end{bmatrix}$.
::::

:::

:::callout-pitfall[Pitfalls in §5.1]
(1) Calling the zero vector an eigenvector; it never is. (2) Testing a proposed eigenvalue by dividing coordinate ratios, which fails if a coordinate is zero; instead solve $(A-\lambda I)\mathbf{x}=0$. (3) Giving only one vector when the eigenspace has two free variables.
:::

:::problem[Problem 5.1 — Diagonal-matrix eigenvalues]{difficulty=easy}
Find the eigenvalues of $A=\begin{bmatrix}3&0&0\\0&-1&0\\0&0&5\end{bmatrix}$.

::::solution[Solution]
**Answer:** The eigenvalues are $3$, $-1$, and $5$.

1. $A$ is diagonal (hence triangular).

2. Eigenvalues are the diagonal entries: $\lambda_1=3,\;\lambda_2=-1,\;\lambda_3=5$.

3. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

4. Form $A-\lambda I=\begin{bmatrix}3 - \lambda&0&0\\0&- \lambda - 1&0\\0&0&5 - \lambda\end{bmatrix}$.

5. The matrix is triangular, so multiply its three diagonal entries after subtracting $\lambda$:

6. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=- \left(\lambda - 5\right) \left(\lambda - 3\right) \left(\lambda + 1\right)=- \lambda^{3} + 7 \lambda^{2} - 7 \lambda - 15.
   $$

7. Eigenspace for $\lambda=-1$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

8. Row-reduce the homogeneous system: start with $A-(-1)I=\begin{bmatrix}4&0&0\\0&0&0\\0&0&6\end{bmatrix}$.

9. Multiply row 1 by $\frac{1}{4}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (\frac{1}{4})R_{1}}\begin{bmatrix}1&0&0\\0&0&0\\0&0&6\end{bmatrix}
   $$

10. Swap rows 2 and 3 to place a nonzero pivot or reorder the equations.

   $$
   \xrightarrow{R_{2}\leftrightarrow R_{3}}\begin{bmatrix}1&0&0\\0&0&6\\0&0&0\end{bmatrix}
   $$

11. Multiply row 2 by $\frac{1}{6}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{2}\leftarrow (\frac{1}{6})R_{2}}\begin{bmatrix}1&0&0\\0&0&1\\0&0&0\end{bmatrix}
   $$

12. The pivot columns are 1, 3; the free variable is $x_2$.

13. The pivot equations give $x_1=0$, $x_3=0$.

14. Choose one free variable at a time and set the others to zero.

15. Clear fractions where necessary.

16. The resulting basis is $\left\{\begin{bmatrix}0\\1\\0\end{bmatrix}\right\}$.

17. Hence $\dim E_{-1}=1$.

18. Eigenspace for $\lambda=3$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

19. Row-reduce the homogeneous system: start with $A-(3)I=\begin{bmatrix}0&0&0\\0&-4&0\\0&0&2\end{bmatrix}$.

20. Swap rows 1 and 2 to place a nonzero pivot or reorder the equations.

   $$
   \xrightarrow{R_{1}\leftrightarrow R_{2}}\begin{bmatrix}0&-4&0\\0&0&0\\0&0&2\end{bmatrix}
   $$

21. Multiply row 1 by $- \frac{1}{4}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (- \frac{1}{4})R_{1}}\begin{bmatrix}0&1&0\\0&0&0\\0&0&2\end{bmatrix}
   $$

22. Swap rows 2 and 3 to place a nonzero pivot or reorder the equations.

   $$
   \xrightarrow{R_{2}\leftrightarrow R_{3}}\begin{bmatrix}0&1&0\\0&0&2\\0&0&0\end{bmatrix}
   $$

23. Multiply row 2 by $\frac{1}{2}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{2}\leftarrow (\frac{1}{2})R_{2}}\begin{bmatrix}0&1&0\\0&0&1\\0&0&0\end{bmatrix}
   $$

24. The pivot columns are 2, 3; the free variable is $x_1$.

25. The pivot equations give $x_2=0$, $x_3=0$.

26. Choose one free variable at a time and set the others to zero.

27. Clear fractions where necessary.

28. The resulting basis is $\left\{\begin{bmatrix}1\\0\\0\end{bmatrix}\right\}$.

29. Hence $\dim E_{3}=1$.

30. Eigenspace for $\lambda=5$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

31. Row-reduce the homogeneous system: start with $A-(5)I=\begin{bmatrix}-2&0&0\\0&-6&0\\0&0&0\end{bmatrix}$.

32. Multiply row 1 by $- \frac{1}{2}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (- \frac{1}{2})R_{1}}\begin{bmatrix}1&0&0\\0&-6&0\\0&0&0\end{bmatrix}
   $$

33. Multiply row 2 by $- \frac{1}{6}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{2}\leftarrow (- \frac{1}{6})R_{2}}\begin{bmatrix}1&0&0\\0&1&0\\0&0&0\end{bmatrix}
   $$

34. The pivot columns are 1, 2; the free variable is $x_3$.

35. The pivot equations give $x_1=0$, $x_2=0$.

36. Choose one free variable at a time and set the others to zero.

37. Clear fractions where necessary.

38. The resulting basis is $\left\{\begin{bmatrix}0\\0\\1\end{bmatrix}\right\}$.

39. Hence $\dim E_{5}=1$.

40. The roots of the factored polynomial are $\lambda=5$ (algebraic multiplicity 1), $\lambda=3$ (algebraic multiplicity 1), $\lambda=-1$ (algebraic multiplicity 1).

41. Check: $A\begin{bmatrix}0\\1\\0\end{bmatrix}=\begin{bmatrix}0\\-1\\0\end{bmatrix}=-1\begin{bmatrix}0\\1\\0\end{bmatrix}$.

42. Check: $A\begin{bmatrix}1\\0\\0\end{bmatrix}=\begin{bmatrix}3\\0\\0\end{bmatrix}=3\begin{bmatrix}1\\0\\0\end{bmatrix}$.

43. Check: $A\begin{bmatrix}0\\0\\1\end{bmatrix}=\begin{bmatrix}0\\0\\5\end{bmatrix}=5\begin{bmatrix}0\\0\\1\end{bmatrix}$.
::::

:::


### Practice problems: Testing an eigenvalue

:::problem[Problem 5.2 — Testing an eigenvalue]{difficulty=standard}
Determine if $\lambda=3$ is an eigenvalue of $B=\begin{bmatrix}1&2\\2&1\end{bmatrix}$, and if so, find a basis for the eigenspace.

::::solution[Solution]
**Answer:** Yes, $\lambda=3$; an eigenspace basis is $\{(1,1)^T\}$.

1. $B-3I=\begin{bmatrix}-2&2\\2&-2\end{bmatrix}\to\begin{bmatrix}1&-1\\0&0\end{bmatrix}$.

2. Free var $x_2$; set $x_2=1\Rightarrow x_1=1$.

3. Yes, $\lambda=3$ is an eigenvalue; basis: $\left\{\begin{bmatrix}1\\1\end{bmatrix}\right\}$.

4. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

5. Form $A-\lambda I=\begin{bmatrix}1 - \lambda&2\\2&1 - \lambda\end{bmatrix}$.

6. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=(1-\lambda)(1-\lambda)-(2)(2)
   $$

7. Expand, simplify, and factor the preceding expression.

   $$
   =\lambda^{2} - 2 \lambda - 3=\left(\lambda - 3\right) \left(\lambda + 1\right).
   $$

8. Eigenspace for $\lambda=3$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

9. Row-reduce the homogeneous system: start with $A-(3)I=\begin{bmatrix}-2&2\\2&-2\end{bmatrix}$.

10. Multiply row 1 by $- \frac{1}{2}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (- \frac{1}{2})R_{1}}\begin{bmatrix}1&-1\\2&-2\end{bmatrix}
   $$

11. Replace row 2 by itself plus $-2$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (-2)R_{1}}\begin{bmatrix}1&-1\\0&0\end{bmatrix}
   $$

12. The pivot columns are 1; the free variable is $x_2$.

13. The pivot equations give $x_1=x_{2}$.

14. Choose one free variable at a time and set the others to zero.

15. Clear fractions where necessary.

16. The resulting basis is $\left\{\begin{bmatrix}1\\1\end{bmatrix}\right\}$.

17. Hence $\dim E_{3}=1$.

18. The roots of the factored polynomial are $\lambda=3$ (algebraic multiplicity 1), $\lambda=-1$ (algebraic multiplicity 1).

19. Check: $A\begin{bmatrix}1\\1\end{bmatrix}=\begin{bmatrix}3\\3\end{bmatrix}=3\begin{bmatrix}1\\1\end{bmatrix}$.
::::

:::

:::problem[Problem 5.3 — All eigenvectors for one eigenvalue]{difficulty=standard}
Find all eigenvectors of $A=\begin{bmatrix}0&1\\-2&3\end{bmatrix}$ corresponding to $\lambda=1$.

::::solution[Solution]
**Answer:** All eigenvectors are $t(1,1)^T$ for $t\ne0$.

1. $A-I=\begin{bmatrix}-1&1\\-2&2\end{bmatrix}\to\begin{bmatrix}1&-1\\0&0\end{bmatrix}$.

2. Solution: $x_1=x_2$.

3. All eigenvectors: $t\begin{bmatrix}1\\1\end{bmatrix}$ for $t\ne 0$.

4. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

5. Form $A-\lambda I=\begin{bmatrix}- \lambda&1\\-2&3 - \lambda\end{bmatrix}$.

6. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=(0-\lambda)(3-\lambda)-(1)(-2)
   $$

7. Expand, simplify, and factor the preceding expression.

   $$
   =\lambda^{2} - 3 \lambda + 2=\left(\lambda - 2\right) \left(\lambda - 1\right).
   $$

8. Eigenspace for $\lambda=1$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

9. Row-reduce the homogeneous system: start with $A-(1)I=\begin{bmatrix}-1&1\\-2&2\end{bmatrix}$.

10. Multiply row 1 by $-1$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (-1)R_{1}}\begin{bmatrix}1&-1\\-2&2\end{bmatrix}
   $$

11. Replace row 2 by itself plus $2$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (2)R_{1}}\begin{bmatrix}1&-1\\0&0\end{bmatrix}
   $$

12. The pivot columns are 1; the free variable is $x_2$.

13. The pivot equations give $x_1=x_{2}$.

14. Choose one free variable at a time and set the others to zero.

15. Clear fractions where necessary.

16. The resulting basis is $\left\{\begin{bmatrix}1\\1\end{bmatrix}\right\}$.

17. Hence $\dim E_{1}=1$.

18. The roots of the factored polynomial are $\lambda=2$ (algebraic multiplicity 1), $\lambda=1$ (algebraic multiplicity 1).

19. Check: $A\begin{bmatrix}1\\1\end{bmatrix}=\begin{bmatrix}1\\1\end{bmatrix}=1\begin{bmatrix}1\\1\end{bmatrix}$.
::::

:::

:::problem[Problem 5.4 — Diagonal eigenspace bases]{difficulty=easy}
For $A=\begin{bmatrix}2&0\\0&5\end{bmatrix}$, find the eigenvalues and an eigenspace basis for each.

::::solution[Solution]
**Answer:** Eigenvalues $2$, $5$.  Eigenspace bases: $E_{2}=\span\left\{\begin{bmatrix}1\\0\end{bmatrix}\right\}$, $E_{5}=\span\left\{\begin{bmatrix}0\\1\end{bmatrix}\right\}$.

1. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

2. Form $A-\lambda I=\begin{bmatrix}2 - \lambda&0\\0&5 - \lambda\end{bmatrix}$.

3. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=(2-\lambda)(5-\lambda)-(0)(0)
   $$

4. Expand, simplify, and factor the preceding expression.

   $$
   =\lambda^{2} - 7 \lambda + 10=\left(\lambda - 5\right) \left(\lambda - 2\right).
   $$

5. Eigenspace for $\lambda=2$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

6. Row-reduce the homogeneous system: start with $A-(2)I=\begin{bmatrix}0&0\\0&3\end{bmatrix}$.

7. Swap rows 1 and 2 to place a nonzero pivot or reorder the equations.

   $$
   \xrightarrow{R_{1}\leftrightarrow R_{2}}\begin{bmatrix}0&3\\0&0\end{bmatrix}
   $$

8. Multiply row 1 by $\frac{1}{3}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (\frac{1}{3})R_{1}}\begin{bmatrix}0&1\\0&0\end{bmatrix}
   $$

9. The pivot columns are 2; the free variable is $x_1$.

10. The pivot equations give $x_2=0$.

11. Choose one free variable at a time and set the others to zero.

12. Clear fractions where necessary.

13. The resulting basis is $\left\{\begin{bmatrix}1\\0\end{bmatrix}\right\}$.

14. Hence $\dim E_{2}=1$.

15. Eigenspace for $\lambda=5$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

16. Row-reduce the homogeneous system: start with $A-(5)I=\begin{bmatrix}-3&0\\0&0\end{bmatrix}$.

17. Multiply row 1 by $- \frac{1}{3}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (- \frac{1}{3})R_{1}}\begin{bmatrix}1&0\\0&0\end{bmatrix}
   $$

18. The pivot columns are 1; the free variable is $x_2$.

19. The pivot equations give $x_1=0$.

20. Choose one free variable at a time and set the others to zero.

21. Clear fractions where necessary.

22. The resulting basis is $\left\{\begin{bmatrix}0\\1\end{bmatrix}\right\}$.

23. Hence $\dim E_{5}=1$.

24. The roots of the factored polynomial are $\lambda=5$ (algebraic multiplicity 1), $\lambda=2$ (algebraic multiplicity 1).

25. Check: $A\begin{bmatrix}1\\0\end{bmatrix}=\begin{bmatrix}2\\0\end{bmatrix}=2\begin{bmatrix}1\\0\end{bmatrix}$.

26. Check: $A\begin{bmatrix}0\\1\end{bmatrix}=\begin{bmatrix}0\\5\end{bmatrix}=5\begin{bmatrix}0\\1\end{bmatrix}$.
::::

:::


### Practice problems: Zero eigenvalue and singularity

:::problem[Problem 5.5 — Zero eigenvalue and singularity]{difficulty=easy}
For $A=\begin{bmatrix}1&0\\0&0\end{bmatrix}$, decide whether 0 is an eigenvalue and justify using the IMT.

::::solution[Solution]
**Answer:** Eigenvalues $0$, $1$.  Eigenspace bases: $E_{0}=\span\left\{\begin{bmatrix}0\\1\end{bmatrix}\right\}$, $E_{1}=\span\left\{\begin{bmatrix}1\\0\end{bmatrix}\right\}$.

1. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

2. Form $A-\lambda I=\begin{bmatrix}1 - \lambda&0\\0&- \lambda\end{bmatrix}$.

3. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=(1-\lambda)(0-\lambda)-(0)(0)
   $$

4. Expand, simplify, and factor the preceding expression.

   $$
   =\lambda \left(\lambda - 1\right)=\lambda \left(\lambda - 1\right).
   $$

5. Eigenspace for $\lambda=0$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

6. Row-reduce the homogeneous system: start with $A-(0)I=\begin{bmatrix}1&0\\0&0\end{bmatrix}$.

7. No row operation is needed; the matrix is already in reduced row-echelon form.

8. The pivot columns are 1; the free variable is $x_2$.

9. The pivot equations give $x_1=0$.

10. Choose one free variable at a time and set the others to zero.

11. Clear fractions where necessary.

12. The resulting basis is $\left\{\begin{bmatrix}0\\1\end{bmatrix}\right\}$.

13. Hence $\dim E_{0}=1$.

14. Eigenspace for $\lambda=1$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

15. Row-reduce the homogeneous system: start with $A-(1)I=\begin{bmatrix}0&0\\0&-1\end{bmatrix}$.

16. Swap rows 1 and 2 to place a nonzero pivot or reorder the equations.

   $$
   \xrightarrow{R_{1}\leftrightarrow R_{2}}\begin{bmatrix}0&-1\\0&0\end{bmatrix}
   $$

17. Multiply row 1 by $-1$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (-1)R_{1}}\begin{bmatrix}0&1\\0&0\end{bmatrix}
   $$

18. The pivot columns are 2; the free variable is $x_1$.

19. The pivot equations give $x_2=0$.

20. Choose one free variable at a time and set the others to zero.

21. Clear fractions where necessary.

22. The resulting basis is $\left\{\begin{bmatrix}1\\0\end{bmatrix}\right\}$.

23. Hence $\dim E_{1}=1$.

24. The roots of the factored polynomial are $\lambda=1$ (algebraic multiplicity 1), $\lambda=0$ (algebraic multiplicity 1).

25. Check: $A\begin{bmatrix}0\\1\end{bmatrix}=\begin{bmatrix}0\\0\end{bmatrix}=0\begin{bmatrix}0\\1\end{bmatrix}$.

26. Check: $A\begin{bmatrix}1\\0\end{bmatrix}=\begin{bmatrix}1\\0\end{bmatrix}=1\begin{bmatrix}1\\0\end{bmatrix}$.
::::

:::

:::problem[Problem 5.6 — Test a candidate eigenvector]{difficulty=standard}
For $A=\begin{bmatrix}3&1\\0&2\end{bmatrix}$, test whether $(1,0)^T$ is an eigenvector and calculate all eigenspaces.

::::solution[Solution]
**Answer:** Eigenvalues $2$, $3$.  Eigenspace bases: $E_{2}=\span\left\{\begin{bmatrix}-1\\1\end{bmatrix}\right\}$, $E_{3}=\span\left\{\begin{bmatrix}1\\0\end{bmatrix}\right\}$.

1. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

2. Form $A-\lambda I=\begin{bmatrix}3 - \lambda&1\\0&2 - \lambda\end{bmatrix}$.

3. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=(3-\lambda)(2-\lambda)-(1)(0)
   $$

4. Expand, simplify, and factor the preceding expression.

   $$
   =\lambda^{2} - 5 \lambda + 6=\left(\lambda - 3\right) \left(\lambda - 2\right).
   $$

5. Eigenspace for $\lambda=2$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

6. Row-reduce the homogeneous system: start with $A-(2)I=\begin{bmatrix}1&1\\0&0\end{bmatrix}$.

7. No row operation is needed; the matrix is already in reduced row-echelon form.

8. The pivot columns are 1; the free variable is $x_2$.

9. The pivot equations give $x_1=- x_{2}$.

10. Choose one free variable at a time and set the others to zero.

11. Clear fractions where necessary.

12. The resulting basis is $\left\{\begin{bmatrix}-1\\1\end{bmatrix}\right\}$.

13. Hence $\dim E_{2}=1$.

14. Eigenspace for $\lambda=3$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

15. Row-reduce the homogeneous system: start with $A-(3)I=\begin{bmatrix}0&1\\0&-1\end{bmatrix}$.

16. Replace row 2 by itself plus $1$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (1)R_{1}}\begin{bmatrix}0&1\\0&0\end{bmatrix}
   $$

17. The pivot columns are 2; the free variable is $x_1$.

18. The pivot equations give $x_2=0$.

19. Choose one free variable at a time and set the others to zero.

20. Clear fractions where necessary.

21. The resulting basis is $\left\{\begin{bmatrix}1\\0\end{bmatrix}\right\}$.

22. Hence $\dim E_{3}=1$.

23. The roots of the factored polynomial are $\lambda=3$ (algebraic multiplicity 1), $\lambda=2$ (algebraic multiplicity 1).

24. Check: $A\begin{bmatrix}-1\\1\end{bmatrix}=\begin{bmatrix}-2\\2\end{bmatrix}=2\begin{bmatrix}-1\\1\end{bmatrix}$.

25. Check: $A\begin{bmatrix}1\\0\end{bmatrix}=\begin{bmatrix}3\\0\end{bmatrix}=3\begin{bmatrix}1\\0\end{bmatrix}$.
::::

:::


### Practice problems: Repeated eigenvalue and nullity

:::problem[Problem 5.7 — Repeated eigenvalue and nullity]{difficulty=challenge}
For $A=\begin{bmatrix}2&1&0\\0&2&0\\0&0&4\end{bmatrix}$, explain why the repeated eigenvalue has only one eigendirection.

::::solution[Solution]
**Answer:** Eigenvalues $2$, $4$.  Eigenspace bases: $E_{2}=\span\left\{\begin{bmatrix}1\\0\\0\end{bmatrix}\right\}$, $E_{4}=\span\left\{\begin{bmatrix}0\\0\\1\end{bmatrix}\right\}$.

1. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

2. Form $A-\lambda I=\begin{bmatrix}2 - \lambda&1&0\\0&2 - \lambda&0\\0&0&4 - \lambda\end{bmatrix}$.

3. The matrix is triangular, so multiply its three diagonal entries after subtracting $\lambda$:

4. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=\left(4 - \lambda\right) \left(\lambda - 2\right)^{2}=- \lambda^{3} + 8 \lambda^{2} - 20 \lambda + 16.
   $$

5. Eigenspace for $\lambda=2$ (algebraic multiplicity 2): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

6. Row-reduce the homogeneous system: start with $A-(2)I=\begin{bmatrix}0&1&0\\0&0&0\\0&0&2\end{bmatrix}$.

7. Swap rows 2 and 3 to place a nonzero pivot or reorder the equations.

   $$
   \xrightarrow{R_{2}\leftrightarrow R_{3}}\begin{bmatrix}0&1&0\\0&0&2\\0&0&0\end{bmatrix}
   $$

8. Multiply row 2 by $\frac{1}{2}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{2}\leftarrow (\frac{1}{2})R_{2}}\begin{bmatrix}0&1&0\\0&0&1\\0&0&0\end{bmatrix}
   $$

9. The pivot columns are 2, 3; the free variable is $x_1$.

10. The pivot equations give $x_2=0$, $x_3=0$.

11. Choose one free variable at a time and set the others to zero.

12. Clear fractions where necessary.

13. The resulting basis is $\left\{\begin{bmatrix}1\\0\\0\end{bmatrix}\right\}$.

14. Hence $\dim E_{2}=1$.

15. Eigenspace for $\lambda=4$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

16. Row-reduce the homogeneous system: start with $A-(4)I=\begin{bmatrix}-2&1&0\\0&-2&0\\0&0&0\end{bmatrix}$.

17. Multiply row 1 by $- \frac{1}{2}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (- \frac{1}{2})R_{1}}\begin{bmatrix}1&- \frac{1}{2}&0\\0&-2&0\\0&0&0\end{bmatrix}
   $$

18. Multiply row 2 by $- \frac{1}{2}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{2}\leftarrow (- \frac{1}{2})R_{2}}\begin{bmatrix}1&- \frac{1}{2}&0\\0&1&0\\0&0&0\end{bmatrix}
   $$

19. Replace row 1 by itself plus $\frac{1}{2}$ times row 2 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{1}\leftarrow R_{1} + (\frac{1}{2})R_{2}}\begin{bmatrix}1&0&0\\0&1&0\\0&0&0\end{bmatrix}
   $$

20. The pivot columns are 1, 2; the free variable is $x_3$.

21. The pivot equations give $x_1=0$, $x_2=0$.

22. Choose one free variable at a time and set the others to zero.

23. Clear fractions where necessary.

24. The resulting basis is $\left\{\begin{bmatrix}0\\0\\1\end{bmatrix}\right\}$.

25. Hence $\dim E_{4}=1$.

26. The roots of the factored polynomial are $\lambda=4$ (algebraic multiplicity 1), $\lambda=2$ (algebraic multiplicity 2).

27. Check: $A\begin{bmatrix}1\\0\\0\end{bmatrix}=\begin{bmatrix}2\\0\\0\end{bmatrix}=2\begin{bmatrix}1\\0\\0\end{bmatrix}$.

28. Check: $A\begin{bmatrix}0\\0\\1\end{bmatrix}=\begin{bmatrix}0\\0\\4\end{bmatrix}=4\begin{bmatrix}0\\0\\1\end{bmatrix}$.
::::

:::

## 5.2 The Characteristic Equation

:::callout-intuition[Why the determinant finds the special stretch factors]
For a random number $\lambda$, the transformation $A-\lambda I$ is invertible, so its homogeneous system has only the zero solution. The special numbers are the exact moments when that matrix loses invertibility. Its determinant becomes zero, and a free variable appears. A determinant calculation is the fastest way to locate that loss before doing any row reduction.
:::

:::callout-tip[Choosing a 3 by 3 cofactor expansion]
Write the full $A-\lambda I$ first. Count zeros in every row and column. Expand across the line with the most zeros; the cofactor sign grid is $\begin{bmatrix}+&-&+\\-&+&-\\+&-&+\end{bmatrix}$. Evaluate each surviving 2 by 2 minor as $ad-bc$. **Do not row-reduce a symbolic matrix casually**: dividing by an expression containing $\lambda$ may silently discard a root. For a triangular matrix, the entire expansion collapses to the diagonal product.
:::

:::theorem[The trace and determinant checks]
For a 2 by 2 matrix, $\det(A-\lambda I)=\lambda^2-(\tr A)\lambda+\det A$. The sum of the two eigenvalues is $\tr A$, and their product is $\det A$. In any dimension, the product of the eigenvalues, counted with multiplicity, is $\det A$.
:::

:::callout-warning[What similarity does not preserve]
Similar matrices have the same characteristic polynomial, trace, determinant, eigenvalues, and algebraic multiplicities. They need **not** have identical entries or eigenvectors. The converse, 'same eigenvalues implies similar', is false; a diagonal matrix and a Jordan block can have the same repeated eigenvalue but different eigenspace dimensions.
:::

:::definition[Definition 5.3 — Characteristic Polynomial]
The **characteristic polynomial** of an $n\times n$ matrix $A$ is

$$
\det(A - \lambda I)
$$

The **characteristic equation** is $\det(A-\lambda I)=0$. Its roots are the eigenvalues of $A$.
:::

:::callout-key[Algorithm: Finding Eigenvalues]
1. Form $A-\lambda I$ (replace each diagonal entry $a_{ii}$ with $a_{ii}-\lambda$).
2. Compute $\det(A-\lambda I)$ as a polynomial in $\lambda$.
3. Factor and set equal to zero; solve for $\lambda$.
4. For each $\lambda$, row-reduce $A-\lambda I$ to find a basis for $E_\lambda$.
:::

:::example[Example 5.5 — Characteristic Equation of a $2\times 2$ Matrix]
Find the eigenvalues of $A=\begin{bmatrix}2&3\\1&4\end{bmatrix}$.

::::answer[Answer]
**Answer:** The eigenvalues are $1$ and $5$.

1. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

2. Form $A-\lambda I=\begin{bmatrix}2 - \lambda&3\\1&4 - \lambda\end{bmatrix}$.

3. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=(2-\lambda)(4-\lambda)-(3)(1)
   $$

4. Expand, simplify, and factor the preceding expression.

   $$
   =\lambda^{2} - 6 \lambda + 5=\left(\lambda - 5\right) \left(\lambda - 1\right).
   $$

5. Eigenspace for $\lambda=1$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

6. Row-reduce the homogeneous system: start with $A-(1)I=\begin{bmatrix}1&3\\1&3\end{bmatrix}$.

7. Replace row 2 by itself plus $-1$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (-1)R_{1}}\begin{bmatrix}1&3\\0&0\end{bmatrix}
   $$

8. The pivot columns are 1; the free variable is $x_2$.

9. The pivot equations give $x_1=- 3 x_{2}$.

10. The resulting basis is $\left\{\begin{bmatrix}-3\\1\end{bmatrix}\right\}$.

11. Hence $\dim E_{1}=1$.

12. Eigenspace for $\lambda=5$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

13. Row-reduce the homogeneous system: start with $A-(5)I=\begin{bmatrix}-3&3\\1&-1\end{bmatrix}$.

14. Multiply row 1 by $- \frac{1}{3}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (- \frac{1}{3})R_{1}}\begin{bmatrix}1&-1\\1&-1\end{bmatrix}
   $$

15. Replace row 2 by itself plus $-1$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (-1)R_{1}}\begin{bmatrix}1&-1\\0&0\end{bmatrix}
   $$

16. The pivot columns are 1; the free variable is $x_2$.

17. The pivot equations give $x_1=x_{2}$.

18. The resulting basis is $\left\{\begin{bmatrix}1\\1\end{bmatrix}\right\}$.

19. Hence $\dim E_{5}=1$.

20. Check: $A\begin{bmatrix}-3\\1\end{bmatrix}=\begin{bmatrix}-3\\1\end{bmatrix}=1\begin{bmatrix}-3\\1\end{bmatrix}$.

21. Check: $A\begin{bmatrix}1\\1\end{bmatrix}=\begin{bmatrix}5\\5\end{bmatrix}=5\begin{bmatrix}1\\1\end{bmatrix}$.
::::

:::


### Worked examples: Characteristic Equation of a $3\times 3$ Matrix

:::example[Example 5.6 — Characteristic Equation of a $3\times 3$ Matrix]
Find the eigenvalues and eigenvectors of $A=\begin{bmatrix}5&0&0\\-2&4&0\\4&-2&3\end{bmatrix}$.

::::answer[Answer]
**Answer:** $\lambda=5,4,3$, with bases $E_5=\span\{(1,-2,4)^T\}$, $E_4=\span\{(0,1,-2)^T\}$ and $E_3=\span\{(0,0,1)^T\}$.

1. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

2. Form $A-\lambda I=\begin{bmatrix}5 - \lambda&0&0\\-2&4 - \lambda&0\\4&-2&3 - \lambda\end{bmatrix}$.

3. The matrix is triangular, so multiply its three diagonal entries after subtracting $\lambda$:

4. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=- \left(\lambda - 5\right) \left(\lambda - 4\right) \left(\lambda - 3\right)=- \lambda^{3} + 12 \lambda^{2} - 47 \lambda + 60.
   $$

5. Eigenspace for $\lambda=3$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

6. Row-reduce the homogeneous system: start with $A-(3)I=\begin{bmatrix}2&0&0\\-2&1&0\\4&-2&0\end{bmatrix}$.

7. Multiply row 1 by $\frac{1}{2}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (\frac{1}{2})R_{1}}\begin{bmatrix}1&0&0\\-2&1&0\\4&-2&0\end{bmatrix}
   $$

8. Replace row 2 by itself plus $2$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (2)R_{1}}\begin{bmatrix}1&0&0\\0&1&0\\4&-2&0\end{bmatrix}
   $$

9. Replace row 3 by itself plus $-4$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{3}\leftarrow R_{3} + (-4)R_{1}}\begin{bmatrix}1&0&0\\0&1&0\\0&-2&0\end{bmatrix}
   $$

10. Replace row 3 by itself plus $2$ times row 2 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{3}\leftarrow R_{3} + (2)R_{2}}\begin{bmatrix}1&0&0\\0&1&0\\0&0&0\end{bmatrix}
   $$

11. The pivot columns are 1, 2; the free variable is $x_3$.

12. The pivot equations give $x_1=0$, $x_2=0$.

13. The resulting basis is $\left\{\begin{bmatrix}0\\0\\1\end{bmatrix}\right\}$.

14. Hence $\dim E_{3}=1$.

15. Eigenspace for $\lambda=4$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

16. Row-reduce the homogeneous system: start with $A-(4)I=\begin{bmatrix}1&0&0\\-2&0&0\\4&-2&-1\end{bmatrix}$.

17. Replace row 2 by itself plus $2$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (2)R_{1}}\begin{bmatrix}1&0&0\\0&0&0\\4&-2&-1\end{bmatrix}
   $$

18. Replace row 3 by itself plus $-4$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{3}\leftarrow R_{3} + (-4)R_{1}}\begin{bmatrix}1&0&0\\0&0&0\\0&-2&-1\end{bmatrix}
   $$

19. Swap rows 2 and 3 to place a nonzero pivot or reorder the equations.

   $$
   \xrightarrow{R_{2}\leftrightarrow R_{3}}\begin{bmatrix}1&0&0\\0&-2&-1\\0&0&0\end{bmatrix}
   $$

20. Multiply row 2 by $- \frac{1}{2}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{2}\leftarrow (- \frac{1}{2})R_{2}}\begin{bmatrix}1&0&0\\0&1&\frac{1}{2}\\0&0&0\end{bmatrix}
   $$

21. The pivot columns are 1, 2; the free variable is $x_3$.

22. The pivot equations give $x_1=0$, $x_2=- \frac{x_{3}}{2}$.

23. The resulting basis is $\left\{\begin{bmatrix}0\\-1\\2\end{bmatrix}\right\}$.

24. Hence $\dim E_{4}=1$.

25. Eigenspace for $\lambda=5$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

26. Row-reduce the homogeneous system: start with $A-(5)I=\begin{bmatrix}0&0&0\\-2&-1&0\\4&-2&-2\end{bmatrix}$.

27. Swap rows 1 and 2 to place a nonzero pivot or reorder the equations.

   $$
   \xrightarrow{R_{1}\leftrightarrow R_{2}}\begin{bmatrix}-2&-1&0\\0&0&0\\4&-2&-2\end{bmatrix}
   $$

28. Multiply row 1 by $- \frac{1}{2}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (- \frac{1}{2})R_{1}}\begin{bmatrix}1&\frac{1}{2}&0\\0&0&0\\4&-2&-2\end{bmatrix}
   $$

29. Replace row 3 by itself plus $-4$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{3}\leftarrow R_{3} + (-4)R_{1}}\begin{bmatrix}1&\frac{1}{2}&0\\0&0&0\\0&-4&-2\end{bmatrix}
   $$

30. Swap rows 2 and 3 to place a nonzero pivot or reorder the equations.

   $$
   \xrightarrow{R_{2}\leftrightarrow R_{3}}\begin{bmatrix}1&\frac{1}{2}&0\\0&-4&-2\\0&0&0\end{bmatrix}
   $$

31. Multiply row 2 by $- \frac{1}{4}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{2}\leftarrow (- \frac{1}{4})R_{2}}\begin{bmatrix}1&\frac{1}{2}&0\\0&1&\frac{1}{2}\\0&0&0\end{bmatrix}
   $$

32. Replace row 1 by itself plus $- \frac{1}{2}$ times row 2 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{1}\leftarrow R_{1} + (- \frac{1}{2})R_{2}}\begin{bmatrix}1&0&- \frac{1}{4}\\0&1&\frac{1}{2}\\0&0&0\end{bmatrix}
   $$

33. The pivot columns are 1, 2; the free variable is $x_3$.

34. The pivot equations give $x_1=\frac{x_{3}}{4}$, $x_2=- \frac{x_{3}}{2}$.

35. The resulting basis is $\left\{\begin{bmatrix}1\\-2\\4\end{bmatrix}\right\}$.

36. Hence $\dim E_{5}=1$.

37. Check: $A\begin{bmatrix}0\\0\\1\end{bmatrix}=\begin{bmatrix}0\\0\\3\end{bmatrix}=3\begin{bmatrix}0\\0\\1\end{bmatrix}$.

38. Check: $A\begin{bmatrix}0\\-1\\2\end{bmatrix}=\begin{bmatrix}0\\-4\\8\end{bmatrix}=4\begin{bmatrix}0\\-1\\2\end{bmatrix}$.

39. Check: $A\begin{bmatrix}1\\-2\\4\end{bmatrix}=\begin{bmatrix}5\\-10\\20\end{bmatrix}=5\begin{bmatrix}1\\-2\\4\end{bmatrix}$.
::::

:::


### The next result

:::definition[Definition 5.4 — Algebraic and Geometric Multiplicity]
For eigenvalue $\lambda$:

- **Algebraic multiplicity:** the multiplicity of $\lambda$ as a root of the characteristic polynomial.
- **Geometric multiplicity:** $\dim E_\lambda = \dim\Nul(A-\lambda I)$.

Always: $1 \le \text{geometric mult.} \le \text{algebraic mult.}$
:::

### Similarity

:::definition[Definition 5.5 — Similar Matrices]
Matrices $A$ and $B$ are **similar** if there exists an invertible matrix $P$ such that $P^{-1}AP=B$ (or equivalently $A=PBP^{-1}$).
:::

:::theorem[Theorem 5.3 — Similar Matrices Share Eigenvalues]
If $A$ and $B$ are similar, they have the same characteristic polynomial and thus the same eigenvalues with the same algebraic multiplicities.
:::


:::example[Example 5.7 — Three by three cofactor expansion with a zero-rich column]
For $A=\begin{bmatrix}1&2&0\\2&1&0\\1&1&3\end{bmatrix}$, find the characteristic polynomial using the best cofactor expansion, factor it, and find every eigenspace.

::::answer[Answer]
**Answer:** Eigenvalues $-1$, $3$.  Eigenspace bases: $E_{-1}=\span\left\{\begin{bmatrix}-1\\1\\0\end{bmatrix}\right\}$, $E_{3}=\span\left\{\begin{bmatrix}0\\0\\1\end{bmatrix}\right\}$.

1. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

2. Form $A-\lambda I=\begin{bmatrix}1 - \lambda&2&0\\2&1 - \lambda&0\\1&1&3 - \lambda\end{bmatrix}$.

3. Expand along column 3, which has the most zeros (ties favor columns).

4. The cofactor signs alternate $+,-,+$ across the first row.

5. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=(3 - \lambda)\left[(1 - \lambda)(1 - \lambda)-(2)(2)\right]
   $$

6. Expand, simplify, and factor the preceding expression.

   $$
   =- \lambda^{3} + 5 \lambda^{2} - 3 \lambda - 9=\left(- \lambda - 1\right) \left(\lambda - 3\right)^{2}.
   $$

7. Eigenspace for $\lambda=-1$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

8. Row-reduce the homogeneous system: start with $A-(-1)I=\begin{bmatrix}2&2&0\\2&2&0\\1&1&4\end{bmatrix}$.

9. Multiply row 1 by $\frac{1}{2}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (\frac{1}{2})R_{1}}\begin{bmatrix}1&1&0\\2&2&0\\1&1&4\end{bmatrix}
   $$

10. Replace row 2 by itself plus $-2$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (-2)R_{1}}\begin{bmatrix}1&1&0\\0&0&0\\1&1&4\end{bmatrix}
   $$

11. Replace row 3 by itself plus $-1$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{3}\leftarrow R_{3} + (-1)R_{1}}\begin{bmatrix}1&1&0\\0&0&0\\0&0&4\end{bmatrix}
   $$

12. Swap rows 2 and 3 to place a nonzero pivot or reorder the equations.

   $$
   \xrightarrow{R_{2}\leftrightarrow R_{3}}\begin{bmatrix}1&1&0\\0&0&4\\0&0&0\end{bmatrix}
   $$

13. Multiply row 2 by $\frac{1}{4}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{2}\leftarrow (\frac{1}{4})R_{2}}\begin{bmatrix}1&1&0\\0&0&1\\0&0&0\end{bmatrix}
   $$

14. The pivot columns are 1, 3; the free variable is $x_2$.

15. The pivot equations give $x_1=- x_{2}$, $x_3=0$.

16. The resulting basis is $\left\{\begin{bmatrix}-1\\1\\0\end{bmatrix}\right\}$.

17. Hence $\dim E_{-1}=1$.

18. Eigenspace for $\lambda=3$ (algebraic multiplicity 2): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

19. Row-reduce the homogeneous system: start with $A-(3)I=\begin{bmatrix}-2&2&0\\2&-2&0\\1&1&0\end{bmatrix}$.

20. Multiply row 1 by $- \frac{1}{2}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (- \frac{1}{2})R_{1}}\begin{bmatrix}1&-1&0\\2&-2&0\\1&1&0\end{bmatrix}
   $$

21. Replace row 2 by itself plus $-2$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (-2)R_{1}}\begin{bmatrix}1&-1&0\\0&0&0\\1&1&0\end{bmatrix}
   $$

22. Replace row 3 by itself plus $-1$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{3}\leftarrow R_{3} + (-1)R_{1}}\begin{bmatrix}1&-1&0\\0&0&0\\0&2&0\end{bmatrix}
   $$

23. Swap rows 2 and 3 to place a nonzero pivot or reorder the equations.

   $$
   \xrightarrow{R_{2}\leftrightarrow R_{3}}\begin{bmatrix}1&-1&0\\0&2&0\\0&0&0\end{bmatrix}
   $$

24. Multiply row 2 by $\frac{1}{2}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{2}\leftarrow (\frac{1}{2})R_{2}}\begin{bmatrix}1&-1&0\\0&1&0\\0&0&0\end{bmatrix}
   $$

25. Replace row 1 by itself plus $1$ times row 2 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{1}\leftarrow R_{1} + (1)R_{2}}\begin{bmatrix}1&0&0\\0&1&0\\0&0&0\end{bmatrix}
   $$

26. The pivot columns are 1, 2; the free variable is $x_3$.

27. The pivot equations give $x_1=0$, $x_2=0$.

28. The resulting basis is $\left\{\begin{bmatrix}0\\0\\1\end{bmatrix}\right\}$.

29. Hence $\dim E_{3}=1$.

30. Check: $A\begin{bmatrix}-1\\1\\0\end{bmatrix}=\begin{bmatrix}1\\-1\\0\end{bmatrix}=-1\begin{bmatrix}-1\\1\\0\end{bmatrix}$.

31. Check: $A\begin{bmatrix}0\\0\\1\end{bmatrix}=\begin{bmatrix}0\\0\\3\end{bmatrix}=3\begin{bmatrix}0\\0\\1\end{bmatrix}$.
::::

:::


### Worked examples: Repeated root, geometric multiplicity

:::example[Example 5.8 — Repeated root, geometric multiplicity]
For $A=\begin{bmatrix}2&1&0\\0&2&0\\0&0&-1\end{bmatrix}$, find its eigenvalues with multiplicities and determine the dimension of each eigenspace.

::::answer[Answer]
**Answer:** Eigenvalues $-1$, $2$.  Eigenspace bases: $E_{-1}=\span\left\{\begin{bmatrix}0\\0\\1\end{bmatrix}\right\}$, $E_{2}=\span\left\{\begin{bmatrix}1\\0\\0\end{bmatrix}\right\}$.

1. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

2. Form $A-\lambda I=\begin{bmatrix}2 - \lambda&1&0\\0&2 - \lambda&0\\0&0&- \lambda - 1\end{bmatrix}$.

3. The matrix is triangular, so multiply its three diagonal entries after subtracting $\lambda$:

4. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=\left(- \lambda - 1\right) \left(\lambda - 2\right)^{2}=- \lambda^{3} + 3 \lambda^{2} - 4.
   $$

5. Eigenspace for $\lambda=-1$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

6. Row-reduce the homogeneous system: start with $A-(-1)I=\begin{bmatrix}3&1&0\\0&3&0\\0&0&0\end{bmatrix}$.

7. Multiply row 1 by $\frac{1}{3}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (\frac{1}{3})R_{1}}\begin{bmatrix}1&\frac{1}{3}&0\\0&3&0\\0&0&0\end{bmatrix}
   $$

8. Multiply row 2 by $\frac{1}{3}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{2}\leftarrow (\frac{1}{3})R_{2}}\begin{bmatrix}1&\frac{1}{3}&0\\0&1&0\\0&0&0\end{bmatrix}
   $$

9. Replace row 1 by itself plus $- \frac{1}{3}$ times row 2 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{1}\leftarrow R_{1} + (- \frac{1}{3})R_{2}}\begin{bmatrix}1&0&0\\0&1&0\\0&0&0\end{bmatrix}
   $$

10. The pivot columns are 1, 2; the free variable is $x_3$.

11. The pivot equations give $x_1=0$, $x_2=0$.

12. The resulting basis is $\left\{\begin{bmatrix}0\\0\\1\end{bmatrix}\right\}$.

13. Hence $\dim E_{-1}=1$.

14. Eigenspace for $\lambda=2$ (algebraic multiplicity 2): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

15. Row-reduce the homogeneous system: start with $A-(2)I=\begin{bmatrix}0&1&0\\0&0&0\\0&0&-3\end{bmatrix}$.

16. Swap rows 2 and 3 to place a nonzero pivot or reorder the equations.

   $$
   \xrightarrow{R_{2}\leftrightarrow R_{3}}\begin{bmatrix}0&1&0\\0&0&-3\\0&0&0\end{bmatrix}
   $$

17. Multiply row 2 by $- \frac{1}{3}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{2}\leftarrow (- \frac{1}{3})R_{2}}\begin{bmatrix}0&1&0\\0&0&1\\0&0&0\end{bmatrix}
   $$

18. The pivot columns are 2, 3; the free variable is $x_1$.

19. The pivot equations give $x_2=0$, $x_3=0$.

20. The resulting basis is $\left\{\begin{bmatrix}1\\0\\0\end{bmatrix}\right\}$.

21. Hence $\dim E_{2}=1$.

22. Check: $A\begin{bmatrix}0\\0\\1\end{bmatrix}=\begin{bmatrix}0\\0\\-1\end{bmatrix}=-1\begin{bmatrix}0\\0\\1\end{bmatrix}$.

23. Check: $A\begin{bmatrix}1\\0\\0\end{bmatrix}=\begin{bmatrix}2\\0\\0\end{bmatrix}=2\begin{bmatrix}1\\0\\0\end{bmatrix}$.
::::

:::

:::callout-pitfall[Pitfalls in §5.2]
(1) Changing only some diagonal entries when forming $A-\lambda I$. (2) Forgetting the $-$ sign on a middle-position cofactor. (3) Reporting roots without factoring or omitting repeated-root multiplicities. (4) Assuming sharing eigenvalues proves similarity.
:::

:::problem[Problem 5.8 — Repeated characteristic root]{difficulty=easy}
Find the characteristic polynomial of $A=\begin{bmatrix}3&1\\0&3\end{bmatrix}$.

::::solution[Solution]
**Answer:** $\det(A-\lambda I)=(3-\lambda)^2$; $\lambda=3$ has multiplicity two.

1. $\det(A-\lambda I)=(3-\lambda)^2-0=(3-\lambda)^2$.

2. Eigenvalue $\lambda=3$ with algebraic multiplicity 2.

3. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

4. Form $A-\lambda I=\begin{bmatrix}3 - \lambda&1\\0&3 - \lambda\end{bmatrix}$.

5. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=(3-\lambda)(3-\lambda)-(1)(0)
   $$

6. Expand, simplify, and factor the preceding expression.

   $$
   =\lambda^{2} - 6 \lambda + 9=\left(\lambda - 3\right)^{2}.
   $$
::::

:::

:::problem[Problem 5.9 — Cofactor expansion in three dimensions]{difficulty=standard}
Find all eigenvalues of $A=\begin{bmatrix}0&0&-2\\1&2&1\\1&0&3\end{bmatrix}$. (Hint: expand along the first row.)

::::solution[Solution]
**Answer:** Eigenvalues are $\lambda=1$ and $\lambda=2$ (the latter twice).

1. $\det(A-\lambda I)=\det\begin{bmatrix}-\lambda&0&-2\\1&2-\lambda&1\\1&0&3-\lambda\end{bmatrix}$.

2. Expanding along column 2: $(2-\lambda)\det\begin{bmatrix}-\lambda&-2\\1&3-\lambda\end{bmatrix}=(2-\lambda)(-\lambda(3-\lambda)+2)=(2-\lambda)(\lambda^2-3\lambda+2)=(2-\lambda)(\lambda-1)(\lambda-2)=(2-\lambda)^2(\lambda-1)$.

3. Eigenvalues: $\lambda=1$ (mult. 1), $\lambda=2$ (mult. 2).

4. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

5. Form $A-\lambda I=\begin{bmatrix}- \lambda&0&-2\\1&2 - \lambda&1\\1&0&3 - \lambda\end{bmatrix}$.

6. Expand along column 2, which has the most zeros (ties favor columns).

7. The cofactor signs alternate $+,-,+$ across the first row.

8. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=(2 - \lambda)\left[(- \lambda)(3 - \lambda)-(-2)(1)\right]
   $$

9. Expand, simplify, and factor the preceding expression.

   $$
   =- \lambda^{3} + 5 \lambda^{2} - 8 \lambda + 4=\left(1 - \lambda\right) \left(\lambda - 2\right)^{2}.
   $$
::::

:::


### Practice problems: Triangular characteristic polynomial

:::problem[Problem 5.10 — Triangular characteristic polynomial]{difficulty=easy}
For $A=\begin{bmatrix}2&3&0\\0&4&0\\0&0&-1\end{bmatrix}$, use the triangular shortcut and show the expanded polynomial.

::::solution[Solution]
**Answer:** Eigenvalues $-1$, $2$, $4$.  Eigenspace bases: $E_{-1}=\span\left\{\begin{bmatrix}0\\0\\1\end{bmatrix}\right\}$, $E_{2}=\span\left\{\begin{bmatrix}1\\0\\0\end{bmatrix}\right\}$, $E_{4}=\span\left\{\begin{bmatrix}3\\2\\0\end{bmatrix}\right\}$.

1. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

2. Form $A-\lambda I=\begin{bmatrix}2 - \lambda&3&0\\0&4 - \lambda&0\\0&0&- \lambda - 1\end{bmatrix}$.

3. The matrix is triangular, so multiply its three diagonal entries after subtracting $\lambda$:

4. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=- \left(\lambda - 4\right) \left(\lambda - 2\right) \left(\lambda + 1\right)=- \lambda^{3} + 5 \lambda^{2} - 2 \lambda - 8.
   $$

5. Eigenspace for $\lambda=-1$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

6. Row-reduce the homogeneous system: start with $A-(-1)I=\begin{bmatrix}3&3&0\\0&5&0\\0&0&0\end{bmatrix}$.

7. Multiply row 1 by $\frac{1}{3}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (\frac{1}{3})R_{1}}\begin{bmatrix}1&1&0\\0&5&0\\0&0&0\end{bmatrix}
   $$

8. Multiply row 2 by $\frac{1}{5}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{2}\leftarrow (\frac{1}{5})R_{2}}\begin{bmatrix}1&1&0\\0&1&0\\0&0&0\end{bmatrix}
   $$

9. Replace row 1 by itself plus $-1$ times row 2 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{1}\leftarrow R_{1} + (-1)R_{2}}\begin{bmatrix}1&0&0\\0&1&0\\0&0&0\end{bmatrix}
   $$

10. The pivot columns are 1, 2; the free variable is $x_3$.

11. The pivot equations give $x_1=0$, $x_2=0$.

12. The resulting basis is $\left\{\begin{bmatrix}0\\0\\1\end{bmatrix}\right\}$.

13. Hence $\dim E_{-1}=1$.

14. Eigenspace for $\lambda=2$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

15. Row-reduce the homogeneous system: start with $A-(2)I=\begin{bmatrix}0&3&0\\0&2&0\\0&0&-3\end{bmatrix}$.

16. Multiply row 1 by $\frac{1}{3}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (\frac{1}{3})R_{1}}\begin{bmatrix}0&1&0\\0&2&0\\0&0&-3\end{bmatrix}
   $$

17. Replace row 2 by itself plus $-2$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (-2)R_{1}}\begin{bmatrix}0&1&0\\0&0&0\\0&0&-3\end{bmatrix}
   $$

18. Swap rows 2 and 3 to place a nonzero pivot or reorder the equations.

   $$
   \xrightarrow{R_{2}\leftrightarrow R_{3}}\begin{bmatrix}0&1&0\\0&0&-3\\0&0&0\end{bmatrix}
   $$

19. Multiply row 2 by $- \frac{1}{3}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{2}\leftarrow (- \frac{1}{3})R_{2}}\begin{bmatrix}0&1&0\\0&0&1\\0&0&0\end{bmatrix}
   $$

20. The pivot columns are 2, 3; the free variable is $x_1$.

21. The pivot equations give $x_2=0$, $x_3=0$.

22. The resulting basis is $\left\{\begin{bmatrix}1\\0\\0\end{bmatrix}\right\}$.

23. Hence $\dim E_{2}=1$.

24. Eigenspace for $\lambda=4$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

25. Row-reduce the homogeneous system: start with $A-(4)I=\begin{bmatrix}-2&3&0\\0&0&0\\0&0&-5\end{bmatrix}$.

26. Multiply row 1 by $- \frac{1}{2}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (- \frac{1}{2})R_{1}}\begin{bmatrix}1&- \frac{3}{2}&0\\0&0&0\\0&0&-5\end{bmatrix}
   $$

27. Swap rows 2 and 3 to place a nonzero pivot or reorder the equations.

   $$
   \xrightarrow{R_{2}\leftrightarrow R_{3}}\begin{bmatrix}1&- \frac{3}{2}&0\\0&0&-5\\0&0&0\end{bmatrix}
   $$

28. Multiply row 2 by $- \frac{1}{5}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{2}\leftarrow (- \frac{1}{5})R_{2}}\begin{bmatrix}1&- \frac{3}{2}&0\\0&0&1\\0&0&0\end{bmatrix}
   $$

29. The pivot columns are 1, 3; the free variable is $x_2$.

30. The pivot equations give $x_1=\frac{3 x_{2}}{2}$, $x_3=0$.

31. The resulting basis is $\left\{\begin{bmatrix}3\\2\\0\end{bmatrix}\right\}$.

32. Hence $\dim E_{4}=1$.

33. Check: $A\begin{bmatrix}0\\0\\1\end{bmatrix}=\begin{bmatrix}0\\0\\-1\end{bmatrix}=-1\begin{bmatrix}0\\0\\1\end{bmatrix}$.

34. Check: $A\begin{bmatrix}1\\0\\0\end{bmatrix}=\begin{bmatrix}2\\0\\0\end{bmatrix}=2\begin{bmatrix}1\\0\\0\end{bmatrix}$.

35. Check: $A\begin{bmatrix}3\\2\\0\end{bmatrix}=\begin{bmatrix}12\\8\\0\end{bmatrix}=4\begin{bmatrix}3\\2\\0\end{bmatrix}$.
::::

:::

:::problem[Problem 5.11 — Characteristic equation and eigenspaces]{difficulty=standard}
For $A=\begin{bmatrix}3&1\\2&2\end{bmatrix}$, calculate the characteristic equation and both eigenspaces.

::::solution[Solution]
**Answer:** Eigenvalues $1$, $4$.  Eigenspace bases: $E_{1}=\span\left\{\begin{bmatrix}-1\\2\end{bmatrix}\right\}$, $E_{4}=\span\left\{\begin{bmatrix}1\\1\end{bmatrix}\right\}$.

1. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

2. Form $A-\lambda I=\begin{bmatrix}3 - \lambda&1\\2&2 - \lambda\end{bmatrix}$.

3. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=(3-\lambda)(2-\lambda)-(1)(2)
   $$

4. Expand, simplify, and factor the preceding expression.

   $$
   =\lambda^{2} - 5 \lambda + 4=\left(\lambda - 4\right) \left(\lambda - 1\right).
   $$

5. Eigenspace for $\lambda=1$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

6. Row-reduce the homogeneous system: start with $A-(1)I=\begin{bmatrix}2&1\\2&1\end{bmatrix}$.

7. Multiply row 1 by $\frac{1}{2}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (\frac{1}{2})R_{1}}\begin{bmatrix}1&\frac{1}{2}\\2&1\end{bmatrix}
   $$

8. Replace row 2 by itself plus $-2$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (-2)R_{1}}\begin{bmatrix}1&\frac{1}{2}\\0&0\end{bmatrix}
   $$

9. The pivot columns are 1; the free variable is $x_2$.

10. The pivot equations give $x_1=- \frac{x_{2}}{2}$.

11. The resulting basis is $\left\{\begin{bmatrix}-1\\2\end{bmatrix}\right\}$.

12. Hence $\dim E_{1}=1$.

13. Eigenspace for $\lambda=4$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

14. Row-reduce the homogeneous system: start with $A-(4)I=\begin{bmatrix}-1&1\\2&-2\end{bmatrix}$.

15. Multiply row 1 by $-1$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (-1)R_{1}}\begin{bmatrix}1&-1\\2&-2\end{bmatrix}
   $$

16. Replace row 2 by itself plus $-2$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (-2)R_{1}}\begin{bmatrix}1&-1\\0&0\end{bmatrix}
   $$

17. The pivot columns are 1; the free variable is $x_2$.

18. The pivot equations give $x_1=x_{2}$.

19. The resulting basis is $\left\{\begin{bmatrix}1\\1\end{bmatrix}\right\}$.

20. Hence $\dim E_{4}=1$.

21. Check: $A\begin{bmatrix}-1\\2\end{bmatrix}=\begin{bmatrix}-1\\2\end{bmatrix}=1\begin{bmatrix}-1\\2\end{bmatrix}$.

22. Check: $A\begin{bmatrix}1\\1\end{bmatrix}=\begin{bmatrix}4\\4\end{bmatrix}=4\begin{bmatrix}1\\1\end{bmatrix}$.
::::

:::


### Practice problems: Expansion along a sparse row

:::problem[Problem 5.12 — Expansion along a sparse row]{difficulty=standard}
For $A=\begin{bmatrix}1&0&2\\0&4&0\\2&0&1\end{bmatrix}$, expand along the middle row and show why it is optimal.

::::solution[Solution]
**Answer:** Eigenvalues $-1$, $3$, $4$.  Eigenspace bases: $E_{-1}=\span\left\{\begin{bmatrix}-1\\0\\1\end{bmatrix}\right\}$, $E_{3}=\span\left\{\begin{bmatrix}1\\0\\1\end{bmatrix}\right\}$, $E_{4}=\span\left\{\begin{bmatrix}0\\1\\0\end{bmatrix}\right\}$.

1. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

2. Form $A-\lambda I=\begin{bmatrix}1 - \lambda&0&2\\0&4 - \lambda&0\\2&0&1 - \lambda\end{bmatrix}$.

3. Expand along column 2, which has the most zeros (ties favor columns).

4. The cofactor signs alternate $+,-,+$ across the first row.

5. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=(4 - \lambda)\left[(1 - \lambda)(1 - \lambda)-(2)(2)\right]
   $$

6. Expand, simplify, and factor the preceding expression.

   $$
   =- \lambda^{3} + 6 \lambda^{2} - 5 \lambda - 12=- \left(\lambda - 4\right) \left(\lambda - 3\right) \left(\lambda + 1\right).
   $$

7. Eigenspace for $\lambda=-1$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

8. Row-reduce the homogeneous system: start with $A-(-1)I=\begin{bmatrix}2&0&2\\0&5&0\\2&0&2\end{bmatrix}$.

9. Multiply row 1 by $\frac{1}{2}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (\frac{1}{2})R_{1}}\begin{bmatrix}1&0&1\\0&5&0\\2&0&2\end{bmatrix}
   $$

10. Replace row 3 by itself plus $-2$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{3}\leftarrow R_{3} + (-2)R_{1}}\begin{bmatrix}1&0&1\\0&5&0\\0&0&0\end{bmatrix}
   $$

11. Multiply row 2 by $\frac{1}{5}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{2}\leftarrow (\frac{1}{5})R_{2}}\begin{bmatrix}1&0&1\\0&1&0\\0&0&0\end{bmatrix}
   $$

12. The pivot columns are 1, 2; the free variable is $x_3$.

13. The pivot equations give $x_1=- x_{3}$, $x_2=0$.

14. The resulting basis is $\left\{\begin{bmatrix}-1\\0\\1\end{bmatrix}\right\}$.

15. Hence $\dim E_{-1}=1$.

16. Eigenspace for $\lambda=3$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

17. Row-reduce the homogeneous system: start with $A-(3)I=\begin{bmatrix}-2&0&2\\0&1&0\\2&0&-2\end{bmatrix}$.

18. Multiply row 1 by $- \frac{1}{2}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (- \frac{1}{2})R_{1}}\begin{bmatrix}1&0&-1\\0&1&0\\2&0&-2\end{bmatrix}
   $$

19. Replace row 3 by itself plus $-2$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{3}\leftarrow R_{3} + (-2)R_{1}}\begin{bmatrix}1&0&-1\\0&1&0\\0&0&0\end{bmatrix}
   $$

20. The pivot columns are 1, 2; the free variable is $x_3$.

21. The pivot equations give $x_1=x_{3}$, $x_2=0$.

22. The resulting basis is $\left\{\begin{bmatrix}1\\0\\1\end{bmatrix}\right\}$.

23. Hence $\dim E_{3}=1$.

24. Eigenspace for $\lambda=4$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

25. Row-reduce the homogeneous system: start with $A-(4)I=\begin{bmatrix}-3&0&2\\0&0&0\\2&0&-3\end{bmatrix}$.

26. Multiply row 1 by $- \frac{1}{3}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (- \frac{1}{3})R_{1}}\begin{bmatrix}1&0&- \frac{2}{3}\\0&0&0\\2&0&-3\end{bmatrix}
   $$

27. Replace row 3 by itself plus $-2$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{3}\leftarrow R_{3} + (-2)R_{1}}\begin{bmatrix}1&0&- \frac{2}{3}\\0&0&0\\0&0&- \frac{5}{3}\end{bmatrix}
   $$

28. Swap rows 2 and 3 to place a nonzero pivot or reorder the equations.

   $$
   \xrightarrow{R_{2}\leftrightarrow R_{3}}\begin{bmatrix}1&0&- \frac{2}{3}\\0&0&- \frac{5}{3}\\0&0&0\end{bmatrix}
   $$

29. Multiply row 2 by $- \frac{3}{5}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{2}\leftarrow (- \frac{3}{5})R_{2}}\begin{bmatrix}1&0&- \frac{2}{3}\\0&0&1\\0&0&0\end{bmatrix}
   $$

30. Replace row 1 by itself plus $\frac{2}{3}$ times row 2 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{1}\leftarrow R_{1} + (\frac{2}{3})R_{2}}\begin{bmatrix}1&0&0\\0&0&1\\0&0&0\end{bmatrix}
   $$

31. The pivot columns are 1, 3; the free variable is $x_2$.

32. The pivot equations give $x_1=0$, $x_3=0$.

33. The resulting basis is $\left\{\begin{bmatrix}0\\1\\0\end{bmatrix}\right\}$.

34. Hence $\dim E_{4}=1$.

35. Check: $A\begin{bmatrix}-1\\0\\1\end{bmatrix}=\begin{bmatrix}1\\0\\-1\end{bmatrix}=-1\begin{bmatrix}-1\\0\\1\end{bmatrix}$.

36. Check: $A\begin{bmatrix}1\\0\\1\end{bmatrix}=\begin{bmatrix}3\\0\\3\end{bmatrix}=3\begin{bmatrix}1\\0\\1\end{bmatrix}$.

37. Check: $A\begin{bmatrix}0\\1\\0\end{bmatrix}=\begin{bmatrix}0\\4\\0\end{bmatrix}=4\begin{bmatrix}0\\1\\0\end{bmatrix}$.
::::

:::

:::problem[Problem 5.13 — Algebraic versus geometric multiplicity]{difficulty=standard}
For $A=\begin{bmatrix}1&1&0\\0&1&0\\0&0&2\end{bmatrix}$, compare algebraic and geometric multiplicities.

::::solution[Solution]
**Answer:** Eigenvalues $1$, $2$.  Eigenspace bases: $E_{1}=\span\left\{\begin{bmatrix}1\\0\\0\end{bmatrix}\right\}$, $E_{2}=\span\left\{\begin{bmatrix}0\\0\\1\end{bmatrix}\right\}$.

1. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

2. Form $A-\lambda I=\begin{bmatrix}1 - \lambda&1&0\\0&1 - \lambda&0\\0&0&2 - \lambda\end{bmatrix}$.

3. The matrix is triangular, so multiply its three diagonal entries after subtracting $\lambda$:

4. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=\left(2 - \lambda\right) \left(\lambda - 1\right)^{2}=- \lambda^{3} + 4 \lambda^{2} - 5 \lambda + 2.
   $$

5. Eigenspace for $\lambda=1$ (algebraic multiplicity 2): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

6. Row-reduce the homogeneous system: start with $A-(1)I=\begin{bmatrix}0&1&0\\0&0&0\\0&0&1\end{bmatrix}$.

7. Swap rows 2 and 3 to place a nonzero pivot or reorder the equations.

   $$
   \xrightarrow{R_{2}\leftrightarrow R_{3}}\begin{bmatrix}0&1&0\\0&0&1\\0&0&0\end{bmatrix}
   $$

8. The pivot columns are 2, 3; the free variable is $x_1$.

9. The pivot equations give $x_2=0$, $x_3=0$.

10. The resulting basis is $\left\{\begin{bmatrix}1\\0\\0\end{bmatrix}\right\}$.

11. Hence $\dim E_{1}=1$.

12. Eigenspace for $\lambda=2$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

13. Row-reduce the homogeneous system: start with $A-(2)I=\begin{bmatrix}-1&1&0\\0&-1&0\\0&0&0\end{bmatrix}$.

14. Multiply row 1 by $-1$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (-1)R_{1}}\begin{bmatrix}1&-1&0\\0&-1&0\\0&0&0\end{bmatrix}
   $$

15. Multiply row 2 by $-1$ to normalize its leading entry.

   $$
   \xrightarrow{R_{2}\leftarrow (-1)R_{2}}\begin{bmatrix}1&-1&0\\0&1&0\\0&0&0\end{bmatrix}
   $$

16. Replace row 1 by itself plus $1$ times row 2 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{1}\leftarrow R_{1} + (1)R_{2}}\begin{bmatrix}1&0&0\\0&1&0\\0&0&0\end{bmatrix}
   $$

17. The pivot columns are 1, 2; the free variable is $x_3$.

18. The pivot equations give $x_1=0$, $x_2=0$.

19. The resulting basis is $\left\{\begin{bmatrix}0\\0\\1\end{bmatrix}\right\}$.

20. Hence $\dim E_{2}=1$.

21. Check: $A\begin{bmatrix}1\\0\\0\end{bmatrix}=\begin{bmatrix}1\\0\\0\end{bmatrix}=1\begin{bmatrix}1\\0\\0\end{bmatrix}$.

22. Check: $A\begin{bmatrix}0\\0\\1\end{bmatrix}=\begin{bmatrix}0\\0\\2\end{bmatrix}=2\begin{bmatrix}0\\0\\1\end{bmatrix}$.
::::

:::


### Practice problems: Roots, trace, and determinant

:::problem[Problem 5.14 — Roots, trace, and determinant]{difficulty=challenge}
For $A=\begin{bmatrix}2&1&0\\1&2&0\\1&0&4\end{bmatrix}$, find characteristic roots and eigenspaces and check trace and determinant.

::::solution[Solution]
**Answer:** Eigenvalues $1$, $3$, $4$.  Eigenspace bases: $E_{1}=\span\left\{\begin{bmatrix}-3\\3\\1\end{bmatrix}\right\}$, $E_{3}=\span\left\{\begin{bmatrix}-1\\-1\\1\end{bmatrix}\right\}$, $E_{4}=\span\left\{\begin{bmatrix}0\\0\\1\end{bmatrix}\right\}$.

1. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

2. Form $A-\lambda I=\begin{bmatrix}2 - \lambda&1&0\\1&2 - \lambda&0\\1&0&4 - \lambda\end{bmatrix}$.

3. Expand along column 3, which has the most zeros (ties favor columns).

4. The cofactor signs alternate $+,-,+$ across the first row.

5. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=(4 - \lambda)\left[(2 - \lambda)(2 - \lambda)-(1)(1)\right]
   $$

6. Expand, simplify, and factor the preceding expression.

   $$
   =- \lambda^{3} + 8 \lambda^{2} - 19 \lambda + 12=- \left(\lambda - 4\right) \left(\lambda - 3\right) \left(\lambda - 1\right).
   $$

7. Eigenspace for $\lambda=1$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

8. Row-reduce the homogeneous system: start with $A-(1)I=\begin{bmatrix}1&1&0\\1&1&0\\1&0&3\end{bmatrix}$.

9. Replace row 2 by itself plus $-1$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (-1)R_{1}}\begin{bmatrix}1&1&0\\0&0&0\\1&0&3\end{bmatrix}
   $$

10. Replace row 3 by itself plus $-1$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{3}\leftarrow R_{3} + (-1)R_{1}}\begin{bmatrix}1&1&0\\0&0&0\\0&-1&3\end{bmatrix}
   $$

11. Swap rows 2 and 3 to place a nonzero pivot or reorder the equations.

   $$
   \xrightarrow{R_{2}\leftrightarrow R_{3}}\begin{bmatrix}1&1&0\\0&-1&3\\0&0&0\end{bmatrix}
   $$

12. Multiply row 2 by $-1$ to normalize its leading entry.

   $$
   \xrightarrow{R_{2}\leftarrow (-1)R_{2}}\begin{bmatrix}1&1&0\\0&1&-3\\0&0&0\end{bmatrix}
   $$

13. Replace row 1 by itself plus $-1$ times row 2 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{1}\leftarrow R_{1} + (-1)R_{2}}\begin{bmatrix}1&0&3\\0&1&-3\\0&0&0\end{bmatrix}
   $$

14. The pivot columns are 1, 2; the free variable is $x_3$.

15. The pivot equations give $x_1=- 3 x_{3}$, $x_2=3 x_{3}$.

16. The resulting basis is $\left\{\begin{bmatrix}-3\\3\\1\end{bmatrix}\right\}$.

17. Hence $\dim E_{1}=1$.

18. Eigenspace for $\lambda=3$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

19. Row-reduce the homogeneous system: start with $A-(3)I=\begin{bmatrix}-1&1&0\\1&-1&0\\1&0&1\end{bmatrix}$.

20. Multiply row 1 by $-1$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (-1)R_{1}}\begin{bmatrix}1&-1&0\\1&-1&0\\1&0&1\end{bmatrix}
   $$

21. Replace row 2 by itself plus $-1$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (-1)R_{1}}\begin{bmatrix}1&-1&0\\0&0&0\\1&0&1\end{bmatrix}
   $$

22. Replace row 3 by itself plus $-1$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{3}\leftarrow R_{3} + (-1)R_{1}}\begin{bmatrix}1&-1&0\\0&0&0\\0&1&1\end{bmatrix}
   $$

23. Swap rows 2 and 3 to place a nonzero pivot or reorder the equations.

   $$
   \xrightarrow{R_{2}\leftrightarrow R_{3}}\begin{bmatrix}1&-1&0\\0&1&1\\0&0&0\end{bmatrix}
   $$

24. Replace row 1 by itself plus $1$ times row 2 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{1}\leftarrow R_{1} + (1)R_{2}}\begin{bmatrix}1&0&1\\0&1&1\\0&0&0\end{bmatrix}
   $$

25. The pivot columns are 1, 2; the free variable is $x_3$.

26. The pivot equations give $x_1=- x_{3}$, $x_2=- x_{3}$.

27. The resulting basis is $\left\{\begin{bmatrix}-1\\-1\\1\end{bmatrix}\right\}$.

28. Hence $\dim E_{3}=1$.

29. Eigenspace for $\lambda=4$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

30. Row-reduce the homogeneous system: start with $A-(4)I=\begin{bmatrix}-2&1&0\\1&-2&0\\1&0&0\end{bmatrix}$.

31. Multiply row 1 by $- \frac{1}{2}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (- \frac{1}{2})R_{1}}\begin{bmatrix}1&- \frac{1}{2}&0\\1&-2&0\\1&0&0\end{bmatrix}
   $$

32. Replace row 2 by itself plus $-1$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (-1)R_{1}}\begin{bmatrix}1&- \frac{1}{2}&0\\0&- \frac{3}{2}&0\\1&0&0\end{bmatrix}
   $$

33. Replace row 3 by itself plus $-1$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{3}\leftarrow R_{3} + (-1)R_{1}}\begin{bmatrix}1&- \frac{1}{2}&0\\0&- \frac{3}{2}&0\\0&\frac{1}{2}&0\end{bmatrix}
   $$

34. Multiply row 2 by $- \frac{2}{3}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{2}\leftarrow (- \frac{2}{3})R_{2}}\begin{bmatrix}1&- \frac{1}{2}&0\\0&1&0\\0&\frac{1}{2}&0\end{bmatrix}
   $$

35. Replace row 1 by itself plus $\frac{1}{2}$ times row 2 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{1}\leftarrow R_{1} + (\frac{1}{2})R_{2}}\begin{bmatrix}1&0&0\\0&1&0\\0&\frac{1}{2}&0\end{bmatrix}
   $$

36. Replace row 3 by itself plus $- \frac{1}{2}$ times row 2 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{3}\leftarrow R_{3} + (- \frac{1}{2})R_{2}}\begin{bmatrix}1&0&0\\0&1&0\\0&0&0\end{bmatrix}
   $$

37. The pivot columns are 1, 2; the free variable is $x_3$.

38. The pivot equations give $x_1=0$, $x_2=0$.

39. The resulting basis is $\left\{\begin{bmatrix}0\\0\\1\end{bmatrix}\right\}$.

40. Hence $\dim E_{4}=1$.

41. Check: $A\begin{bmatrix}-3\\3\\1\end{bmatrix}=\begin{bmatrix}-3\\3\\1\end{bmatrix}=1\begin{bmatrix}-3\\3\\1\end{bmatrix}$.

42. Check: $A\begin{bmatrix}-1\\-1\\1\end{bmatrix}=\begin{bmatrix}-3\\-3\\3\end{bmatrix}=3\begin{bmatrix}-1\\-1\\1\end{bmatrix}$.

43. Check: $A\begin{bmatrix}0\\0\\1\end{bmatrix}=\begin{bmatrix}0\\0\\4\end{bmatrix}=4\begin{bmatrix}0\\0\\1\end{bmatrix}$.
::::

:::

## 5.3 Diagonalization


:::callout-intuition[Intuition]
A diagonal matrix is trivial to work with: raising it to a power just raises each diagonal entry to that power. **Diagonalization** is the process of rewriting $A=PDP^{-1}$ so we can leverage this simplicity. The columns of $P$ are eigenvectors; the diagonal of $D$ contains the corresponding eigenvalues. This is the most important computational tool of this chapter.

In the standard coordinates, a matrix may mix coordinates. In coordinates measured along its eigenvectors, each coordinate merely gets multiplied by its eigenvalue. The change-of-basis matrix $P$ records those eigenvector directions, and $D$ records their multipliers. If you cannot find enough independent directions, the change of basis cannot be built.
:::

:::callout-tip[Written-exam decision tree]
Find eigenvalues with algebraic multiplicity. For each eigenvalue, row-reduce $A-\lambda I$, count free variables and write a basis. If the sum of eigenspace dimensions is $n$, put those vectors into $P$ and the **matching** eigenvalues into $D$. Check $AP=PD$ before calculating $P^{-1}$. If a repeated eigenvalue of algebraic multiplicity two gives only one free variable, stop and say it is not diagonalizable. Do not 'fix' it by choosing a second vector outside the eigenspace.
:::

:::theorem[Power formula and inverse formula]
If $A=PDP^{-1}$, then $A^k=PD^kP^{-1}$ for nonnegative integers $k$. If no eigenvalue is zero, $A^{-1}=PD^{-1}P^{-1}$. **Cancellation is adjacent:** $(PDP^{-1})(PDP^{-1})=PD(P^{-1}P)DP^{-1}=PD^2P^{-1}$.
:::

:::theorem[Theorem 5.4 — The Diagonalization Theorem]
An $n\times n$ matrix $A$ is **diagonalizable** if and only if $A$ has $n$ linearly independent eigenvectors. If so:

$$
A = PDP^{-1}
$$

where $D$ is a diagonal matrix whose diagonal entries are eigenvalues of $A$, and $P$ is the matrix whose columns are the corresponding eigenvectors.
:::

:::theorem[Theorem 5.5 — $n$ Distinct Eigenvalues Implies Diagonalizable]
If an $n\times n$ matrix has $n$ *distinct* eigenvalues, then it is diagonalizable.
:::

:::theorem[Theorem 5.6 — Geometric vs. Algebraic Multiplicity Test]
$A$ is diagonalizable if and only if for each eigenvalue $\lambda$:

$$
\dim E_\lambda = \text{algebraic multiplicity of }\lambda
$$

Equivalently: the sum of the dimensions of all eigenspaces equals $n$.
:::

### Diagonalization Procedure

:::callout-key[Step-by-Step: How to Diagonalize $A$]
1. Find all eigenvalues: solve $\det(A-\lambda I)=0$.
2. For each eigenvalue, find a basis for the eigenspace $E_\lambda=\Nul(A-\lambda I)$.
3. Check: if total number of independent eigenvectors $=n$, proceed.
4. Form $P$ = [eigenvectors as columns] and $D$ = diagonal matrix of corresponding eigenvalues (same order).
5. Verify: $AP = PD$ (spot-check one column).
:::

<figure class="fig">
<svg class="fig-hue-3" viewBox="0 0 440 240" role="img" aria-label="A lattice grid stretches horizontally and compresses vertically under a diagonal matrix.">
<line class="fig-axis" x1="31.0" y1="132.0" x2="409.0" y2="132.0"/><line class="fig-axis" x1="220.0" y1="241.2" x2="220.0" y2="22.8"/><line class="fig-gridline" x1="136.0" y1="216.0" x2="136.0" y2="48.0"/><line class="fig-gridline" x1="136.0" y1="216.0" x2="304.0" y2="216.0"/><line class="fig-gridline" x1="178.0" y1="216.0" x2="178.0" y2="48.0"/><line class="fig-gridline" x1="136.0" y1="174.0" x2="304.0" y2="174.0"/><line class="fig-gridline" x1="220.0" y1="216.0" x2="220.0" y2="48.0"/><line class="fig-gridline" x1="136.0" y1="132.0" x2="304.0" y2="132.0"/><line class="fig-gridline" x1="262.0" y1="216.0" x2="262.0" y2="48.0"/><line class="fig-gridline" x1="136.0" y1="90.0" x2="304.0" y2="90.0"/><line class="fig-gridline" x1="304.0" y1="216.0" x2="304.0" y2="48.0"/><line class="fig-gridline" x1="136.0" y1="48.0" x2="304.0" y2="48.0"/><line class="fig-guide" x1="52.0" y1="174.0" x2="52.0" y2="90.0"/><line class="fig-guide" x1="136.0" y1="174.0" x2="136.0" y2="90.0"/><line class="fig-guide" x1="220.0" y1="174.0" x2="220.0" y2="90.0"/><line class="fig-guide" x1="304.0" y1="174.0" x2="304.0" y2="90.0"/><line class="fig-guide" x1="388.0" y1="174.0" x2="388.0" y2="90.0"/><line class="fig-guide" x1="52.0" y1="174.0" x2="388.0" y2="174.0"/><line class="fig-guide" x1="52.0" y1="153.0" x2="388.0" y2="153.0"/><line class="fig-guide" x1="52.0" y1="132.0" x2="388.0" y2="132.0"/><line class="fig-guide" x1="52.0" y1="111.0" x2="388.0" y2="111.0"/><line class="fig-guide" x1="52.0" y1="90.0" x2="388.0" y2="90.0"/><line class="fig-curve" x1="220.0" y1="132.0" x2="262.0" y2="132.0"/><path class="fig-arrow" d="M253.0 128.0 L262.0 132.0 L253.0 136.0"/><line class="fig-curve-alt" x1="220.0" y1="132.0" x2="304.0" y2="132.0"/><path class="fig-arrow" d="M295.0 128.0 L304.0 132.0 L295.0 136.0"/><line class="fig-curve" x1="220.0" y1="132.0" x2="220.0" y2="90.0"/><path class="fig-arrow" d="M216.0 99.0 L220.0 90.0 L224.0 99.0"/><line class="fig-curve-alt" x1="220.0" y1="132.0" x2="220.0" y2="111.0"/><path class="fig-arrow" d="M216.0 120.0 L220.0 111.0 L224.0 120.0"/><text class="fig-label" x="308.2" y="119.4">2u</text><text class="fig-label" x="225.5" y="96.3">v</text>
</svg>
<figcaption>In eigenvector coordinates, $D=\operatorname{diag}(2,1/2)$ stretches the $u$-direction by $2$ and compresses the $v$-direction by $1/2$. The original grid (solid) becomes the transformed grid (dashed).</figcaption>
</figure>

:::example[Example 5.9 — Diagonalizing a $3\times 3$ Matrix]
Diagonalize $A=\begin{bmatrix}1&3&3\\-3&-5&-3\\3&3&1\end{bmatrix}$ if possible.

::::answer[Answer]
**Answer:** The matrix is diagonalizable: $P=\begin{bmatrix}-1&-1&1\\1&0&-1\\0&1&1\end{bmatrix}$ and $D=\operatorname{diag}(-2,-2,1)$.

1. **Step 1 — Characteristic polynomial:**

2. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=-(\lambda+2)^2(\lambda-1)
   $$

3. Eigenvalues: $\lambda_1=-2$ (algebraic mult. 2), $\lambda_2=1$ (mult. 1).

4. **Step 2 — Eigenspace for $\lambda_1=-2$:**

5. Evaluate the displayed calculation.

   $$
   A+2I=\begin{bmatrix}3&3&3\\-3&-3&-3\\3&3&3\end{bmatrix}\to\begin{bmatrix}1&1&1\\0&0&0\\0&0&0\end{bmatrix}
   $$

6. Free variables $x_2, x_3$.

7. Basis: $\mathbf{v}_1=\begin{bmatrix}-1\\1\\0\end{bmatrix}, \mathbf{v}_2=\begin{bmatrix}-1\\0\\1\end{bmatrix}$.

8. Geometric mult. = 2 = algebraic mult. ✓

9. **Step 3 — Eigenspace for $\lambda_2=1$:**

10. Evaluate the displayed calculation.

   $$
   A-I=\begin{bmatrix}0&3&3\\-3&-6&-3\\3&3&0\end{bmatrix}\to\begin{bmatrix}1&0&-1\\0&1&1\\0&0&0\end{bmatrix}
   $$

11. Free var $x_3$.

12. Basis: $\mathbf{v}_3=\begin{bmatrix}1\\-1\\1\end{bmatrix}$.

13. **Result:** $A=PDP^{-1}$ where

14. Evaluate the displayed calculation.

   $$
   P=\begin{bmatrix}-1&-1&1\\1&0&-1\\0&1&1\end{bmatrix},\quad D=\begin{bmatrix}-2&0&0\\0&-2&0\\0&0&1\end{bmatrix}
   $$
::::

:::

:::example[Example 5.10 — A Non-Diagonalizable Matrix]
Show $A=\begin{bmatrix}2&1\\0&2\end{bmatrix}$ is not diagonalizable.

::::answer[Answer]
**Answer:** Not diagonalizable, because $\lambda=2$ has algebraic multiplicity two but eigenspace dimension one.

1. Characteristic polynomial: $(2-\lambda)^2=0$, so $\lambda=2$ with algebraic mult. 2.

2. Eigenspace: $A-2I=\begin{bmatrix}0&1\\0&0\end{bmatrix}$.

3. Only one free variable: $\dim E_2=1$.

4. Since geometric multiplicity (1) $<$ algebraic multiplicity (2), $A$ is **not diagonalizable**.

5. We cannot find 2 independent eigenvectors.
::::

:::

:::callout-key[Powers of $A$ via Diagonalization]
If $A=PDP^{-1}$, then $A^k = PD^kP^{-1}$, and $D^k=\text{diag}(\lambda_1^k,\ldots,\lambda_n^k)$. This makes computing large powers of matrices trivial.
:::

<figure class="fig">
<svg class="fig-hue-4" viewBox="0 0 440 240" role="img" aria-label="Normalized iterates approach the horizontal dominant eigenvector.">
<line class="fig-axis" x1="75.9" y1="183.0" x2="301.5" y2="183.0"/><line class="fig-axis" x1="90.0" y1="192.4" x2="90.0" y2="-5.0"/><line class="fig-curve" x1="90.0" y1="183.0" x2="137.0" y2="89.0"/><path class="fig-arrow" d="M129.4 95.3 L137.0 89.0 L136.6 98.8"/><text class="fig-label" x="141.7" y="80.5">k=0</text><line class="fig-curve-alt" x1="90.0" y1="183.0" x2="137.0" y2="159.5"/><path class="fig-arrow" d="M127.2 159.9 L137.0 159.5 L130.7 167.1"/><text class="fig-label" x="141.7" y="151.0">k=1</text><line class="fig-curve-alt" x1="90.0" y1="183.0" x2="137.0" y2="177.1"/><path class="fig-arrow" d="M127.6 174.3 L137.0 177.1 L128.6 182.2"/><text class="fig-label" x="141.7" y="168.7">k=2</text><line class="fig-curve-alt" x1="90.0" y1="183.0" x2="137.0" y2="181.5"/><path class="fig-arrow" d="M127.9 177.8 L137.0 181.5 L128.1 185.8"/><text class="fig-label" x="141.7" y="173.1">k=3</text><line class="fig-guide" x1="90.0" y1="183.0" x2="254.5" y2="183.0"/><path class="fig-arrow" d="M245.5 179.0 L254.5 183.0 L245.5 187.0"/>
</svg>
<figcaption>For $D=\operatorname{diag}(2,1/2)$ and $x_0=(1,2)^T$, the normalized vectors $2^{-k}D^kx_0=(1,2(1/4)^k)^T$ approach the dominant eigendirection $E_2$. Normalization removes growth so the change in direction is visible.</figcaption>
</figure>


### Worked examples: Computing $A^{10}$

:::example[Example 5.11 — Computing $A^{10}$]
Given $A=\begin{bmatrix}3&1\\0&1\end{bmatrix}$, find $A^{10}$.

::::answer[Answer]
**Answer:** $A^{10}=\begin{bmatrix}59049&29524\\0&1\end{bmatrix}$.

1. Find the eigenvalues $3$ and $1$. For $\lambda=3$, $(A-3I)v=0$ gives $v_1=(1,0)^T$.

2. For $\lambda=1$, solve $(A-I)v=0$ with $A-I=\begin{bmatrix}2&1\\0&0\end{bmatrix}$. The equation $2x+y=0$ gives $v_2=(1,-2)^T$.

3. Put the eigenvectors in columns: $P=\begin{bmatrix}1&1\\0&-2\end{bmatrix}$, $D=\operatorname{diag}(3,1)$, and $\det P=-2\ne0$.

4. For the inverse, $P^{-1}=\frac1{-2}\begin{bmatrix}-2&-1\\0&1\end{bmatrix}=\begin{bmatrix}1&1/2\\0&-1/2\end{bmatrix}$.

5. Use $A^{10}=PD^{10}P^{-1}$; $D^{10}=\operatorname{diag}(3^{10},1)$.

6. Compute powers by hand: $3^2=9$, $3^4=9^2=81$, $3^8=81^2=6561$, and $3^{10}=6561(9)=59049$.

7. Multiply the first two matrices: $PD^{10}=\begin{bmatrix}59049&1\\0&-2\end{bmatrix}$.

8. Multiply by $P^{-1}$: $\begin{bmatrix}59049&1\\0&-2\end{bmatrix}\begin{bmatrix}1&1/2\\0&-1/2\end{bmatrix}=\begin{bmatrix}59049&(59049-1)/2\\0&1\end{bmatrix}$.

9. Simplify $(59049-1)/2=59048/2=29524$. Check: for $k=1$, the same formula gives $PDP^{-1}=A$.
::::

:::


:::example[Example 5.12 — Fully diagonalize a small two by two]
For $A=\begin{bmatrix}2&1\\1&2\end{bmatrix}$, find the characteristic polynomial, both eigenspaces, and build a diagonalization.

::::answer[Answer]
**Answer:** $P=\begin{bmatrix}-1&1\\1&1\end{bmatrix}$, $D=\begin{bmatrix}1&0\\0&3\end{bmatrix}$; Eigenvalues $1$, $3$.  Eigenspace bases: $E_{1}=\span\left\{\begin{bmatrix}-1\\1\end{bmatrix}\right\}$, $E_{3}=\span\left\{\begin{bmatrix}1\\1\end{bmatrix}\right\}$.

1. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

2. Form $A-\lambda I=\begin{bmatrix}2 - \lambda&1\\1&2 - \lambda\end{bmatrix}$.

3. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=(2-\lambda)(2-\lambda)-(1)(1)
   $$

4. Expand, simplify, and factor the preceding expression.

   $$
   =\lambda^{2} - 4 \lambda + 3=\left(\lambda - 3\right) \left(\lambda - 1\right).
   $$

5. Eigenspace for $\lambda=1$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

6. Row-reduce the homogeneous system: start with $A-(1)I=\begin{bmatrix}1&1\\1&1\end{bmatrix}$.

7. Replace row 2 by itself plus $-1$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (-1)R_{1}}\begin{bmatrix}1&1\\0&0\end{bmatrix}
   $$

8. The pivot columns are 1; the free variable is $x_2$.

9. The pivot equations give $x_1=- x_{2}$.

10. Choose one free variable at a time and set the others to zero.

11. Clear fractions where necessary.

12. The resulting basis is $\left\{\begin{bmatrix}-1\\1\end{bmatrix}\right\}$.

13. Hence $\dim E_{1}=1$.

14. Eigenspace for $\lambda=3$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

15. Row-reduce the homogeneous system: start with $A-(3)I=\begin{bmatrix}-1&1\\1&-1\end{bmatrix}$.

16. Multiply row 1 by $-1$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (-1)R_{1}}\begin{bmatrix}1&-1\\1&-1\end{bmatrix}
   $$

17. Replace row 2 by itself plus $-1$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (-1)R_{1}}\begin{bmatrix}1&-1\\0&0\end{bmatrix}
   $$

18. The pivot columns are 1; the free variable is $x_2$.

19. The pivot equations give $x_1=x_{2}$.

20. Choose one free variable at a time and set the others to zero.

21. Clear fractions where necessary.

22. The resulting basis is $\left\{\begin{bmatrix}1\\1\end{bmatrix}\right\}$.

23. Hence $\dim E_{3}=1$.

24. The roots of the factored polynomial are $\lambda=3$ (algebraic multiplicity 1), $\lambda=1$ (algebraic multiplicity 1).

25. **Diagonalization:** the eigenspace bases give $P=\begin{bmatrix}-1&1\\1&1\end{bmatrix}$ and $D=\begin{bmatrix}1&0\\0&3\end{bmatrix}$.

26. Check $AP=\begin{bmatrix}-1&3\\1&3\end{bmatrix}=PD$.

27. Since $\det P=-2\ne0$, $P$ is invertible, and $A=PDP^{-1}$.

28. Check: $A\begin{bmatrix}-1\\1\end{bmatrix}=\begin{bmatrix}-1\\1\end{bmatrix}=1\begin{bmatrix}-1\\1\end{bmatrix}$.

29. Check: $A\begin{bmatrix}1\\1\end{bmatrix}=\begin{bmatrix}3\\3\end{bmatrix}=3\begin{bmatrix}1\\1\end{bmatrix}$.
::::

:::

:::example[Example 5.13 — Repeated eigenvalue, but still diagonalizable]
For $A=\begin{bmatrix}3&0&0\\0&3&0\\0&0&1\end{bmatrix}$, find all eigenspaces and decide whether the repeated eigenvalue prevents diagonalization.

::::answer[Answer]
**Answer:** $P=\begin{bmatrix}0&1&0\\0&0&1\\1&0&0\end{bmatrix}$, $D=\begin{bmatrix}1&0&0\\0&3&0\\0&0&3\end{bmatrix}$; Eigenvalues $1$, $3$.  Eigenspace bases: $E_{1}=\span\left\{\begin{bmatrix}0\\0\\1\end{bmatrix}\right\}$, $E_{3}=\span\left\{\begin{bmatrix}1\\0\\0\end{bmatrix}, \begin{bmatrix}0\\1\\0\end{bmatrix}\right\}$.

1. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

2. Form $A-\lambda I=\begin{bmatrix}3 - \lambda&0&0\\0&3 - \lambda&0\\0&0&1 - \lambda\end{bmatrix}$.

3. The matrix is triangular, so multiply its three diagonal entries after subtracting $\lambda$:

4. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=\left(1 - \lambda\right) \left(\lambda - 3\right)^{2}=- \lambda^{3} + 7 \lambda^{2} - 15 \lambda + 9.
   $$

5. Eigenspace for $\lambda=1$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

6. Row-reduce the homogeneous system: start with $A-(1)I=\begin{bmatrix}2&0&0\\0&2&0\\0&0&0\end{bmatrix}$.

7. Multiply row 1 by $\frac{1}{2}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (\frac{1}{2})R_{1}}\begin{bmatrix}1&0&0\\0&2&0\\0&0&0\end{bmatrix}
   $$

8. Multiply row 2 by $\frac{1}{2}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{2}\leftarrow (\frac{1}{2})R_{2}}\begin{bmatrix}1&0&0\\0&1&0\\0&0&0\end{bmatrix}
   $$

9. The pivot columns are 1, 2; the free variable is $x_3$.

10. The pivot equations give $x_1=0$, $x_2=0$.

11. Choose one free variable at a time and set the others to zero.

12. Clear fractions where necessary.

13. The resulting basis is $\left\{\begin{bmatrix}0\\0\\1\end{bmatrix}\right\}$.

14. Hence $\dim E_{1}=1$.

15. Eigenspace for $\lambda=3$ (algebraic multiplicity 2): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

16. Row-reduce the homogeneous system: start with $A-(3)I=\begin{bmatrix}0&0&0\\0&0&0\\0&0&-2\end{bmatrix}$.

17. Swap rows 1 and 3 to place a nonzero pivot or reorder the equations.

   $$
   \xrightarrow{R_{1}\leftrightarrow R_{3}}\begin{bmatrix}0&0&-2\\0&0&0\\0&0&0\end{bmatrix}
   $$

18. Multiply row 1 by $- \frac{1}{2}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (- \frac{1}{2})R_{1}}\begin{bmatrix}0&0&1\\0&0&0\\0&0&0\end{bmatrix}
   $$

19. The pivot columns are 3; the free variables are $x_1$, $x_2$.

20. The pivot equations give $x_3=0$.

21. Choose one free variable at a time and set the others to zero.

22. Clear fractions where necessary.

23. The resulting basis is $\left\{\begin{bmatrix}1\\0\\0\end{bmatrix},\;\begin{bmatrix}0\\1\\0\end{bmatrix}\right\}$.

24. Hence $\dim E_{3}=2$.

25. The roots of the factored polynomial are $\lambda=1$ (algebraic multiplicity 1), $\lambda=3$ (algebraic multiplicity 2).

26. **Diagonalization:** the eigenspace bases give $P=\begin{bmatrix}0&1&0\\0&0&1\\1&0&0\end{bmatrix}$ and $D=\begin{bmatrix}1&0&0\\0&3&0\\0&0&3\end{bmatrix}$.

27. Check $AP=\begin{bmatrix}0&3&0\\0&0&3\\1&0&0\end{bmatrix}=PD$.

28. Since $\det P=1\ne0$, $P$ is invertible, and $A=PDP^{-1}$.

29. Check: $A\begin{bmatrix}0\\0\\1\end{bmatrix}=\begin{bmatrix}0\\0\\1\end{bmatrix}=1\begin{bmatrix}0\\0\\1\end{bmatrix}$.

30. Check: $A\begin{bmatrix}1\\0\\0\end{bmatrix}=\begin{bmatrix}3\\0\\0\end{bmatrix}=3\begin{bmatrix}1\\0\\0\end{bmatrix}$.

31. Check: $A\begin{bmatrix}0\\1\\0\end{bmatrix}=\begin{bmatrix}0\\3\\0\end{bmatrix}=3\begin{bmatrix}0\\1\\0\end{bmatrix}$.
::::

:::

:::callout-pitfall[Pitfalls in §5.3]
(1) Misaligning the columns of $P$ with the diagonal entries of $D$. (2) Assuming a repeated eigenvalue automatically prevents diagonalization, or assuming that it guarantees it. (3) Trying $A^k=P^kD^k(P^{-1})^k$, which is generally false.
:::


### Practice problems: Diagonalization and fifth power

:::problem[Problem 5.15 — Diagonalization and fifth power]{difficulty=standard}
Diagonalize $A=\begin{bmatrix}4&-1\\2&1\end{bmatrix}$ or state why it is not diagonalizable. Then compute $A^5$.

::::solution[Solution]
**Answer:** $A$ is diagonalizable with eigenvalues $2,3$; $A^5=\begin{bmatrix}454&-211\\422&-179\end{bmatrix}$.

1. Char. poly: $(4-\lambda)(1-\lambda)+2=\lambda^2-5\lambda+6=(\lambda-2)(\lambda-3)$.

2. Eigenvalues: $\lambda_1=2, \lambda_2=3$ (distinct $\Rightarrow$ diagonalizable).

3. $E_2$: $A-2I=\begin{bmatrix}2&-1\\2&-1\end{bmatrix}\to\begin{bmatrix}2&-1\\0&0\end{bmatrix}$.

4. $\mathbf{v}_1=\begin{bmatrix}1\\2\end{bmatrix}$.

5. $E_3$: $A-3I=\begin{bmatrix}1&-1\\2&-2\end{bmatrix}\to\begin{bmatrix}1&-1\\0&0\end{bmatrix}$.

6. $\mathbf{v}_2=\begin{bmatrix}1\\1\end{bmatrix}$.

7. $P=\begin{bmatrix}1&1\\2&1\end{bmatrix}$, $D=\begin{bmatrix}2&0\\0&3\end{bmatrix}$, $P^{-1}=\begin{bmatrix}-1&1\\2&-1\end{bmatrix}$.

8. $A^5=PD^5P^{-1}=\begin{bmatrix}1&1\\2&1\end{bmatrix}\begin{bmatrix}32&0\\0&243\end{bmatrix}\begin{bmatrix}-1&1\\2&-1\end{bmatrix}=\begin{bmatrix}454&-211\\422&-179\end{bmatrix}$.

9. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

10. Form $A-\lambda I=\begin{bmatrix}4 - \lambda&-1\\2&1 - \lambda\end{bmatrix}$.

11. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=(4-\lambda)(1-\lambda)-(-1)(2)
   $$

12. Expand, simplify, and factor the preceding expression.

   $$
   =\lambda^{2} - 5 \lambda + 6=\left(\lambda - 3\right) \left(\lambda - 2\right).
   $$

13. Eigenspace for $\lambda=2$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

14. Row-reduce the homogeneous system: start with $A-(2)I=\begin{bmatrix}2&-1\\2&-1\end{bmatrix}$.

15. Multiply row 1 by $\frac{1}{2}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (\frac{1}{2})R_{1}}\begin{bmatrix}1&- \frac{1}{2}\\2&-1\end{bmatrix}
   $$

16. Replace row 2 by itself plus $-2$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (-2)R_{1}}\begin{bmatrix}1&- \frac{1}{2}\\0&0\end{bmatrix}
   $$

17. The pivot columns are 1; the free variable is $x_2$.

18. The pivot equations give $x_1=\frac{x_{2}}{2}$.

19. Choose one free variable at a time and set the others to zero.

20. Clear fractions where necessary.

21. The resulting basis is $\left\{\begin{bmatrix}1\\2\end{bmatrix}\right\}$.

22. Hence $\dim E_{2}=1$.

23. Eigenspace for $\lambda=3$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

24. Row-reduce the homogeneous system: start with $A-(3)I=\begin{bmatrix}1&-1\\2&-2\end{bmatrix}$.

25. Replace row 2 by itself plus $-2$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (-2)R_{1}}\begin{bmatrix}1&-1\\0&0\end{bmatrix}
   $$

26. The pivot columns are 1; the free variable is $x_2$.

27. The pivot equations give $x_1=x_{2}$.

28. Choose one free variable at a time and set the others to zero.

29. Clear fractions where necessary.

30. The resulting basis is $\left\{\begin{bmatrix}1\\1\end{bmatrix}\right\}$.

31. Hence $\dim E_{3}=1$.

32. The roots of the factored polynomial are $\lambda=3$ (algebraic multiplicity 1), $\lambda=2$ (algebraic multiplicity 1).

33. Check: $A\begin{bmatrix}1\\2\end{bmatrix}=\begin{bmatrix}2\\4\end{bmatrix}=2\begin{bmatrix}1\\2\end{bmatrix}$.

34. Check: $A\begin{bmatrix}1\\1\end{bmatrix}=\begin{bmatrix}3\\3\end{bmatrix}=3\begin{bmatrix}1\\1\end{bmatrix}$.
::::

:::

:::problem[Problem 5.16 — Multiplicity obstruction]{difficulty=challenge}
A $4\times 4$ matrix has eigenvalues $\lambda=2$ (alg. mult. 3) and $\lambda=5$ (alg. mult. 1). If $\dim E_2=2$, is $A$ diagonalizable?

::::solution[Solution]
**Answer:** Not diagonalizable: $\dim E_2=2<3$ (algebraic multiplicity).

1. Use the diagonalization test: an $n\times n$ matrix needs $n$ linearly independent eigenvectors, so the geometric multiplicities must add to $n$.
2. For $\lambda=2$, the problem gives algebraic multiplicity $3$ but $\dim E_2=2$. Thus this eigenvalue supplies only two independent eigenvectors rather than three.
3. For $\lambda=5$, algebraic multiplicity $1$ means its geometric multiplicity is exactly $1$, so it supplies one independent eigenvector.
4. Add the available independent eigenvectors: $\dim E_2+\dim E_5=2+1=3$. Since $3<4$, no eigenvector matrix with four independent columns can be formed.
**Check:** The algebraic multiplicities total $3+1=4$, but the geometric multiplicities total only $3$. Hence $A$ is not diagonalizable.
::::

:::

:::problem[Problem 5.17 — Diagonalization of a diagonal matrix]{difficulty=easy}
For $A=\begin{bmatrix}1&0\\0&4\end{bmatrix}$, exhibit P and D for an obvious diagonalization.

::::solution[Solution]
**Answer:** $P=\begin{bmatrix}1&0\\0&1\end{bmatrix}$, $D=\begin{bmatrix}1&0\\0&4\end{bmatrix}$; Eigenvalues $1$, $4$.  Eigenspace bases: $E_{1}=\span\left\{\begin{bmatrix}1\\0\end{bmatrix}\right\}$, $E_{4}=\span\left\{\begin{bmatrix}0\\1\end{bmatrix}\right\}$.

1. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

2. Form $A-\lambda I=\begin{bmatrix}1 - \lambda&0\\0&4 - \lambda\end{bmatrix}$.

3. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=(1-\lambda)(4-\lambda)-(0)(0)
   $$

4. Expand, simplify, and factor the preceding expression.

   $$
   =\lambda^{2} - 5 \lambda + 4=\left(\lambda - 4\right) \left(\lambda - 1\right).
   $$

5. Eigenspace for $\lambda=1$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

6. Row-reduce the homogeneous system: start with $A-(1)I=\begin{bmatrix}0&0\\0&3\end{bmatrix}$.

7. Swap rows 1 and 2 to place a nonzero pivot or reorder the equations.

   $$
   \xrightarrow{R_{1}\leftrightarrow R_{2}}\begin{bmatrix}0&3\\0&0\end{bmatrix}
   $$

8. Multiply row 1 by $\frac{1}{3}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (\frac{1}{3})R_{1}}\begin{bmatrix}0&1\\0&0\end{bmatrix}
   $$

9. The pivot columns are 2; the free variable is $x_1$.

10. The pivot equations give $x_2=0$.

11. Choose one free variable at a time and set the others to zero.

12. Clear fractions where necessary.

13. The resulting basis is $\left\{\begin{bmatrix}1\\0\end{bmatrix}\right\}$.

14. Hence $\dim E_{1}=1$.

15. Eigenspace for $\lambda=4$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

16. Row-reduce the homogeneous system: start with $A-(4)I=\begin{bmatrix}-3&0\\0&0\end{bmatrix}$.

17. Multiply row 1 by $- \frac{1}{3}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (- \frac{1}{3})R_{1}}\begin{bmatrix}1&0\\0&0\end{bmatrix}
   $$

18. The pivot columns are 1; the free variable is $x_2$.

19. The pivot equations give $x_1=0$.

20. Choose one free variable at a time and set the others to zero.

21. Clear fractions where necessary.

22. The resulting basis is $\left\{\begin{bmatrix}0\\1\end{bmatrix}\right\}$.

23. Hence $\dim E_{4}=1$.

24. The roots of the factored polynomial are $\lambda=4$ (algebraic multiplicity 1), $\lambda=1$ (algebraic multiplicity 1).

25. **Diagonalization:** the eigenspace bases give $P=\begin{bmatrix}1&0\\0&1\end{bmatrix}$ and $D=\begin{bmatrix}1&0\\0&4\end{bmatrix}$.

26. Check $AP=\begin{bmatrix}1&0\\0&4\end{bmatrix}=PD$.

27. Since $\det P=1\ne0$, $P$ is invertible, and $A=PDP^{-1}$.

28. Check: $A\begin{bmatrix}1\\0\end{bmatrix}=\begin{bmatrix}1\\0\end{bmatrix}=1\begin{bmatrix}1\\0\end{bmatrix}$.

29. Check: $A\begin{bmatrix}0\\1\end{bmatrix}=\begin{bmatrix}0\\4\end{bmatrix}=4\begin{bmatrix}0\\1\end{bmatrix}$.
::::

:::


### Practice problems: Use diagonalization to square a matrix

:::problem[Problem 5.18 — Use diagonalization to square a matrix]{difficulty=standard}
For $A=\begin{bmatrix}2&1\\1&2\end{bmatrix}$, find a diagonalization and use it for the square.

::::solution[Solution]
**Answer:** $P=\begin{bmatrix}-1&1\\1&1\end{bmatrix}$, $D=\begin{bmatrix}1&0\\0&3\end{bmatrix}$; $A^{2}=\begin{bmatrix}5&4\\4&5\end{bmatrix}$; Eigenvalues $1$, $3$.  Eigenspace bases: $E_{1}=\span\left\{\begin{bmatrix}-1\\1\end{bmatrix}\right\}$, $E_{3}=\span\left\{\begin{bmatrix}1\\1\end{bmatrix}\right\}$.

1. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

2. Form $A-\lambda I=\begin{bmatrix}2 - \lambda&1\\1&2 - \lambda\end{bmatrix}$.

3. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=(2-\lambda)(2-\lambda)-(1)(1)
   $$

4. Expand, simplify, and factor the preceding expression.

   $$
   =\lambda^{2} - 4 \lambda + 3=\left(\lambda - 3\right) \left(\lambda - 1\right).
   $$

5. Eigenspace for $\lambda=1$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

6. Row-reduce the homogeneous system: start with $A-(1)I=\begin{bmatrix}1&1\\1&1\end{bmatrix}$.

7. Replace row 2 by itself plus $-1$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (-1)R_{1}}\begin{bmatrix}1&1\\0&0\end{bmatrix}
   $$

8. The pivot columns are 1; the free variable is $x_2$.

9. The pivot equations give $x_1=- x_{2}$.

10. Choose one free variable at a time and set the others to zero.

11. Clear fractions where necessary.

12. The resulting basis is $\left\{\begin{bmatrix}-1\\1\end{bmatrix}\right\}$.

13. Hence $\dim E_{1}=1$.

14. Eigenspace for $\lambda=3$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

15. Row-reduce the homogeneous system: start with $A-(3)I=\begin{bmatrix}-1&1\\1&-1\end{bmatrix}$.

16. Multiply row 1 by $-1$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (-1)R_{1}}\begin{bmatrix}1&-1\\1&-1\end{bmatrix}
   $$

17. Replace row 2 by itself plus $-1$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (-1)R_{1}}\begin{bmatrix}1&-1\\0&0\end{bmatrix}
   $$

18. The pivot columns are 1; the free variable is $x_2$.

19. The pivot equations give $x_1=x_{2}$.

20. Choose one free variable at a time and set the others to zero.

21. Clear fractions where necessary.

22. The resulting basis is $\left\{\begin{bmatrix}1\\1\end{bmatrix}\right\}$.

23. Hence $\dim E_{3}=1$.

24. The roots of the factored polynomial are $\lambda=3$ (algebraic multiplicity 1), $\lambda=1$ (algebraic multiplicity 1).

25. **Diagonalization:** the eigenspace bases give $P=\begin{bmatrix}-1&1\\1&1\end{bmatrix}$ and $D=\begin{bmatrix}1&0\\0&3\end{bmatrix}$.

26. Check $AP=\begin{bmatrix}-1&3\\1&3\end{bmatrix}=PD$.

27. Since $\det P=-2\ne0$, $P$ is invertible, and $A=PDP^{-1}$.

28. For the requested power, $P^{-1}=\begin{bmatrix}- \frac{1}{2}&\frac{1}{2}\\\frac{1}{2}&\frac{1}{2}\end{bmatrix}$, $D^2=\begin{bmatrix}1&0\\0&9\end{bmatrix}$, and $A^2=PD^2P^{-1}=\begin{bmatrix}5&4\\4&5\end{bmatrix}$.

29. Check: $A\begin{bmatrix}-1\\1\end{bmatrix}=\begin{bmatrix}-1\\1\end{bmatrix}=1\begin{bmatrix}-1\\1\end{bmatrix}$.

30. Check: $A\begin{bmatrix}1\\1\end{bmatrix}=\begin{bmatrix}3\\3\end{bmatrix}=3\begin{bmatrix}1\\1\end{bmatrix}$.
::::

:::

:::problem[Problem 5.19 — Defective repeated eigenvalue]{difficulty=standard}
For $A=\begin{bmatrix}4&1\\0&4\end{bmatrix}$, show why the multiplicity test rules out diagonalization.

::::solution[Solution]
**Answer:** **not diagonalizable**; Eigenvalues $4$.  Eigenspace bases: $E_{4}=\span\left\{\begin{bmatrix}1\\0\end{bmatrix}\right\}$.

1. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

2. Form $A-\lambda I=\begin{bmatrix}4 - \lambda&1\\0&4 - \lambda\end{bmatrix}$.

3. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=(4-\lambda)(4-\lambda)-(1)(0)
   $$

4. Expand, simplify, and factor the preceding expression.

   $$
   =\lambda^{2} - 8 \lambda + 16=\left(\lambda - 4\right)^{2}.
   $$

5. Eigenspace for $\lambda=4$ (algebraic multiplicity 2): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

6. Row-reduce the homogeneous system: start with $A-(4)I=\begin{bmatrix}0&1\\0&0\end{bmatrix}$.

7. No row operation is needed; the matrix is already in reduced row-echelon form.

8. The pivot columns are 2; the free variable is $x_1$.

9. The pivot equations give $x_2=0$.

10. Choose one free variable at a time and set the others to zero.

11. Clear fractions where necessary.

12. The resulting basis is $\left\{\begin{bmatrix}1\\0\end{bmatrix}\right\}$.

13. Hence $\dim E_{4}=1$.

14. The roots of the factored polynomial are $\lambda=4$ (algebraic multiplicity 2).

15. **Diagonalization verdict:** The matrix is **not diagonalizable**: the total number of independent eigenvectors is 1, fewer than 2.

16. Check: $A\begin{bmatrix}1\\0\end{bmatrix}=\begin{bmatrix}4\\0\end{bmatrix}=4\begin{bmatrix}1\\0\end{bmatrix}$.
::::

:::


### Practice problems: Diagonalizable repeated eigenvalue

:::problem[Problem 5.20 — Diagonalizable repeated eigenvalue]{difficulty=standard}
For $A=\begin{bmatrix}3&0&0\\0&3&0\\0&0&1\end{bmatrix}$, explain why repetition does not always prevent diagonalization.

::::solution[Solution]
**Answer:** $P=\begin{bmatrix}0&1&0\\0&0&1\\1&0&0\end{bmatrix}$, $D=\begin{bmatrix}1&0&0\\0&3&0\\0&0&3\end{bmatrix}$; Eigenvalues $1$, $3$.  Eigenspace bases: $E_{1}=\span\left\{\begin{bmatrix}0\\0\\1\end{bmatrix}\right\}$, $E_{3}=\span\left\{\begin{bmatrix}1\\0\\0\end{bmatrix}, \begin{bmatrix}0\\1\\0\end{bmatrix}\right\}$.

1. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

2. Form $A-\lambda I=\begin{bmatrix}3 - \lambda&0&0\\0&3 - \lambda&0\\0&0&1 - \lambda\end{bmatrix}$.

3. The matrix is triangular, so multiply its three diagonal entries after subtracting $\lambda$:

4. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=\left(1 - \lambda\right) \left(\lambda - 3\right)^{2}=- \lambda^{3} + 7 \lambda^{2} - 15 \lambda + 9.
   $$

5. Eigenspace for $\lambda=1$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

6. Row-reduce the homogeneous system: start with $A-(1)I=\begin{bmatrix}2&0&0\\0&2&0\\0&0&0\end{bmatrix}$.

7. Multiply row 1 by $\frac{1}{2}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (\frac{1}{2})R_{1}}\begin{bmatrix}1&0&0\\0&2&0\\0&0&0\end{bmatrix}
   $$

8. Multiply row 2 by $\frac{1}{2}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{2}\leftarrow (\frac{1}{2})R_{2}}\begin{bmatrix}1&0&0\\0&1&0\\0&0&0\end{bmatrix}
   $$

9. The pivot columns are 1, 2; the free variable is $x_3$.

10. The pivot equations give $x_1=0$, $x_2=0$.

11. Choose one free variable at a time and set the others to zero.

12. Clear fractions where necessary.

13. The resulting basis is $\left\{\begin{bmatrix}0\\0\\1\end{bmatrix}\right\}$.

14. Hence $\dim E_{1}=1$.

15. Eigenspace for $\lambda=3$ (algebraic multiplicity 2): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

16. Row-reduce the homogeneous system: start with $A-(3)I=\begin{bmatrix}0&0&0\\0&0&0\\0&0&-2\end{bmatrix}$.

17. Swap rows 1 and 3 to place a nonzero pivot or reorder the equations.

   $$
   \xrightarrow{R_{1}\leftrightarrow R_{3}}\begin{bmatrix}0&0&-2\\0&0&0\\0&0&0\end{bmatrix}
   $$

18. Multiply row 1 by $- \frac{1}{2}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (- \frac{1}{2})R_{1}}\begin{bmatrix}0&0&1\\0&0&0\\0&0&0\end{bmatrix}
   $$

19. The pivot columns are 3; the free variables are $x_1$, $x_2$.

20. The pivot equations give $x_3=0$.

21. Choose one free variable at a time and set the others to zero.

22. Clear fractions where necessary.

23. The resulting basis is $\left\{\begin{bmatrix}1\\0\\0\end{bmatrix},\;\begin{bmatrix}0\\1\\0\end{bmatrix}\right\}$.

24. Hence $\dim E_{3}=2$.

25. The roots of the factored polynomial are $\lambda=1$ (algebraic multiplicity 1), $\lambda=3$ (algebraic multiplicity 2).

26. **Diagonalization:** the eigenspace bases give $P=\begin{bmatrix}0&1&0\\0&0&1\\1&0&0\end{bmatrix}$ and $D=\begin{bmatrix}1&0&0\\0&3&0\\0&0&3\end{bmatrix}$.

27. Check $AP=\begin{bmatrix}0&3&0\\0&0&3\\1&0&0\end{bmatrix}=PD$.

28. Since $\det P=1\ne0$, $P$ is invertible, and $A=PDP^{-1}$.

29. Check: $A\begin{bmatrix}0\\0\\1\end{bmatrix}=\begin{bmatrix}0\\0\\1\end{bmatrix}=1\begin{bmatrix}0\\0\\1\end{bmatrix}$.

30. Check: $A\begin{bmatrix}1\\0\\0\end{bmatrix}=\begin{bmatrix}3\\0\\0\end{bmatrix}=3\begin{bmatrix}1\\0\\0\end{bmatrix}$.

31. Check: $A\begin{bmatrix}0\\1\\0\end{bmatrix}=\begin{bmatrix}0\\3\\0\end{bmatrix}=3\begin{bmatrix}0\\1\\0\end{bmatrix}$.
::::

:::

:::problem[Problem 5.21 — Multiplicity and failure to diagonalize]{difficulty=challenge}
For $A=\begin{bmatrix}2&0&0\\0&3&1\\0&0&3\end{bmatrix}$, decide diagonalizability by comparing multiplicities.

::::solution[Solution]
**Answer:** **not diagonalizable**; Eigenvalues $2$, $3$.  Eigenspace bases: $E_{2}=\span\left\{\begin{bmatrix}1\\0\\0\end{bmatrix}\right\}$, $E_{3}=\span\left\{\begin{bmatrix}0\\1\\0\end{bmatrix}\right\}$.

1. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

2. Form $A-\lambda I=\begin{bmatrix}2 - \lambda&0&0\\0&3 - \lambda&1\\0&0&3 - \lambda\end{bmatrix}$.

3. The matrix is triangular, so multiply its three diagonal entries after subtracting $\lambda$:

4. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=\left(2 - \lambda\right) \left(\lambda - 3\right)^{2}=- \lambda^{3} + 8 \lambda^{2} - 21 \lambda + 18.
   $$

5. Eigenspace for $\lambda=2$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

6. Row-reduce the homogeneous system: start with $A-(2)I=\begin{bmatrix}0&0&0\\0&1&1\\0&0&1\end{bmatrix}$.

7. Swap rows 1 and 2 to place a nonzero pivot or reorder the equations.

   $$
   \xrightarrow{R_{1}\leftrightarrow R_{2}}\begin{bmatrix}0&1&1\\0&0&0\\0&0&1\end{bmatrix}
   $$

8. Swap rows 2 and 3 to place a nonzero pivot or reorder the equations.

   $$
   \xrightarrow{R_{2}\leftrightarrow R_{3}}\begin{bmatrix}0&1&1\\0&0&1\\0&0&0\end{bmatrix}
   $$

9. Replace row 1 by itself plus $-1$ times row 2 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{1}\leftarrow R_{1} + (-1)R_{2}}\begin{bmatrix}0&1&0\\0&0&1\\0&0&0\end{bmatrix}
   $$

10. The pivot columns are 2, 3; the free variable is $x_1$.

11. The pivot equations give $x_2=0$, $x_3=0$.

12. Choose one free variable at a time and set the others to zero.

13. Clear fractions where necessary.

14. The resulting basis is $\left\{\begin{bmatrix}1\\0\\0\end{bmatrix}\right\}$.

15. Hence $\dim E_{2}=1$.

16. Eigenspace for $\lambda=3$ (algebraic multiplicity 2): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

17. Row-reduce the homogeneous system: start with $A-(3)I=\begin{bmatrix}-1&0&0\\0&0&1\\0&0&0\end{bmatrix}$.

18. Multiply row 1 by $-1$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (-1)R_{1}}\begin{bmatrix}1&0&0\\0&0&1\\0&0&0\end{bmatrix}
   $$

19. The pivot columns are 1, 3; the free variable is $x_2$.

20. The pivot equations give $x_1=0$, $x_3=0$.

21. Choose one free variable at a time and set the others to zero.

22. Clear fractions where necessary.

23. The resulting basis is $\left\{\begin{bmatrix}0\\1\\0\end{bmatrix}\right\}$.

24. Hence $\dim E_{3}=1$.

25. The roots of the factored polynomial are $\lambda=2$ (algebraic multiplicity 1), $\lambda=3$ (algebraic multiplicity 2).

26. **Diagonalization verdict:** The matrix is **not diagonalizable**: the total number of independent eigenvectors is 2, fewer than 3.

27. Check: $A\begin{bmatrix}1\\0\\0\end{bmatrix}=\begin{bmatrix}2\\0\\0\end{bmatrix}=2\begin{bmatrix}1\\0\\0\end{bmatrix}$.

28. Check: $A\begin{bmatrix}0\\1\\0\end{bmatrix}=\begin{bmatrix}0\\3\\0\end{bmatrix}=3\begin{bmatrix}0\\1\\0\end{bmatrix}$.
::::

:::

## 5.5 Complex Eigenvalues


:::callout-intuition[Intuition]
A real matrix can have complex eigenvalues (they come in conjugate pairs). Rather than working in $\C^n$, for $2\times 2$ blocks we can express the transformation geometrically as a *rotation-dilation* in the plane, captured by a real block matrix.
:::

:::definition[Complex eigenvectors]
When $A$ has real entries but a complex root $a+bi$, the equation $(A-(a+bi)I)\mathbf{v}=\mathbf{0}$ is solved in $\C^n$. An eigenvector is still required to be nonzero. You may take $i^2=-1$ and rationalize fractions by multiplying numerator and denominator by the complex conjugate.
:::

:::callout-warning[The sign of the real 2 by 2 block]
For $\lambda=a-bi$ and $\mathbf{v}=\mathbf{p}+i\mathbf{q}$, equating real and imaginary parts gives $A\mathbf{p}=a\mathbf{p}+b\mathbf{q}$ and $A\mathbf{q}=-b\mathbf{p}+a\mathbf{q}$. Therefore $P=[\mathbf{p}\ \mathbf{q}]$ and $C=\begin{bmatrix}a&-b\\b&a\end{bmatrix}$. If instead you choose $a+bi$, the off-diagonal signs reverse. Compute $AP$ and $PC$ to check.
:::

<figure class="fig">
<svg class="fig-hue-5" viewBox="0 0 440 240" role="img" aria-label="Spiral formed from successive iterates of a rotation and shrink matrix.">
<line class="fig-axis" x1="101.2" y1="120.0" x2="338.8" y2="120.0"/><line class="fig-axis" x1="220.0" y1="215.7" x2="220.0" y2="24.3"/><path class="fig-curve" d="M319.0,120.0 L279.4,80.4 L239.8,72.5 L212.9,83.6 L201.2,101.0 L201.1,116.1 L207.1,125.2 L214.4,128.3 L219.9,127.2 L222.9,124.4 L223.5,121.5 L222.7,119.5 L221.4,118.6 L220.3,118.6"/><circle class="fig-point" cx="319.0" cy="120.0" r="3"/><circle class="fig-point" cx="239.8" cy="72.5" r="3"/><circle class="fig-point" cx="201.1" cy="116.1" r="3"/><circle class="fig-point" cx="222.9" cy="124.4" r="3"/><circle class="fig-point" cx="220.3" cy="118.6" r="3"/><text class="fig-label" x="320.6" y="106.8">k=0</text><text class="fig-label" x="196.9" y="92.0">toward 0</text>
</svg>
<figcaption>Repeated application of $A=\begin{bmatrix}0.6&-0.4\\0.4&0.6\end{bmatrix}$ rotates every vector by $\arctan(2/3)$ and multiplies its length by $\sqrt{0.52}\lt1$. The resulting iterates spiral toward zero.</figcaption>
</figure>

:::callout-connect[Real matrices, complex answers]
$\det(A-\lambda I)=0$ still works with complex roots, and $E_\lambda=\Nul(A-\lambda I)$ still works over $\C$. In a real two-dimensional space a genuine nontrivial rotation has no real eigenvector; the same matrix does have complex eigenvectors.
:::

:::theorem[Theorem 5.7 — Complex Eigenvalues of Real Matrices Come in Conjugate Pairs]
If $A$ is a real matrix with complex eigenvalue $\lambda = a+bi$ ($b\ne 0$) and eigenvector $\mathbf{v}=\mathbf{p}+i\mathbf{q}$, then $\bar\lambda = a-bi$ is also an eigenvalue with eigenvector $\bar{\mathbf{v}}=\mathbf{p}-i\mathbf{q}$.
:::

:::theorem[Theorem 5.8 — Real Block Form]
If $A$ is a real $2\times 2$ matrix with eigenvalue $\lambda=a-bi$ ($b\ne 0$) and corresponding eigenvector $\mathbf{v}=\mathbf{p}+i\mathbf{q}$, then

$$
A = PCP^{-1},\quad \text{where } P=[\mathbf{p}\;\mathbf{q}],\quad C=\begin{bmatrix}a&-b\\b&a\end{bmatrix}
$$

In the $P$-coordinate basis, $C$ is a counterclockwise rotation through $\theta=\operatorname{atan2}(b,a)$ followed by a dilation by $|\lambda|=\sqrt{a^2+b^2}$. The original matrix need not be a Euclidean rotation-dilation in its original coordinates.
:::


### How to do a complex $2\times2$ computation by hand

Do not start by guessing a rotation angle. Begin exactly as in the real-eigenvalue problems. For $A=\begin{bmatrix}a&b\\c&d\end{bmatrix}$, the characteristic equation is

$$
0=\det(A-\lambda I)=(a-\lambda)(d-\lambda)-bc
=\lambda^2-(a+d)\lambda+(ad-bc).
$$

Its discriminant is $\Delta=(a+d)^2-4(ad-bc)$. When $\Delta$ is negative, write $\sqrt\Delta=i\sqrt{-\Delta}$ before applying the quadratic formula. This prevents the common error of treating the square root of a negative number as a real number. Because $a,b,c,d$ are real, the two roots have opposite imaginary parts. Their sum is $a+d$, the trace, and their product is $ad-bc$, the determinant. Those give two arithmetic checks before you solve for a vector.

After finding $\lambda=\alpha+\beta i$, row-reduce $A-\lambda I$ over complex numbers. A typical pivot equation has the form $(r+si)x_1+tx_2=0$. If $r+si\ne0$, isolate

$$
x_1=-\frac{t}{r+si}x_2=-\frac{t(r-si)}{r^2+s^2}x_2.
$$

Choose the free variable so that the final vector has simple entries. Multiplying an eigenvector by any nonzero **complex** number gives another valid eigenvector in the same eigenspace. The row-reduction procedure is otherwise unchanged: identify pivots and free variables, then substitute back. Always check the result in the original equation $A\mathbf v=\lambda\mathbf v$, keeping the real and imaginary parts separate.

### Why the real block formula works

Take the root $\lambda=\alpha-\beta i$, with $\beta>0$, and write its eigenvector as $\mathbf v=\mathbf p+i\mathbf q$. Multiplication gives

$$
A(\mathbf p+i\mathbf q)=(\alpha-\beta i)(\mathbf p+i\mathbf q)
=(\alpha\mathbf p+\beta\mathbf q)
+i(\alpha\mathbf q-\beta\mathbf p).
$$

Matching the real and imaginary parts yields $A\mathbf p=\alpha\mathbf p+\beta\mathbf q$ and $A\mathbf q=-\beta\mathbf p+\alpha\mathbf q$. Place $\mathbf p$ and $\mathbf q$ beside each other as the columns of $P$. The two equations then become

$$
A[\mathbf p\ \mathbf q]
=[\mathbf p\ \mathbf q]\begin{bmatrix}\alpha&-\beta\\\beta&\alpha\end{bmatrix},
\qquad AP=PC.
$$

That one multiplication is the safest way to check all four signs in a test answer. In dimension two, a nonreal eigenvalue ensures $\mathbf p$ and $\mathbf q$ are independent; otherwise the real plane would contain a real eigenvector for a genuinely complex root. Thus $P$ is invertible and $A=PCP^{-1}$. Different choices of eigenvector may give different $P$ matrices, but the similarity identity is what matters.

### From a complex root to a spiral

The real block can be factored into a positive size change and a rotation:

$$
C=\begin{bmatrix}\alpha&-\beta\\\beta&\alpha\end{bmatrix}
=\underbrace{\sqrt{\alpha^2+\beta^2}}_{r}
\begin{bmatrix}\cos\theta&-\sin\theta\\\sin\theta&\cos\theta\end{bmatrix},
\quad \cos\theta=\frac\alpha r,\quad\sin\theta=\frac\beta r.
$$

The columns of $P$ provide the coordinate axes in which this statement is literally true. In those coordinates, $C^k=r^kR(k\theta)$: each application rotates through the same angle and multiplies distance from the origin by the same factor. If $0<r<1$, the iterates spiral inward; if $r>1$, they spiral outward; if $r=1$, they remain at constant radius. A negative $\beta$ changes the direction of rotation. In the original coordinates, the same iterates can trace a sheared or elliptical-looking spiral because $P$ may distort lengths and angles.

For a no-calculator test, leave a non-special angle as $\tan^{-1}(\beta/\alpha)$ with a quadrant statement, or as $\operatorname{atan2}(\beta,\alpha)$. There is no reason to approximate the angle in degrees. You *can* determine the scale factor exactly from $r=\sqrt{\det C}$; for a real $2\times2$ matrix with a nonreal conjugate eigenpair, $\det A=r^2>0$. A complex eigenvalue never by itself makes a real matrix noninvertible: only a **zero** eigenvalue does.


:::example[Example 5.14 — Real Block Form for a $2\times 2$ Matrix]
Find the real block decomposition of $A=\begin{bmatrix}0.5&-0.6\\0.75&1.1\end{bmatrix}$.

::::answer[Answer]
**Answer:** Eigenvalues $\frac45\pm\frac35i$; a real block for the chosen $\frac45-\frac35i$ eigenvector is $C=\begin{bmatrix}4/5&-3/5\\3/5&4/5\end{bmatrix}$.

1. **Characteristic polynomial:**

2. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=\lambda^2-1.6\lambda+0.55+0.45=\lambda^2-1.6\lambda+1
   $$

3. Roots: $\lambda=\frac{1.6\pm\sqrt{2.56-4}}{2}=\frac{1.6\pm\sqrt{-1.44}}{2}=0.8\pm 0.6i$

4. So $a=0.8, b=0.6$, and $|\lambda|=\sqrt{0.64+0.36}=1$ (similar to a pure rotation, though not necessarily a Euclidean rotation in the original coordinates).

5. **Eigenvector for $\lambda=0.8-0.6i$:**

6. Evaluate the displayed calculation.

   $$
   A-(0.8-0.6i)I=\begin{bmatrix}-0.3+0.6i&-0.6\\0.75&0.3+0.6i\end{bmatrix}
   $$

7. From row 1: $(-0.3+0.6i)x_1=0.6x_2$.

8. Set $x_2=1$: $x_1=\frac{0.6}{-0.3+0.6i}=\frac{0.6(-0.3-0.6i)}{0.09+0.36}=\frac{-0.18-0.36i}{0.45}=-0.4-0.8i$.

9. So $\mathbf{v}=\begin{bmatrix}-0.4-0.8i\\1\end{bmatrix}=\underbrace{\begin{bmatrix}-0.4\\1\end{bmatrix}}_{\mathbf{p}}+i\underbrace{\begin{bmatrix}-0.8\\0\end{bmatrix}}_{\mathbf{q}}$.

10. $P=\begin{bmatrix}-0.4&-0.8\\1&0\end{bmatrix}$, $C=\begin{bmatrix}0.8&-0.6\\0.6&0.8\end{bmatrix}$.

11. **Exact hand verification (fractions instead of decimals):** $A=\begin{bmatrix}1/2&-3/5\\3/4&11/10\end{bmatrix}$.

12. Its real block factorization must use $C=\begin{bmatrix}4/5&-3/5\\3/5&4/5\end{bmatrix}$ for the chosen eigenvector $0.8-0.6i$.

13. Multiplying $AP$ and $PC$ gives the same matrix.

14. The angle is $\operatorname{atan2}(3,4)$ in the transformed basis, not automatically in the original coordinate axes.
::::

:::

:::example[Example 5.15 — Interpreting Complex Eigenvalues Geometrically]
The matrix $A=\begin{bmatrix}\cos\theta&-\sin\theta\\\sin\theta&\cos\theta\end{bmatrix}$ represents a rotation by $\theta$. What are its eigenvalues?

::::answer[Answer]
**Answer:** $\lambda=\cos\theta\pm i\sin\theta$.

1. $\det(A-\lambda I)=(\cos\theta-\lambda)^2+\sin^2\theta=\lambda^2-2\cos\theta\cdot\lambda+1$.

2. Roots: $\lambda=\cos\theta\pm i\sin\theta = e^{\pm i\theta}$.

3. These have modulus 1 — a pure rotation with no stretching or shrinking.
::::

:::


:::example[Example 5.16 — Quarter-turn eigenvectors]
Find the complex eigenvalues and eigenspaces of $A=\begin{bmatrix}0&-1\\1&0\end{bmatrix}$.

::::answer[Answer]
**Answer:** $\lambda=i$ and $\lambda=-i$, with eigenspaces $E_i=\span\{\begin{bmatrix}1\\-i\end{bmatrix}\}$ and $E_{-i}=\span\{\begin{bmatrix}1\\i\end{bmatrix}\}$.

1. The entire determinant is

2. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=\det\begin{bmatrix}-\lambda&-1\\1&-\lambda\end{bmatrix}=(-\lambda)(-\lambda)-(-1)(1)=\lambda^2+1=(\lambda-i)(\lambda+i).
   $$

3. For $\lambda=i$, start with

4. Use the indicated row operation to simplify the homogeneous system.

   $$
   A-iI=\begin{bmatrix}-i&-1\\1&-i\end{bmatrix}
   \xrightarrow{R_1\leftarrow iR_1}\begin{bmatrix}1&-i\\1&-i\end{bmatrix}
   \xrightarrow{R_2\leftarrow R_2-R_1}\begin{bmatrix}1&-i\\0&0\end{bmatrix}.
   $$

5. The pivot is column 1, $x_2$ is free, and $x_1=ix_2$.

6. Set $x_2=-i$ to get $x_1=1$: $\mathbf{v}_i=(1,-i)^T$.

7. Check $A\mathbf{v}_i=(i,1)^T=i(1,-i)^T$.

8. For $\lambda=-i$,

9. Use the indicated row operation to simplify the homogeneous system.

   $$
   A+iI=\begin{bmatrix}i&-1\\1&i\end{bmatrix}
   \xrightarrow{R_1\leftarrow -iR_1}\begin{bmatrix}1&i\\1&i\end{bmatrix}
   \xrightarrow{R_2\leftarrow R_2-R_1}\begin{bmatrix}1&i\\0&0\end{bmatrix}.
   $$

10. Column 1 is pivot, $x_2$ is free, and $x_1=-ix_2$.

11. Set $x_2=i$ to get $x_1=1$: $\mathbf{v}_{-i}=(1,i)^T$.

12. Check $A\mathbf{v}_{-i}=(-i,1)^T=-i(1,i)^T$.
::::

:::


### Worked examples: Real block from an easy complex vector

:::example[Example 5.17 — Real block from an easy complex vector]
For $A=\begin{bmatrix}1&-2\\2&1\end{bmatrix}$, find complex eigenspaces and $A=PCP^{-1}$ in a real basis.

::::answer[Answer]
**Answer:** eigenvalues $1\pm2i$; eigenvectors $(1,-i)^T$ for $1+2i$ and $(1,i)^T$ for $1-2i$. One real block decomposition is $P=I$, $C=\begin{bmatrix}1&-2\\2&1\end{bmatrix}$.

1. Compute

2. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=(1-\lambda)(1-\lambda)-(-2)(2)
   =(1-2\lambda+\lambda^2)+4=\lambda^2-2\lambda+5
   =(\lambda-(1+2i))(\lambda-(1-2i)).
   $$

3. For $\lambda=1+2i$,

4. Use the indicated row operation to simplify the homogeneous system.

   $$
   A-\lambda I=\begin{bmatrix}-2i&-2\\2&-2i\end{bmatrix}
   \xrightarrow{R_1\leftarrow R_1/(-2i)}\begin{bmatrix}1&-i\\2&-2i\end{bmatrix}
   \xrightarrow{R_2\leftarrow R_2-2R_1}\begin{bmatrix}1&-i\\0&0\end{bmatrix}.
   $$

5. So $x_2$ is free and $x_1=ix_2$.

6. Choose $x_2=-i$, obtaining $(1,-i)^T$.

7. Its conjugate is $(1,i)^T$ for $1-2i$; conjugation preserves the row-reduction steps.

8. For the *negative imaginary root* $\lambda=1-2i$, choose $\mathbf{p}=(1,0)^T$ and $\mathbf{q}=(0,1)^T$, so $P=[\mathbf{p}\ \mathbf{q}]=I$ and $C=\begin{bmatrix}1&-2\\2&1\end{bmatrix}$.

9. Directly $AP=PC=A$.

10. The rotation angle is $\operatorname{atan2}(2,1)$ and the scale factor is $\sqrt5$.
::::

:::


### Checking complex arithmetic without a calculator

The expression $i^2=-1$ must be used in both the determinant and the eigenvector check. For example, take $A=\begin{bmatrix}0&-2\\2&0\end{bmatrix}$. Its characteristic equation is
$$
\det(A-\lambda I)=(-\lambda)(-\lambda)-(-2)(2)=\lambda^2+4=0.
$$
Moving the constant gives $\lambda^2=-4$, and taking the two square roots gives $\lambda=\pm2i$. For $\lambda=2i$,
$$
A-2iI=\begin{bmatrix}-2i&-2\\2&-2i\end{bmatrix}.
$$
The first row yields $-2ix_1-2x_2=0$, then $x_2=-ix_1$. Taking $x_1=1$ gives $\mathbf v=(1,-i)^T$. Verify explicitly:
$$
A\mathbf v=\begin{bmatrix}2i\\2\end{bmatrix}
=2i\begin{bmatrix}1\\-i\end{bmatrix},
\quad\text{since }2i(-i)=-2i^2=2.
$$
The conjugate vector $(1,i)^T$ belongs to the conjugate eigenvalue $-2i$. Neither eigenvector is real, which agrees with the fact that a nonzero real vector turned through a quarter-turn cannot remain on its own line.

An exact power computation gives another way to see the geometry. Here $A^2=\begin{bmatrix}-4&0\\0&-4\end{bmatrix}=-4I$, so $A^3=-4A$ and $A^4=16I$. Every four applications restore the original direction, scaled by $16$; one application turns it and doubles its length. These identities can be checked by ordinary matrix multiplication, without converting a complex angle to a decimal.

### Two boundaries to remember

If $\beta=0$, the eigenvalues are real, and the complex-pair rotation formula is no longer a separate two-dimensional conjugate-block construction. Use the ordinary real eigenvalue and diagonalization methods instead. If a real $2\times2$ matrix has conjugate nonreal eigenvalues, it is diagonalizable **over $\mathbb C$** but not by a real diagonal matrix. The real block $C$ is the replacement for such a diagonalization when your final answer must be real. If the problem asks only for eigenvalues, stop after factoring the characteristic equation; if it asks for a real block, you must also find an eigenvector, separate its real and imaginary parts, and verify $AP=PC$.


A final exam distinction: **the modulus $|\lambda|$ controls discrete powers, but the real part controls continuous ODE growth**. For $\mathbf x_{k+1}=A\mathbf x_k$, the powers of $r$ determine whether a complex-conjugate mode shrinks or grows from one step to the next. For $\mathbf x'=A\mathbf x$, the corresponding complex exponential has size $e^{(\operatorname{Re}\lambda)t}$, so positive real part causes growth even if a particular matrix has a complex eigenvalue with modulus below one. Never interchange these tests. In the real block, the off-diagonal entries describe the rotation, and the diagonal entries describe the real part of the eigenvalues. On a written test, state explicitly whether you are analyzing **powers** or **a differential equation** before drawing a long-run conclusion.

:::callout-pitfall[Pitfalls in §5.5]
(1) Losing a sign when replacing $i^2$ by $-1$. (2) Computing eigenvalues but failing to solve the complex null-space systems. (3) Using the block sign for $a+bi$ when the chosen eigenvector belongs to $a-bi$. (4) Claiming every similar rotation-dilation is a literal Euclidean rotation in the original basis.
:::

:::problem[Problem 5.22 — Complex roots and geometric action]{difficulty=standard}
Find the eigenvalues and describe the geometry of $A=\begin{bmatrix}3&-2\\1&1\end{bmatrix}$.

::::solution[Solution]
**Answer:** $\lambda=2\pm i$, corresponding to rotation angle $\arctan(1/2)$ and dilation $\sqrt5$ in a suitable real basis.

1. Char. poly: $\lambda^2-4\lambda+5$.

2. Roots: $\lambda=2\pm i$.

3. Here $a=2, b=1$, $|\lambda|=\sqrt{5}$.

4. In a suitable eigenvector-derived real basis, the matrix is similar to a rotation by $\theta=\arctan(1/2)\approx 26.6^\circ$ and a dilation by $\sqrt{5}$.

5. In the original coordinates this is not necessarily a Euclidean rotation and uniform dilation.

6. **Full calculation:** $\det(A-\lambda I)=(3-\lambda)(1-\lambda)-(-2)(1)=\lambda^2-4\lambda+5$.

7. The discriminant is $16-20=-4$, so $\lambda=(4\pm2i)/2=2\pm i$.

8. This matrix is similar over the reals to a rotation-dilation block, not necessarily itself a Euclidean rotation.
::::

:::

:::problem[Problem 5.23 — Quarter-turn eigenspaces]{difficulty=easy}
Find complex eigenvalues and an eigenspace basis for $A=\begin{bmatrix}0&-1\\1&0\end{bmatrix}$.

::::solution[Solution]
**Answer:** $\lambda=i,\;- i$; respective bases $\begin{bmatrix}i\\1\end{bmatrix}$ and $\begin{bmatrix}- i\\1\end{bmatrix}$.

1. $\det(A-\lambda I)=(0-\lambda)(0-\lambda)-(-1)(1)=\lambda^{2} + 1=\lambda^{2} + 1.$

2. For the positive imaginary root:

3. $A-(i)I=\begin{bmatrix}- i&-1\\1&- i\end{bmatrix}$.

4. $\xrightarrow{R_{1}\leftarrow (i)R_{1}}\begin{bmatrix}1&- i\\1&- i\end{bmatrix}$

5. $\xrightarrow{R_{2}\leftarrow R_{2} + (-1)R_{1}}\begin{bmatrix}1&- i\\0&0\end{bmatrix}$

6. Pivot column 1, free variable $x_{2}$.

7. Choose $x_2=1$; then $x_1=i$, so $E_{i}=\span\{\begin{bmatrix}i\\1\end{bmatrix}\}$.

8. Direct multiplication gives $A\begin{bmatrix}i\\1\end{bmatrix}=\begin{bmatrix}-1\\i\end{bmatrix}=(i)\begin{bmatrix}i\\1\end{bmatrix}$.

9. For the conjugate root:

10. $A-(- i)I=\begin{bmatrix}i&-1\\1&i\end{bmatrix}$.

11. $\xrightarrow{R_{1}\leftarrow (- i)R_{1}}\begin{bmatrix}1&i\\1&i\end{bmatrix}$

12. $\xrightarrow{R_{2}\leftarrow R_{2} + (-1)R_{1}}\begin{bmatrix}1&i\\0&0\end{bmatrix}$

13. Pivot column 1, free variable $x_{2}$.

14. Choose $x_2=1$; then $x_1=- i$, so $E_{- i}=\span\{\begin{bmatrix}- i\\1\end{bmatrix}\}$.

15. Direct multiplication gives $A\begin{bmatrix}- i\\1\end{bmatrix}=\begin{bmatrix}-1\\- i\end{bmatrix}=(- i)\begin{bmatrix}- i\\1\end{bmatrix}$.
::::

:::


### Practice problems: Complex roots with translation

:::problem[Problem 5.24 — Complex roots with translation]{difficulty=easy}
Find complex eigenvalues and an eigenspace basis for $A=\begin{bmatrix}1&-1\\1&1\end{bmatrix}$.

::::solution[Solution]
**Answer:** $\lambda=1 + i,\;1 - i$; respective bases $\begin{bmatrix}i\\1\end{bmatrix}$ and $\begin{bmatrix}- i\\1\end{bmatrix}$.

1. $\det(A-\lambda I)=(1-\lambda)(1-\lambda)-(-1)(1)=\lambda^{2} - 2 \lambda + 2=\lambda^{2} - 2 \lambda + 2.$

2. For the positive imaginary root:

3. $A-(1 + i)I=\begin{bmatrix}- i&-1\\1&- i\end{bmatrix}$.

4. $\xrightarrow{R_{1}\leftarrow (i)R_{1}}\begin{bmatrix}1&- i\\1&- i\end{bmatrix}$

5. $\xrightarrow{R_{2}\leftarrow R_{2} + (-1)R_{1}}\begin{bmatrix}1&- i\\0&0\end{bmatrix}$

6. Pivot column 1, free variable $x_{2}$.

7. Choose $x_2=1$; then $x_1=i$, so $E_{1 + i}=\span\{\begin{bmatrix}i\\1\end{bmatrix}\}$.

8. Direct multiplication gives $A\begin{bmatrix}i\\1\end{bmatrix}=\begin{bmatrix}-1 + i\\1 + i\end{bmatrix}=(1 + i)\begin{bmatrix}i\\1\end{bmatrix}$.

9. For the conjugate root:

10. $A-(1 - i)I=\begin{bmatrix}i&-1\\1&i\end{bmatrix}$.

11. $\xrightarrow{R_{1}\leftarrow (- i)R_{1}}\begin{bmatrix}1&i\\1&i\end{bmatrix}$

12. $\xrightarrow{R_{2}\leftarrow R_{2} + (-1)R_{1}}\begin{bmatrix}1&i\\0&0\end{bmatrix}$

13. Pivot column 1, free variable $x_{2}$.

14. Choose $x_2=1$; then $x_1=- i$, so $E_{1 - i}=\span\{\begin{bmatrix}- i\\1\end{bmatrix}\}$.

15. Direct multiplication gives $A\begin{bmatrix}- i\\1\end{bmatrix}=\begin{bmatrix}-1 - i\\1 - i\end{bmatrix}=(1 - i)\begin{bmatrix}- i\\1\end{bmatrix}$.
::::

:::

:::problem[Problem 5.25 — Complex conjugate eigenspaces]{difficulty=standard}
Find complex eigenvalues and an eigenspace basis for $A=\begin{bmatrix}2&-1\\1&2\end{bmatrix}$.

::::solution[Solution]
**Answer:** $\lambda=2 + i,\;2 - i$; respective bases $\begin{bmatrix}i\\1\end{bmatrix}$ and $\begin{bmatrix}- i\\1\end{bmatrix}$.

1. $\det(A-\lambda I)=(2-\lambda)(2-\lambda)-(-1)(1)=\lambda^{2} - 4 \lambda + 5=\lambda^{2} - 4 \lambda + 5.$

2. For the positive imaginary root:

3. $A-(2 + i)I=\begin{bmatrix}- i&-1\\1&- i\end{bmatrix}$.

4. $\xrightarrow{R_{1}\leftarrow (i)R_{1}}\begin{bmatrix}1&- i\\1&- i\end{bmatrix}$

5. $\xrightarrow{R_{2}\leftarrow R_{2} + (-1)R_{1}}\begin{bmatrix}1&- i\\0&0\end{bmatrix}$

6. Pivot column 1, free variable $x_{2}$.

7. Choose $x_2=1$; then $x_1=i$, so $E_{2 + i}=\span\{\begin{bmatrix}i\\1\end{bmatrix}\}$.

8. Direct multiplication gives $A\begin{bmatrix}i\\1\end{bmatrix}=\begin{bmatrix}-1 + 2 i\\2 + i\end{bmatrix}=(2 + i)\begin{bmatrix}i\\1\end{bmatrix}$.

9. For the conjugate root:

10. $A-(2 - i)I=\begin{bmatrix}i&-1\\1&i\end{bmatrix}$.

11. $\xrightarrow{R_{1}\leftarrow (- i)R_{1}}\begin{bmatrix}1&i\\1&i\end{bmatrix}$

12. $\xrightarrow{R_{2}\leftarrow R_{2} + (-1)R_{1}}\begin{bmatrix}1&i\\0&0\end{bmatrix}$

13. Pivot column 1, free variable $x_{2}$.

14. Choose $x_2=1$; then $x_1=- i$, so $E_{2 - i}=\span\{\begin{bmatrix}- i\\1\end{bmatrix}\}$.

15. Direct multiplication gives $A\begin{bmatrix}- i\\1\end{bmatrix}=\begin{bmatrix}-1 - 2 i\\2 - i\end{bmatrix}=(2 - i)\begin{bmatrix}- i\\1\end{bmatrix}$.
::::

:::

:::problem[Problem 5.26 — Pure imaginary eigenvalues]{difficulty=standard}
Find complex eigenvalues and an eigenspace basis for $A=\begin{bmatrix}0&-2\\2&0\end{bmatrix}$.

::::solution[Solution]
**Answer:** $\lambda=2 i,\;- 2 i$; respective bases $\begin{bmatrix}i\\1\end{bmatrix}$ and $\begin{bmatrix}- i\\1\end{bmatrix}$.

1. $\det(A-\lambda I)=(0-\lambda)(0-\lambda)-(-2)(2)=\lambda^{2} + 4=\lambda^{2} + 4.$

2. For the positive imaginary root:

3. $A-(2 i)I=\begin{bmatrix}- 2 i&-2\\2&- 2 i\end{bmatrix}$.

4. $\xrightarrow{R_{1}\leftarrow (\frac{i}{2})R_{1}}\begin{bmatrix}1&- i\\2&- 2 i\end{bmatrix}$

5. $\xrightarrow{R_{2}\leftarrow R_{2} + (-2)R_{1}}\begin{bmatrix}1&- i\\0&0\end{bmatrix}$

6. Pivot column 1, free variable $x_{2}$.

7. Choose $x_2=1$; then $x_1=i$, so $E_{2 i}=\span\{\begin{bmatrix}i\\1\end{bmatrix}\}$.

8. Direct multiplication gives $A\begin{bmatrix}i\\1\end{bmatrix}=\begin{bmatrix}-2\\2 i\end{bmatrix}=(2 i)\begin{bmatrix}i\\1\end{bmatrix}$.

9. For the conjugate root:

10. $A-(- 2 i)I=\begin{bmatrix}2 i&-2\\2&2 i\end{bmatrix}$.

11. $\xrightarrow{R_{1}\leftarrow (- \frac{i}{2})R_{1}}\begin{bmatrix}1&i\\2&2 i\end{bmatrix}$

12. $\xrightarrow{R_{2}\leftarrow R_{2} + (-2)R_{1}}\begin{bmatrix}1&i\\0&0\end{bmatrix}$

13. Pivot column 1, free variable $x_{2}$.

14. Choose $x_2=1$; then $x_1=- i$, so $E_{- 2 i}=\span\{\begin{bmatrix}- i\\1\end{bmatrix}\}$.

15. Direct multiplication gives $A\begin{bmatrix}- i\\1\end{bmatrix}=\begin{bmatrix}-2\\- 2 i\end{bmatrix}=(- 2 i)\begin{bmatrix}- i\\1\end{bmatrix}$.
::::

:::

:::problem[Problem 5.27 — Complex eigenvectors with unequal scales]{difficulty=standard}
Find complex eigenvalues and an eigenspace basis for $A=\begin{bmatrix}3&-1\\4&3\end{bmatrix}$.

::::solution[Solution]
**Answer:** $\lambda=3 + 2 i,\;3 - 2 i$; respective bases $\begin{bmatrix}\frac{i}{2}\\1\end{bmatrix}$ and $\begin{bmatrix}- \frac{i}{2}\\1\end{bmatrix}$.

1. $\det(A-\lambda I)=(3-\lambda)(3-\lambda)-(-1)(4)=\lambda^{2} - 6 \lambda + 13=\lambda^{2} - 6 \lambda + 13.$

2. For the positive imaginary root:

3. $A-(3 + 2 i)I=\begin{bmatrix}- 2 i&-1\\4&- 2 i\end{bmatrix}$.

4. $\xrightarrow{R_{1}\leftarrow (\frac{i}{2})R_{1}}\begin{bmatrix}1&- \frac{i}{2}\\4&- 2 i\end{bmatrix}$

5. $\xrightarrow{R_{2}\leftarrow R_{2} + (-4)R_{1}}\begin{bmatrix}1&- \frac{i}{2}\\0&0\end{bmatrix}$

6. Pivot column 1, free variable $x_{2}$.

7. Choose $x_2=1$; then $x_1=\frac{i}{2}$, so $E_{3 + 2 i}=\span\{\begin{bmatrix}\frac{i}{2}\\1\end{bmatrix}\}$.

8. Direct multiplication gives $A\begin{bmatrix}\frac{i}{2}\\1\end{bmatrix}=\begin{bmatrix}-1 + \frac{3 i}{2}\\3 + 2 i\end{bmatrix}=(3 + 2 i)\begin{bmatrix}\frac{i}{2}\\1\end{bmatrix}$.

9. For the conjugate root:

10. $A-(3 - 2 i)I=\begin{bmatrix}2 i&-1\\4&2 i\end{bmatrix}$.

11. $\xrightarrow{R_{1}\leftarrow (- \frac{i}{2})R_{1}}\begin{bmatrix}1&\frac{i}{2}\\4&2 i\end{bmatrix}$

12. $\xrightarrow{R_{2}\leftarrow R_{2} + (-4)R_{1}}\begin{bmatrix}1&\frac{i}{2}\\0&0\end{bmatrix}$

13. Pivot column 1, free variable $x_{2}$.

14. Choose $x_2=1$; then $x_1=- \frac{i}{2}$, so $E_{3 - 2 i}=\span\{\begin{bmatrix}- \frac{i}{2}\\1\end{bmatrix}\}$.

15. Direct multiplication gives $A\begin{bmatrix}- \frac{i}{2}\\1\end{bmatrix}=\begin{bmatrix}-1 - \frac{3 i}{2}\\3 - 2 i\end{bmatrix}=(3 - 2 i)\begin{bmatrix}- \frac{i}{2}\\1\end{bmatrix}$.
::::

:::


### Practice problems: Complex roots containing a radical

:::problem[Problem 5.28 — Complex roots containing a radical]{difficulty=challenge}
Find complex eigenvalues and an eigenspace basis for $A=\begin{bmatrix}2&-5\\1&2\end{bmatrix}$.

::::solution[Solution]
**Answer:** $\lambda=2 + \sqrt{5} i,\;2 - \sqrt{5} i$; respective bases $\begin{bmatrix}\sqrt{5} i\\1\end{bmatrix}$ and $\begin{bmatrix}- \sqrt{5} i\\1\end{bmatrix}$.

1. $\det(A-\lambda I)=(2-\lambda)(2-\lambda)-(-5)(1)=\lambda^{2} - 4 \lambda + 9=\lambda^{2} - 4 \lambda + 9.$

2. For the positive imaginary root:

3. $A-(2 + \sqrt{5} i)I=\begin{bmatrix}- \sqrt{5} i&-5\\1&- \sqrt{5} i\end{bmatrix}$.

4. $\xrightarrow{R_{1}\leftarrow (\frac{\sqrt{5} i}{5})R_{1}}\begin{bmatrix}1&- \sqrt{5} i\\1&- \sqrt{5} i\end{bmatrix}$

5. $\xrightarrow{R_{2}\leftarrow R_{2} + (-1)R_{1}}\begin{bmatrix}1&- \sqrt{5} i\\0&0\end{bmatrix}$

6. Pivot column 1, free variable $x_{2}$.

7. Choose $x_2=1$; then $x_1=\sqrt{5} i$, so $E_{2 + \sqrt{5} i}=\span\{\begin{bmatrix}\sqrt{5} i\\1\end{bmatrix}\}$.

8. Direct multiplication gives $A\begin{bmatrix}\sqrt{5} i\\1\end{bmatrix}=\begin{bmatrix}-5 + 2 \sqrt{5} i\\2 + \sqrt{5} i\end{bmatrix}=(2 + \sqrt{5} i)\begin{bmatrix}\sqrt{5} i\\1\end{bmatrix}$.

9. For the conjugate root:

10. $A-(2 - \sqrt{5} i)I=\begin{bmatrix}\sqrt{5} i&-5\\1&\sqrt{5} i\end{bmatrix}$.

11. $\xrightarrow{R_{1}\leftarrow (- \frac{\sqrt{5} i}{5})R_{1}}\begin{bmatrix}1&\sqrt{5} i\\1&\sqrt{5} i\end{bmatrix}$

12. $\xrightarrow{R_{2}\leftarrow R_{2} + (-1)R_{1}}\begin{bmatrix}1&\sqrt{5} i\\0&0\end{bmatrix}$

13. Pivot column 1, free variable $x_{2}$.

14. Choose $x_2=1$; then $x_1=- \sqrt{5} i$, so $E_{2 - \sqrt{5} i}=\span\{\begin{bmatrix}- \sqrt{5} i\\1\end{bmatrix}\}$.

15. Direct multiplication gives $A\begin{bmatrix}- \sqrt{5} i\\1\end{bmatrix}=\begin{bmatrix}-5 - 2 \sqrt{5} i\\2 - \sqrt{5} i\end{bmatrix}=(2 - \sqrt{5} i)\begin{bmatrix}- \sqrt{5} i\\1\end{bmatrix}$.
::::

:::

## 5.7 Applications to Differential Equations


:::callout-intuition[Intuition]
A system of $n$ first-order linear ODEs $\mathbf{x}'=A\mathbf{x}$ can be solved by decoupling it: if $A$ is diagonalizable, each eigenvector direction evolves independently as a pure exponential $e^{\lambda t}$. The general solution is a linear combination of these exponential modes.

A single equation $y'=3y$ has solution $y(t)=Ce^{3t}$. In a system, the coordinates may interact, but an eigenvector direction behaves as if it were one scalar equation. Express the starting point as a sum of eigenvectors and let each component grow or decay with its own exponential. The mathematics is the same row reduction and change of basis you already practiced.
:::

:::callout-key[What earns full written credit]
For $\mathbf{x}'=A\mathbf{x}$, find $\lambda_i$, solve $(A-\lambda_i I)\mathbf{v}_i=0$, write $\mathbf{x}(t)=\sum_i c_i e^{\lambda_i t}\mathbf{v}_i$, then plug in $t=0$ to solve $P\mathbf{c}=\mathbf{x}_0$ by row reduction. Finish by checking $\mathbf{x}(0)$ and $\mathbf{x}'(t)=A\mathbf{x}(t)$.
:::

:::theorem[Real-part stability test]
For an $n\times n$ constant real matrix, every solution of $\mathbf{x}'=A\mathbf{x}$ approaches zero when every eigenvalue has strictly negative real part. If at least one eigenvalue has positive real part, some solutions grow. Eigenvalues with real part zero require additional analysis: the eigenvalues alone may not settle the question.
:::

:::definition[System Setup]
A first-order linear system has the form

$$
\mathbf{x}'(t) = A\mathbf{x}(t),\qquad \mathbf{x}(0)=\mathbf{x}_0
$$

where $A$ is an $n\times n$ matrix and $\mathbf{x}:\R\to\R^n$.
:::

:::theorem[Theorem 5.9 — Solution via Diagonalization]
If $A=PDP^{-1}$ is diagonalizable with $D=\text{diag}(\lambda_1,\ldots,\lambda_n)$ and $P=[\mathbf{v}_1\cdots\mathbf{v}_n]$, then the general solution of $\mathbf{x}'=A\mathbf{x}$ is

$$
\mathbf{x}(t) = c_1 e^{\lambda_1 t}\mathbf{v}_1 + c_2 e^{\lambda_2 t}\mathbf{v}_2 + \cdots + c_n e^{\lambda_n t}\mathbf{v}_n
$$

The constants $c_1,\ldots,c_n$ are determined by the initial condition: $\mathbf{c}=[c_1,\ldots,c_n]^T = P^{-1}\mathbf{x}_0$.
:::

:::example[Example 5.18 — Solving a $2\times 2$ System of ODEs]
Solve $\mathbf{x}'=A\mathbf{x}$ where $A=\begin{bmatrix}3&1\\0&1\end{bmatrix}$, $\mathbf{x}(0)=\begin{bmatrix}1\\3\end{bmatrix}$.

::::answer[Answer]
**Answer:** $\mathbf{x}(t)=(\frac52e^{3t}-\frac32e^t,\;3e^t)^T$.

1. **Step 1 — Eigenvalues and eigenvectors:**

2. $A$ is upper triangular; eigenvalues $\lambda_1=3, \lambda_2=1$.

3. $E_3$: $A-3I=\begin{bmatrix}0&1\\0&-2\end{bmatrix}\to\begin{bmatrix}0&1\\0&0\end{bmatrix}$, so $x_2=0$.

4. Eigenvector: $\mathbf{v}_1=\begin{bmatrix}1\\0\end{bmatrix}$.

5. $E_1$: $A-I=\begin{bmatrix}2&1\\0&0\end{bmatrix}$.

6. Set $x_2=2$: $x_1=-1$.

7. Eigenvector: $\mathbf{v}_2=\begin{bmatrix}-1\\2\end{bmatrix}$.

8. **Step 2 — General solution:**

9. Evaluate the displayed calculation.

   $$
   \mathbf{x}(t) = c_1 e^{3t}\begin{bmatrix}1\\0\end{bmatrix} + c_2 e^{t}\begin{bmatrix}-1\\2\end{bmatrix}
   $$

10. **Step 3 — Apply initial condition:**

11. Evaluate the displayed calculation.

   $$
   \mathbf{x}(0)=c_1\begin{bmatrix}1\\0\end{bmatrix}+c_2\begin{bmatrix}-1\\2\end{bmatrix}=\begin{bmatrix}1\\3\end{bmatrix}
   $$

12. System: $c_1-c_2=1$ and $2c_2=3\Rightarrow c_2=3/2$, $c_1=5/2$.

13. **Solution:**

14. Evaluate the displayed calculation.

   $$
   \mathbf{x}(t)=\frac{5}{2}e^{3t}\begin{bmatrix}1\\0\end{bmatrix}+\frac{3}{2}e^{t}\begin{bmatrix}-1\\2\end{bmatrix}=\begin{bmatrix}\frac{5}{2}e^{3t}-\frac{3}{2}e^t\\3e^t\end{bmatrix}
   $$
::::

:::

:::example[Example 5.19 — Long-Run Behavior]
For $\mathbf{x}'=A\mathbf{x}$ with eigenvalues $\lambda_1=-2, \lambda_2=3$, describe what happens as $t\to\infty$.

::::answer[Answer]
**Answer:** The negative-eigenvalue mode decays; the positive-eigenvalue mode grows whenever its coefficient is nonzero.

1. The solution is $c_1e^{-2t}\mathbf{v}_1 + c_2e^{3t}\mathbf{v}_2$.

2. As $t\to\infty$, the $e^{-2t}$ term $\to 0$ while the $e^{3t}$ term dominates (if $c_2\ne 0$).

3. The solution grows without bound in the direction of $\mathbf{v}_2$.

4. For a real diagonalizable system, negative eigenvalues produce decay modes and positive eigenvalues produce growth modes when their coefficient is nonzero.

5. With complex eigenvalues, use their real parts.
::::

:::


:::example[Example 5.20 — Decaying and growing modes]
Solve $\mathbf{x}'(t)=A\mathbf{x}(t)$ with $A=\begin{bmatrix}2&0\\0&-1\end{bmatrix}$ and $\mathbf{x}(0)=\begin{bmatrix}3\\-2\end{bmatrix}$.

::::answer[Answer]
**Answer:** $\mathbf{x}(t)=(3)e^{2t}\begin{bmatrix}1\\0\end{bmatrix} + (-2)e^{-1t}\begin{bmatrix}0\\1\end{bmatrix}$.

1. First compute the modes, showing the determinant and the eigenspace RREFs:

2. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

3. Form $A-\lambda I=\begin{bmatrix}2 - \lambda&0\\0&- \lambda - 1\end{bmatrix}$.

4. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=(2-\lambda)(-1-\lambda)-(0)(0)
   $$

5. Expand, simplify, and factor the preceding expression.

   $$
   =\lambda^{2} - \lambda - 2=\left(\lambda - 2\right) \left(\lambda + 1\right).
   $$

6. Eigenspace for $\lambda=-1$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

7. Row-reduce the homogeneous system: start with $A-(-1)I=\begin{bmatrix}3&0\\0&0\end{bmatrix}$.

8. Multiply row 1 by $\frac{1}{3}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (\frac{1}{3})R_{1}}\begin{bmatrix}1&0\\0&0\end{bmatrix}
   $$

9. The pivot columns are 1; the free variable is $x_2$.

10. The pivot equations give $x_1=0$.

11. Choose one free variable at a time and set the others to zero.

12. Clear fractions where necessary.

13. The resulting basis is $\left\{\begin{bmatrix}0\\1\end{bmatrix}\right\}$.

14. Hence $\dim E_{-1}=1$.

15. Eigenspace for $\lambda=2$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

16. Row-reduce the homogeneous system: start with $A-(2)I=\begin{bmatrix}0&0\\0&-3\end{bmatrix}$.

17. Swap rows 1 and 2 to place a nonzero pivot or reorder the equations.

   $$
   \xrightarrow{R_{1}\leftrightarrow R_{2}}\begin{bmatrix}0&-3\\0&0\end{bmatrix}
   $$

18. Multiply row 1 by $- \frac{1}{3}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (- \frac{1}{3})R_{1}}\begin{bmatrix}0&1\\0&0\end{bmatrix}
   $$

19. The pivot columns are 2; the free variable is $x_1$.

20. The pivot equations give $x_2=0$.

21. Choose one free variable at a time and set the others to zero.

22. Clear fractions where necessary.

23. The resulting basis is $\left\{\begin{bmatrix}1\\0\end{bmatrix}\right\}$.

24. Hence $\dim E_{2}=1$.

25. The roots of the factored polynomial are $\lambda=2$ (algebraic multiplicity 1), $\lambda=-1$ (algebraic multiplicity 1).

26. At $t=0$, collect eigenvectors in $P=\begin{bmatrix}1&0\\0&1\end{bmatrix}$.

27. The constant vector is found from $P\mathbf{c}=\mathbf{x}_0$:

28. Evaluate the displayed calculation.

   $$
   \begin{bmatrix}1&0\\0&1\end{bmatrix}\begin{bmatrix}c_{1}\\c_{2}\end{bmatrix}=\begin{bmatrix}3\\-2\end{bmatrix}.
   $$

29. Row reduction or substitution yields $\mathbf{c}=\begin{bmatrix}3\\-2\end{bmatrix}$.

30. Therefore

31. Evaluate the displayed calculation.

   $$
   \mathbf{x}(t)=(3)e^{2t}\begin{bmatrix}1\\0\end{bmatrix} + (-2)e^{-1t}\begin{bmatrix}0\\1\end{bmatrix}.
   $$

32. Check: $A\begin{bmatrix}0\\1\end{bmatrix}=\begin{bmatrix}0\\-1\end{bmatrix}=-1\begin{bmatrix}0\\1\end{bmatrix}$.

33. Check: $A\begin{bmatrix}1\\0\end{bmatrix}=\begin{bmatrix}2\\0\end{bmatrix}=2\begin{bmatrix}1\\0\end{bmatrix}$.

34. Check: $\mathbf{x}(0)=\begin{bmatrix}3\\-2\end{bmatrix}$, and differentiating each term multiplies that mode by $\lambda$, which is the same as applying $A$ to its eigenvector.
::::

:::


### Worked examples: Coupled initial-value system

:::example[Example 5.21 — Coupled initial-value system]
Solve $\mathbf{x}'(t)=A\mathbf{x}(t)$ with $A=\begin{bmatrix}2&1\\0&1\end{bmatrix}$ and $\mathbf{x}(0)=\begin{bmatrix}1\\2\end{bmatrix}$.

::::answer[Answer]
**Answer:** $\mathbf{x}(t)=(3)e^{2t}\begin{bmatrix}1\\0\end{bmatrix} + (2)e^{1t}\begin{bmatrix}-1\\1\end{bmatrix}$.

1. First compute the modes, showing the determinant and the eigenspace RREFs:

2. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

3. Form $A-\lambda I=\begin{bmatrix}2 - \lambda&1\\0&1 - \lambda\end{bmatrix}$.

4. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=(2-\lambda)(1-\lambda)-(1)(0)
   $$

5. Expand, simplify, and factor the preceding expression.

   $$
   =\lambda^{2} - 3 \lambda + 2=\left(\lambda - 2\right) \left(\lambda - 1\right).
   $$

6. Eigenspace for $\lambda=1$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

7. Row-reduce the homogeneous system: start with $A-(1)I=\begin{bmatrix}1&1\\0&0\end{bmatrix}$.

8. No row operation is needed; the matrix is already in reduced row-echelon form.

9. The pivot columns are 1; the free variable is $x_2$.

10. The pivot equations give $x_1=- x_{2}$.

11. Choose one free variable at a time and set the others to zero.

12. Clear fractions where necessary.

13. The resulting basis is $\left\{\begin{bmatrix}-1\\1\end{bmatrix}\right\}$.

14. Hence $\dim E_{1}=1$.

15. Eigenspace for $\lambda=2$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

16. Row-reduce the homogeneous system: start with $A-(2)I=\begin{bmatrix}0&1\\0&-1\end{bmatrix}$.

17. Replace row 2 by itself plus $1$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (1)R_{1}}\begin{bmatrix}0&1\\0&0\end{bmatrix}
   $$

18. The pivot columns are 2; the free variable is $x_1$.

19. The pivot equations give $x_2=0$.

20. Choose one free variable at a time and set the others to zero.

21. Clear fractions where necessary.

22. The resulting basis is $\left\{\begin{bmatrix}1\\0\end{bmatrix}\right\}$.

23. Hence $\dim E_{2}=1$.

24. The roots of the factored polynomial are $\lambda=2$ (algebraic multiplicity 1), $\lambda=1$ (algebraic multiplicity 1).

25. At $t=0$, collect eigenvectors in $P=\begin{bmatrix}1&-1\\0&1\end{bmatrix}$.

26. The constant vector is found from $P\mathbf{c}=\mathbf{x}_0$:

27. Evaluate the displayed calculation.

   $$
   \begin{bmatrix}1&-1\\0&1\end{bmatrix}\begin{bmatrix}c_{1}\\c_{2}\end{bmatrix}=\begin{bmatrix}1\\2\end{bmatrix}.
   $$

28. Row reduction or substitution yields $\mathbf{c}=\begin{bmatrix}3\\2\end{bmatrix}$.

29. Therefore

30. Evaluate the displayed calculation.

   $$
   \mathbf{x}(t)=(3)e^{2t}\begin{bmatrix}1\\0\end{bmatrix} + (2)e^{1t}\begin{bmatrix}-1\\1\end{bmatrix}.
   $$

31. Check: $A\begin{bmatrix}-1\\1\end{bmatrix}=\begin{bmatrix}-1\\1\end{bmatrix}=1\begin{bmatrix}-1\\1\end{bmatrix}$.

32. Check: $A\begin{bmatrix}1\\0\end{bmatrix}=\begin{bmatrix}2\\0\end{bmatrix}=2\begin{bmatrix}1\\0\end{bmatrix}$.

33. Check: $\mathbf{x}(0)=\begin{bmatrix}1\\2\end{bmatrix}$, and differentiating each term multiplies that mode by $\lambda$, which is the same as applying $A$ to its eigenvector.
::::

:::


### A fast differential-equation check

Once the constants $c_i$ have been found, the proposed solution can be verified without solving the ODE a second time. Differentiate a single mode:
$$
\frac{d}{dt}\left(c_ie^{\lambda_it}\mathbf v_i\right)
=c_i\lambda_i e^{\lambda_it}\mathbf v_i
=c_ie^{\lambda_it}A\mathbf v_i
=A\left(c_ie^{\lambda_it}\mathbf v_i\right).
$$
Adding all modes preserves the equality by linearity, so $\mathbf x'(t)=A\mathbf x(t)$. The remaining check is $\mathbf x(0)=\sum_i c_i\mathbf v_i=\mathbf x_0$. On paper, check the initial condition first: it catches a coefficient sign mistake faster than differentiating everything. If you only know the eigenvalues, you cannot determine the solution for a specific $\mathbf x_0$ until you also find an eigenvector basis and solve for the constants.

:::callout-pitfall[Pitfalls in §5.7]
(1) Forgetting to solve for $c_i$ from the initial vector. (2) Confusing the algebraic eigenvalue $\lambda$ with the exponential $e^{\lambda t}$. (3) Saying all solutions grow from a positive eigenvalue; a special initial condition may have zero coefficient for that direction.
:::

:::problem[Problem 5.29 — Initial-value system with diagonal matrix]{difficulty=standard}
Solve $\mathbf{x}'=\begin{bmatrix}1&0\\0&-2\end{bmatrix}\mathbf{x}$ with $\mathbf{x}(0)=\begin{bmatrix}3\\-1\end{bmatrix}$.

::::solution[Solution]
**Answer:** $\mathbf{x}(t)=(3e^t,-e^{-2t})^T$.

1. $A$ is diagonal.

2. Eigenvalues $\lambda_1=1$ with $\mathbf{v}_1=\mathbf{e}_1$, $\lambda_2=-2$ with $\mathbf{v}_2=\mathbf{e}_2$.

3. General solution: $\mathbf{x}(t)=c_1e^t\begin{bmatrix}1\\0\end{bmatrix}+c_2e^{-2t}\begin{bmatrix}0\\1\end{bmatrix}$.

4. Initial condition: $c_1=3, c_2=-1$.

5. Solution: $\mathbf{x}(t)=\begin{bmatrix}3e^t\\-e^{-2t}\end{bmatrix}$.

6. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

7. Form $A-\lambda I=\begin{bmatrix}1 - \lambda&0\\0&- \lambda - 2\end{bmatrix}$.

8. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=(1-\lambda)(-2-\lambda)-(0)(0)
   $$

9. Expand, simplify, and factor the preceding expression.

   $$
   =\lambda^{2} + \lambda - 2=\left(\lambda - 1\right) \left(\lambda + 2\right).
   $$

10. Eigenspace for $\lambda=-2$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

11. Row-reduce the homogeneous system: start with $A-(-2)I=\begin{bmatrix}3&0\\0&0\end{bmatrix}$.

12. Multiply row 1 by $\frac{1}{3}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (\frac{1}{3})R_{1}}\begin{bmatrix}1&0\\0&0\end{bmatrix}
   $$

13. The pivot columns are 1; the free variable is $x_2$.

14. The pivot equations give $x_1=0$.

15. Choose one free variable at a time and set the others to zero.

16. Clear fractions where necessary.

17. The resulting basis is $\left\{\begin{bmatrix}0\\1\end{bmatrix}\right\}$.

18. Hence $\dim E_{-2}=1$.

19. Eigenspace for $\lambda=1$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

20. Row-reduce the homogeneous system: start with $A-(1)I=\begin{bmatrix}0&0\\0&-3\end{bmatrix}$.

21. Swap rows 1 and 2 to place a nonzero pivot or reorder the equations.

   $$
   \xrightarrow{R_{1}\leftrightarrow R_{2}}\begin{bmatrix}0&-3\\0&0\end{bmatrix}
   $$

22. Multiply row 1 by $- \frac{1}{3}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (- \frac{1}{3})R_{1}}\begin{bmatrix}0&1\\0&0\end{bmatrix}
   $$

23. The pivot columns are 2; the free variable is $x_1$.

24. The pivot equations give $x_2=0$.

25. Choose one free variable at a time and set the others to zero.

26. Clear fractions where necessary.

27. The resulting basis is $\left\{\begin{bmatrix}1\\0\end{bmatrix}\right\}$.

28. Hence $\dim E_{1}=1$.

29. The roots of the factored polynomial are $\lambda=1$ (algebraic multiplicity 1), $\lambda=-2$ (algebraic multiplicity 1).

30. Check: $A\begin{bmatrix}0\\1\end{bmatrix}=\begin{bmatrix}0\\-2\end{bmatrix}=-2\begin{bmatrix}0\\1\end{bmatrix}$.

31. Check: $A\begin{bmatrix}1\\0\end{bmatrix}=\begin{bmatrix}1\\0\end{bmatrix}=1\begin{bmatrix}1\\0\end{bmatrix}$.
::::

:::

:::problem[Problem 5.30 — Stability of eigenmodes]{difficulty=challenge}
A linear system $\mathbf{x}'=A\mathbf{x}$ has eigenvalues $-1, -3, 2$. Will the system be stable (all solutions $\to\mathbf{0}$ as $t\to\infty$)? Explain.

::::solution[Solution]
**Answer:** No; the mode for $\lambda=2$ grows, so not every solution decays.

1. **No.** Stability requires all eigenvalues to have negative real parts.

2. The positive eigenvalue $\lambda=2$ gives a term $c_3e^{2t}\mathbf{v}_3$, which grows without bound unless $c_3=0$.

3. So for most initial conditions, the solution grows.
::::

:::


### Practice problems: Growing and decaying coordinates

:::problem[Problem 5.31 — Growing and decaying coordinates]{difficulty=easy}
Solve $\mathbf{x}'=A\mathbf{x}$ for $A=\begin{bmatrix}1&0\\0&-1\end{bmatrix}$, $\mathbf{x}(0)=\begin{bmatrix}2\\3\end{bmatrix}$.

::::solution[Solution]
**Answer:** $\mathbf{x}(t)=(3)e^{-1t}\begin{bmatrix}0\\1\end{bmatrix} + (2)e^{1t}\begin{bmatrix}1\\0\end{bmatrix}$.

1. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

2. Form $A-\lambda I=\begin{bmatrix}1 - \lambda&0\\0&- \lambda - 1\end{bmatrix}$.

3. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=(1-\lambda)(-1-\lambda)-(0)(0)
   $$

4. Expand, simplify, and factor the preceding expression.

   $$
   =\lambda^{2} - 1=\lambda^{2} - 1.
   $$

5. Eigenspace for $\lambda=-1$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

6. Row-reduce the homogeneous system: start with $A-(-1)I=\begin{bmatrix}2&0\\0&0\end{bmatrix}$.

7. Multiply row 1 by $\frac{1}{2}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (\frac{1}{2})R_{1}}\begin{bmatrix}1&0\\0&0\end{bmatrix}
   $$

8. The pivot columns are 1; the free variable is $x_2$.

9. The pivot equations give $x_1=0$.

10. Choose one free variable at a time and set the others to zero.

11. Clear fractions where necessary.

12. The resulting basis is $\left\{\begin{bmatrix}0\\1\end{bmatrix}\right\}$.

13. Hence $\dim E_{-1}=1$.

14. Eigenspace for $\lambda=1$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

15. Row-reduce the homogeneous system: start with $A-(1)I=\begin{bmatrix}0&0\\0&-2\end{bmatrix}$.

16. Swap rows 1 and 2 to place a nonzero pivot or reorder the equations.

   $$
   \xrightarrow{R_{1}\leftrightarrow R_{2}}\begin{bmatrix}0&-2\\0&0\end{bmatrix}
   $$

17. Multiply row 1 by $- \frac{1}{2}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (- \frac{1}{2})R_{1}}\begin{bmatrix}0&1\\0&0\end{bmatrix}
   $$

18. The pivot columns are 2; the free variable is $x_1$.

19. The pivot equations give $x_2=0$.

20. Choose one free variable at a time and set the others to zero.

21. Clear fractions where necessary.

22. The resulting basis is $\left\{\begin{bmatrix}1\\0\end{bmatrix}\right\}$.

23. Hence $\dim E_{1}=1$.

24. The roots of the factored polynomial are $\lambda=-1$ (algebraic multiplicity 1), $\lambda=1$ (algebraic multiplicity 1).

25. Build $P=\begin{bmatrix}0&1\\1&0\end{bmatrix}$ from eigenvectors and solve the initial condition $P\mathbf{c}=\begin{bmatrix}2\\3\end{bmatrix}$.

26. The system gives $\mathbf{c}=\begin{bmatrix}3\\2\end{bmatrix}$.

27. Consequently

28. $\mathbf{x}(t)=(3)e^{-1t}\begin{bmatrix}0\\1\end{bmatrix} + (2)e^{1t}\begin{bmatrix}1\\0\end{bmatrix}.$
29. Check at $t=0$: $P\mathbf{c}=\begin{bmatrix}2\\3\end{bmatrix}=\begin{bmatrix}2\\3\end{bmatrix}$.

30. Each exponential term differentiates into $\lambda$ times itself, exactly $A$ acting on its eigenvector.

31. Check: $A\begin{bmatrix}0\\1\end{bmatrix}=\begin{bmatrix}0\\-1\end{bmatrix}=-1\begin{bmatrix}0\\1\end{bmatrix}$.

32. Check: $A\begin{bmatrix}1\\0\end{bmatrix}=\begin{bmatrix}1\\0\end{bmatrix}=1\begin{bmatrix}1\\0\end{bmatrix}$.
::::

:::

:::problem[Problem 5.32 — Two decaying modes]{difficulty=easy}
Solve $\mathbf{x}'=A\mathbf{x}$ for $A=\begin{bmatrix}-2&0\\0&-3\end{bmatrix}$, $\mathbf{x}(0)=\begin{bmatrix}1\\-2\end{bmatrix}$.

::::solution[Solution]
**Answer:** $\mathbf{x}(t)=(-2)e^{-3t}\begin{bmatrix}0\\1\end{bmatrix} + (1)e^{-2t}\begin{bmatrix}1\\0\end{bmatrix}$.

1. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

2. Form $A-\lambda I=\begin{bmatrix}- \lambda - 2&0\\0&- \lambda - 3\end{bmatrix}$.

3. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=(-2-\lambda)(-3-\lambda)-(0)(0)
   $$

4. Expand, simplify, and factor the preceding expression.

   $$
   =\lambda^{2} + 5 \lambda + 6=\left(\lambda + 2\right) \left(\lambda + 3\right).
   $$

5. Eigenspace for $\lambda=-3$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

6. Row-reduce the homogeneous system: start with $A-(-3)I=\begin{bmatrix}1&0\\0&0\end{bmatrix}$.

7. No row operation is needed; the matrix is already in reduced row-echelon form.

8. The pivot columns are 1; the free variable is $x_2$.

9. The pivot equations give $x_1=0$.

10. Choose one free variable at a time and set the others to zero.

11. Clear fractions where necessary.

12. The resulting basis is $\left\{\begin{bmatrix}0\\1\end{bmatrix}\right\}$.

13. Hence $\dim E_{-3}=1$.

14. Eigenspace for $\lambda=-2$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

15. Row-reduce the homogeneous system: start with $A-(-2)I=\begin{bmatrix}0&0\\0&-1\end{bmatrix}$.

16. Swap rows 1 and 2 to place a nonzero pivot or reorder the equations.

   $$
   \xrightarrow{R_{1}\leftrightarrow R_{2}}\begin{bmatrix}0&-1\\0&0\end{bmatrix}
   $$

17. Multiply row 1 by $-1$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (-1)R_{1}}\begin{bmatrix}0&1\\0&0\end{bmatrix}
   $$

18. The pivot columns are 2; the free variable is $x_1$.

19. The pivot equations give $x_2=0$.

20. Choose one free variable at a time and set the others to zero.

21. Clear fractions where necessary.

22. The resulting basis is $\left\{\begin{bmatrix}1\\0\end{bmatrix}\right\}$.

23. Hence $\dim E_{-2}=1$.

24. The roots of the factored polynomial are $\lambda=-2$ (algebraic multiplicity 1), $\lambda=-3$ (algebraic multiplicity 1).

25. Build $P=\begin{bmatrix}0&1\\1&0\end{bmatrix}$ from eigenvectors and solve the initial condition $P\mathbf{c}=\begin{bmatrix}1\\-2\end{bmatrix}$.

26. The system gives $\mathbf{c}=\begin{bmatrix}-2\\1\end{bmatrix}$.

27. Consequently

28. $\mathbf{x}(t)=(-2)e^{-3t}\begin{bmatrix}0\\1\end{bmatrix} + (1)e^{-2t}\begin{bmatrix}1\\0\end{bmatrix}.$
29. Check at $t=0$: $P\mathbf{c}=\begin{bmatrix}1\\-2\end{bmatrix}=\begin{bmatrix}1\\-2\end{bmatrix}$.

30. Each exponential term differentiates into $\lambda$ times itself, exactly $A$ acting on its eigenvector.

31. Check: $A\begin{bmatrix}0\\1\end{bmatrix}=\begin{bmatrix}0\\-3\end{bmatrix}=-3\begin{bmatrix}0\\1\end{bmatrix}$.

32. Check: $A\begin{bmatrix}1\\0\end{bmatrix}=\begin{bmatrix}-2\\0\end{bmatrix}=-2\begin{bmatrix}1\\0\end{bmatrix}$.
::::

:::


### Practice problems: Coupled system by eigenvectors

:::problem[Problem 5.33 — Coupled system by eigenvectors]{difficulty=standard}
Solve $\mathbf{x}'=A\mathbf{x}$ for $A=\begin{bmatrix}3&1\\0&1\end{bmatrix}$, $\mathbf{x}(0)=\begin{bmatrix}1\\1\end{bmatrix}$.

::::solution[Solution]
**Answer:** $\mathbf{x}(t)=(\frac{1}{2})e^{1t}\begin{bmatrix}-1\\2\end{bmatrix} + (\frac{3}{2})e^{3t}\begin{bmatrix}1\\0\end{bmatrix}$.

1. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

2. Form $A-\lambda I=\begin{bmatrix}3 - \lambda&1\\0&1 - \lambda\end{bmatrix}$.

3. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=(3-\lambda)(1-\lambda)-(1)(0)
   $$

4. Expand, simplify, and factor the preceding expression.

   $$
   =\lambda^{2} - 4 \lambda + 3=\left(\lambda - 3\right) \left(\lambda - 1\right).
   $$

5. Eigenspace for $\lambda=1$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

6. Row-reduce the homogeneous system: start with $A-(1)I=\begin{bmatrix}2&1\\0&0\end{bmatrix}$.

7. Multiply row 1 by $\frac{1}{2}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (\frac{1}{2})R_{1}}\begin{bmatrix}1&\frac{1}{2}\\0&0\end{bmatrix}
   $$

8. The pivot columns are 1; the free variable is $x_2$.

9. The pivot equations give $x_1=- \frac{x_{2}}{2}$.

10. Choose one free variable at a time and set the others to zero.

11. Clear fractions where necessary.

12. The resulting basis is $\left\{\begin{bmatrix}-1\\2\end{bmatrix}\right\}$.

13. Hence $\dim E_{1}=1$.

14. Eigenspace for $\lambda=3$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

15. Row-reduce the homogeneous system: start with $A-(3)I=\begin{bmatrix}0&1\\0&-2\end{bmatrix}$.

16. Replace row 2 by itself plus $2$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (2)R_{1}}\begin{bmatrix}0&1\\0&0\end{bmatrix}
   $$

17. The pivot columns are 2; the free variable is $x_1$.

18. The pivot equations give $x_2=0$.

19. Choose one free variable at a time and set the others to zero.

20. Clear fractions where necessary.

21. The resulting basis is $\left\{\begin{bmatrix}1\\0\end{bmatrix}\right\}$.

22. Hence $\dim E_{3}=1$.

23. The roots of the factored polynomial are $\lambda=3$ (algebraic multiplicity 1), $\lambda=1$ (algebraic multiplicity 1).

24. Build $P=\begin{bmatrix}-1&1\\2&0\end{bmatrix}$ from eigenvectors and solve the initial condition $P\mathbf{c}=\begin{bmatrix}1\\1\end{bmatrix}$.

25. The system gives $\mathbf{c}=\begin{bmatrix}\frac{1}{2}\\\frac{3}{2}\end{bmatrix}$.

26. Consequently

27. $\mathbf{x}(t)=(\frac{1}{2})e^{1t}\begin{bmatrix}-1\\2\end{bmatrix} + (\frac{3}{2})e^{3t}\begin{bmatrix}1\\0\end{bmatrix}.$
28. Check at $t=0$: $P\mathbf{c}=\begin{bmatrix}1\\1\end{bmatrix}=\begin{bmatrix}1\\1\end{bmatrix}$.

29. Each exponential term differentiates into $\lambda$ times itself, exactly $A$ acting on its eigenvector.

30. Check: $A\begin{bmatrix}-1\\2\end{bmatrix}=\begin{bmatrix}-1\\2\end{bmatrix}=1\begin{bmatrix}-1\\2\end{bmatrix}$.

31. Check: $A\begin{bmatrix}1\\0\end{bmatrix}=\begin{bmatrix}3\\0\end{bmatrix}=3\begin{bmatrix}1\\0\end{bmatrix}$.
::::

:::

:::problem[Problem 5.34 — Symmetric system by eigenmodes]{difficulty=standard}
Solve $\mathbf{x}'=A\mathbf{x}$ for $A=\begin{bmatrix}2&1\\1&2\end{bmatrix}$, $\mathbf{x}(0)=\begin{bmatrix}1\\0\end{bmatrix}$.

::::solution[Solution]
**Answer:** $\mathbf{x}(t)=(- \frac{1}{2})e^{1t}\begin{bmatrix}-1\\1\end{bmatrix} + (\frac{1}{2})e^{3t}\begin{bmatrix}1\\1\end{bmatrix}$.

1. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

2. Form $A-\lambda I=\begin{bmatrix}2 - \lambda&1\\1&2 - \lambda\end{bmatrix}$.

3. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=(2-\lambda)(2-\lambda)-(1)(1)
   $$

4. Expand, simplify, and factor the preceding expression.

   $$
   =\lambda^{2} - 4 \lambda + 3=\left(\lambda - 3\right) \left(\lambda - 1\right).
   $$

5. Eigenspace for $\lambda=1$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

6. Row-reduce the homogeneous system: start with $A-(1)I=\begin{bmatrix}1&1\\1&1\end{bmatrix}$.

7. Replace row 2 by itself plus $-1$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (-1)R_{1}}\begin{bmatrix}1&1\\0&0\end{bmatrix}
   $$

8. The pivot columns are 1; the free variable is $x_2$.

9. The pivot equations give $x_1=- x_{2}$.

10. Choose one free variable at a time and set the others to zero.

11. Clear fractions where necessary.

12. The resulting basis is $\left\{\begin{bmatrix}-1\\1\end{bmatrix}\right\}$.

13. Hence $\dim E_{1}=1$.

14. Eigenspace for $\lambda=3$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

15. Row-reduce the homogeneous system: start with $A-(3)I=\begin{bmatrix}-1&1\\1&-1\end{bmatrix}$.

16. Multiply row 1 by $-1$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (-1)R_{1}}\begin{bmatrix}1&-1\\1&-1\end{bmatrix}
   $$

17. Replace row 2 by itself plus $-1$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (-1)R_{1}}\begin{bmatrix}1&-1\\0&0\end{bmatrix}
   $$

18. The pivot columns are 1; the free variable is $x_2$.

19. The pivot equations give $x_1=x_{2}$.

20. Choose one free variable at a time and set the others to zero.

21. Clear fractions where necessary.

22. The resulting basis is $\left\{\begin{bmatrix}1\\1\end{bmatrix}\right\}$.

23. Hence $\dim E_{3}=1$.

24. The roots of the factored polynomial are $\lambda=3$ (algebraic multiplicity 1), $\lambda=1$ (algebraic multiplicity 1).

25. Build $P=\begin{bmatrix}-1&1\\1&1\end{bmatrix}$ from eigenvectors and solve the initial condition $P\mathbf{c}=\begin{bmatrix}1\\0\end{bmatrix}$.

26. The system gives $\mathbf{c}=\begin{bmatrix}- \frac{1}{2}\\\frac{1}{2}\end{bmatrix}$.

27. Consequently

28. $\mathbf{x}(t)=(- \frac{1}{2})e^{1t}\begin{bmatrix}-1\\1\end{bmatrix} + (\frac{1}{2})e^{3t}\begin{bmatrix}1\\1\end{bmatrix}.$
29. Check at $t=0$: $P\mathbf{c}=\begin{bmatrix}1\\0\end{bmatrix}=\begin{bmatrix}1\\0\end{bmatrix}$.

30. Each exponential term differentiates into $\lambda$ times itself, exactly $A$ acting on its eigenvector.

31. Check: $A\begin{bmatrix}-1\\1\end{bmatrix}=\begin{bmatrix}-1\\1\end{bmatrix}=1\begin{bmatrix}-1\\1\end{bmatrix}$.

32. Check: $A\begin{bmatrix}1\\1\end{bmatrix}=\begin{bmatrix}3\\3\end{bmatrix}=3\begin{bmatrix}1\\1\end{bmatrix}$.
::::

:::


### Practice problems: Nontriangular initial-value system

:::problem[Problem 5.35 — Nontriangular initial-value system]{difficulty=challenge}
Solve $\mathbf{x}'=A\mathbf{x}$ for $A=\begin{bmatrix}0&1\\-2&3\end{bmatrix}$, $\mathbf{x}(0)=\begin{bmatrix}2\\1\end{bmatrix}$.

::::solution[Solution]
**Answer:** $\mathbf{x}(t)=(3)e^{1t}\begin{bmatrix}1\\1\end{bmatrix} + (-1)e^{2t}\begin{bmatrix}1\\2\end{bmatrix}$.

1. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

2. Form $A-\lambda I=\begin{bmatrix}- \lambda&1\\-2&3 - \lambda\end{bmatrix}$.

3. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=(0-\lambda)(3-\lambda)-(1)(-2)
   $$

4. Expand, simplify, and factor the preceding expression.

   $$
   =\lambda^{2} - 3 \lambda + 2=\left(\lambda - 2\right) \left(\lambda - 1\right).
   $$

5. Eigenspace for $\lambda=1$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

6. Row-reduce the homogeneous system: start with $A-(1)I=\begin{bmatrix}-1&1\\-2&2\end{bmatrix}$.

7. Multiply row 1 by $-1$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (-1)R_{1}}\begin{bmatrix}1&-1\\-2&2\end{bmatrix}
   $$

8. Replace row 2 by itself plus $2$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (2)R_{1}}\begin{bmatrix}1&-1\\0&0\end{bmatrix}
   $$

9. The pivot columns are 1; the free variable is $x_2$.

10. The pivot equations give $x_1=x_{2}$.

11. Choose one free variable at a time and set the others to zero.

12. Clear fractions where necessary.

13. The resulting basis is $\left\{\begin{bmatrix}1\\1\end{bmatrix}\right\}$.

14. Hence $\dim E_{1}=1$.

15. Eigenspace for $\lambda=2$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

16. Row-reduce the homogeneous system: start with $A-(2)I=\begin{bmatrix}-2&1\\-2&1\end{bmatrix}$.

17. Multiply row 1 by $- \frac{1}{2}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (- \frac{1}{2})R_{1}}\begin{bmatrix}1&- \frac{1}{2}\\-2&1\end{bmatrix}
   $$

18. Replace row 2 by itself plus $2$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (2)R_{1}}\begin{bmatrix}1&- \frac{1}{2}\\0&0\end{bmatrix}
   $$

19. The pivot columns are 1; the free variable is $x_2$.

20. The pivot equations give $x_1=\frac{x_{2}}{2}$.

21. Choose one free variable at a time and set the others to zero.

22. Clear fractions where necessary.

23. The resulting basis is $\left\{\begin{bmatrix}1\\2\end{bmatrix}\right\}$.

24. Hence $\dim E_{2}=1$.

25. The roots of the factored polynomial are $\lambda=2$ (algebraic multiplicity 1), $\lambda=1$ (algebraic multiplicity 1).

26. Build $P=\begin{bmatrix}1&1\\1&2\end{bmatrix}$ from eigenvectors and solve the initial condition $P\mathbf{c}=\begin{bmatrix}2\\1\end{bmatrix}$.

27. The system gives $\mathbf{c}=\begin{bmatrix}3\\-1\end{bmatrix}$.

28. Consequently

29. $\mathbf{x}(t)=(3)e^{1t}\begin{bmatrix}1\\1\end{bmatrix} + (-1)e^{2t}\begin{bmatrix}1\\2\end{bmatrix}.$
30. Check at $t=0$: $P\mathbf{c}=\begin{bmatrix}2\\1\end{bmatrix}=\begin{bmatrix}2\\1\end{bmatrix}$.

31. Each exponential term differentiates into $\lambda$ times itself, exactly $A$ acting on its eigenvector.

32. Check: $A\begin{bmatrix}1\\1\end{bmatrix}=\begin{bmatrix}1\\1\end{bmatrix}=1\begin{bmatrix}1\\1\end{bmatrix}$.

33. Check: $A\begin{bmatrix}1\\2\end{bmatrix}=\begin{bmatrix}2\\4\end{bmatrix}=2\begin{bmatrix}1\\2\end{bmatrix}$.
::::

:::

## 5.9 Applications to Markov Chains


:::callout-intuition[Intuition]
A **Markov chain** models a system that randomly transitions between states. At each step, the probabilities of future states depend only on the current state, not on history. Eigenvalue theory tells us about long-run behavior: does the system settle to a steady state?

A Markov transition redistributes a fixed total of probability or population. A steady state is the one nonnegative probability vector that comes back to itself after a step: $P\mathbf{q}=\mathbf{q}$. Because the multiplier is 1, it is just an eigenvector in $E_1$, scaled so its coordinates add to 1. The sum-to-one equation is essential: the zero vector also solves the homogeneous equation but is not a probability distribution.
:::

:::callout-tip[Read the columns, not the rows]
The entry in row $i$, column $j$ is the probability of going **from** state $j$ **to** state $i$. Each column must sum to 1. Multiply $P\mathbf{x}_0$ for one step, $P^2\mathbf{x}_0$ for two. For the steady state, row-reduce $P-I$, choose a nonnegative null-space direction, and divide by the sum of its entries. Regularity (some positive matrix power) justifies uniqueness and convergence.
:::

:::theorem[Stochasticity is preserved]
If the columns of $P$ each sum to one and have nonnegative entries, then $P\mathbf{x}$ is again a probability vector whenever $\mathbf{x}$ is. Indeed $\mathbf{1}^TP=\mathbf{1}^T$, so $\mathbf{1}^TP\mathbf{x}=\mathbf{1}^T\mathbf{x}=1$, and all coordinates of $P\mathbf{x}$ are nonnegative.
:::

:::definition[Definition 5.6 — Stochastic Matrix and Probability Vector]
A **probability vector** is a vector with nonnegative entries summing to 1.

A **stochastic (Markov) matrix** is a square matrix whose columns are probability vectors. That is, all entries are $\ge 0$ and each column sums to 1.

If $P$ is a stochastic matrix and $\mathbf{x}_0$ is a probability vector, then $\mathbf{x}_k=P\mathbf{x}_{k-1}=P^k\mathbf{x}_0$ represents the state distribution after $k$ steps.
:::

<figure class="fig">
<svg class="fig-hue-6" viewBox="0 0 440 240" role="img" aria-label="Two-state Markov chain with self-loops and transitions, labeled by departure-state probabilities.">
<circle class="fig-curve" cx="110" cy="105" r="30"/><circle class="fig-curve" cx="330" cy="105" r="30"/><text class="fig-label-em" x="104" y="109">1</text><text class="fig-label-em" x="324" y="109">2</text><path class="fig-curve" d="M140 91 Q220 29 300 91"/><path class="fig-arrow" d="M288 82 L300 91 L282 93"/><path class="fig-curve-alt" d="M300 121 Q220 181 140 121"/><path class="fig-arrow" d="M150 133 L140 121 L158 119"/><path class="fig-curve" d="M89 78 C40 24 35 161 89 132"/><path class="fig-arrow" d="M84 142 L89 132 L77 132"/><path class="fig-curve-alt" d="M350 78 C403 22 405 165 350 132"/><path class="fig-arrow" d="M362 136 L350 132 L358 147"/><text class="fig-label" x="210" y="56">0.2</text><text class="fig-label" x="210" y="164">0.3</text><text class="fig-label" x="28" y="101">0.8</text><text class="fig-label" x="393" y="101">0.7</text>
</svg>
<figcaption>In the column-stochastic matrix $P=\begin{bmatrix}0.8&0.3\\0.2&0.7\end{bmatrix}$, each arrow leaves its origin state. The $1\to2$ probability is $0.2$, and the $2\to1$ probability is $0.3$.</figcaption>
</figure>

:::callout-key[Key Fact: Eigenvalue 1]
Every stochastic matrix has eigenvalue $\lambda=1$. (Proof: each column sums to 1, so the row vector $[1,1,\ldots,1]$ satisfies $[1,\ldots,1]A=[1,\ldots,1]$, meaning 1 is an eigenvalue of $A^T$, hence also of $A$.)
:::

:::definition[Definition 5.7 — Steady-State Vector]
A **steady-state vector** (or equilibrium vector) of a stochastic matrix $P$ is a probability vector $\mathbf{q}$ such that $P\mathbf{q}=\mathbf{q}$, i.e., $\mathbf{q}\in E_1=\Nul(P-I)$ and all entries of $\mathbf{q}$ are nonnegative and sum to 1.
:::

:::theorem[Theorem 5.10 — Perron–Frobenius (Special Case)]
A **regular** stochastic matrix (some power of it has all positive entries) has a unique steady-state vector $\mathbf{q}$, and for any initial probability vector $\mathbf{x}_0$:

$$
\lim_{k\to\infty} P^k\mathbf{x}_0 = \mathbf{q}
$$

The long-run distribution is independent of the starting state.
:::


### Worked examples: Finding the Steady-State Vector

:::example[Example 5.22 — Finding the Steady-State Vector]
A Markov chain has transition matrix $P=\begin{bmatrix}0.7&0.2\\0.3&0.8\end{bmatrix}$. Find the steady-state vector.

::::answer[Answer]
**Answer:** $\mathbf{q}=(2/5,3/5)^T$.

1. Find $\Nul(P-I)$:

2. Evaluate the displayed calculation.

   $$
   P-I=\begin{bmatrix}-0.3&0.2\\0.3&-0.2\end{bmatrix}\to\begin{bmatrix}3&-2\\0&0\end{bmatrix}
   $$

3. General solution: $x_1=\frac{2}{3}x_2$.

4. Set $x_2=3$: $\mathbf{q}_{\text{unnorm}}=\begin{bmatrix}2\\3\end{bmatrix}$.

5. Total = 5.

6. Normalize: $\mathbf{q}=\begin{bmatrix}2/5\\3/5\end{bmatrix}$.

7. **Interpretation:** In the long run, 40% of the time is spent in state 1, 60% in state 2, regardless of starting state.
::::

:::

:::example[Example 5.23 — Migration Markov Chain]
A city/suburb model: each year, 5% of city residents move to suburbs, 3% of suburb residents move to city. The transition matrix is

$$
P=\begin{bmatrix}0.95&0.03\\0.05&0.97\end{bmatrix}
$$

 Currently the population is 60% city, 40% suburb. Find the steady-state distribution.

::::answer[Answer]
**Answer:** $\mathbf{q}=(3/8,5/8)^T$.

1. Solve $P\mathbf{q}=\mathbf{q}$: $(P-I)\mathbf{q}=\mathbf{0}$:

2. Evaluate the displayed calculation.

   $$
   \begin{bmatrix}-0.05&0.03\\0.05&-0.03\end{bmatrix}\to\begin{bmatrix}5&-3\\0&0\end{bmatrix}
   $$

3. So $5q_1=3q_2$.

4. With $q_1+q_2=1$: $q_1+\frac{5}{3}q_1=1\Rightarrow \frac{8}{3}q_1=1\Rightarrow q_1=\frac{3}{8}$.

5. Evaluate the displayed calculation.

   $$
   \mathbf{q}=\begin{bmatrix}3/8\\5/8\end{bmatrix}\approx\begin{bmatrix}0.375\\0.625\end{bmatrix}
   $$

6. **Long-run:** Regardless of current population split, the city will stabilize at 37.5% and suburbs at 62.5% of total population.

7. Note the starting $[0.6, 0.4]$ is irrelevant in the long run.
::::

:::

:::example[Example 5.24 — Transient Behavior of a Markov Chain]
Using the city/suburb model above, find the distribution after exactly 2 years starting from state $\mathbf{x}_0=[0.6, 0.4]^T$.

::::answer[Answer]
**Answer:** $\mathbf{x}_2=(0.56544,0.43456)^T$, approximately $(0.5654,0.4346)^T$.

1. Use the Markov update $x_{k+1}=Px_k$ with $P=\begin{bmatrix}0.95&0.03\\0.05&0.97\end{bmatrix}$ and $x_0=(0.6,0.4)^T$.

2. After one year, compute the first coordinate $0.95(0.6)+0.03(0.4)=0.57+0.012=0.582$.

3. Compute the second coordinate $0.05(0.6)+0.97(0.4)=0.03+0.388=0.418$. Thus $x_1=(0.582,0.418)^T$.

4. After two years, the first coordinate is $0.95(0.582)+0.03(0.418)=0.5529+0.01254=0.56544$.

5. The second coordinate is $0.05(0.582)+0.97(0.418)=0.0291+0.40546=0.43456$.

6. The distribution is moving toward the steady state $(0.375,0.625)^T$. Check: $0.56544+0.43456=1$ and both probabilities are nonnegative.
::::

:::


<figure class="fig">
<svg class="fig-hue-2" viewBox="0 0 440 240" role="img" aria-label="Two state-probability trajectories converge to steady probabilities 0.6 and 0.4.">
<line class="fig-axis" x1="46.0" y1="183.0" x2="389.2" y2="183.0"/><line class="fig-axis" x1="46.0" y1="183.0" x2="46.0" y2="77.4"/><path class="fig-curve" d="M46.0,95.0 L90.0,112.6 L134.0,121.4 L178.0,125.8 L222.0,128.0 L266.0,129.1 L310.0,129.6 L354.0,129.9"/><path class="fig-curve-alt" d="M46.0,183.0 L90.0,165.4 L134.0,156.6 L178.0,152.2 L222.0,150.0 L266.0,148.9 L310.0,148.3 L354.0,148.1"/><line class="fig-guide" x1="46.0" y1="130.2" x2="367.2" y2="130.2"/><line class="fig-guide" x1="46.0" y1="147.8" x2="367.2" y2="147.8"/><text class="fig-label" x="327.6" y="120.5">0.6</text><text class="fig-label" x="327.6" y="154.4">0.4</text><text class="fig-label" x="369.4" y="189.6">k</text>
</svg>
<figcaption>Starting at $x_0=(1,0)^T$, the two state probabilities approach $(0.6,0.4)^T$ under $x_{k+1}=Px_k$. The deviations shrink by the second eigenvalue $1/2$ each step.</figcaption>
</figure>

:::example[Example 5.25 — Integer fractions, one steady state]
For the column-stochastic transition matrix $P=\begin{bmatrix}\frac{3}{4}&\frac{1}{4}\\\frac{1}{4}&\frac{3}{4}\end{bmatrix}$ and $\mathbf{x}_0=\begin{bmatrix}1\\0\end{bmatrix}$, find the steady-state vector and the next two distributions.

::::answer[Answer]
**Answer:** $\mathbf{q}=\begin{bmatrix}\frac{1}{2}\\\frac{1}{2}\end{bmatrix}$, $\mathbf{x}_1=\begin{bmatrix}\frac{3}{4}\\\frac{1}{4}\end{bmatrix}$, and $\mathbf{x}_2=\begin{bmatrix}\frac{5}{8}\\\frac{3}{8}\end{bmatrix}$.

1. Check the columns: their sums are 1 and 1, and every entry is nonnegative.

2. Find the eigenspaces using the usual determinant and homogeneous row reduction:

3. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

4. Form $A-\lambda I=\begin{bmatrix}\frac{3}{4} - \lambda&\frac{1}{4}\\\frac{1}{4}&\frac{3}{4} - \lambda\end{bmatrix}$.

5. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=(\frac{3}{4}-\lambda)(\frac{3}{4}-\lambda)-(\frac{1}{4})(\frac{1}{4})
   $$

6. Expand, simplify, and factor the preceding expression.

   $$
   =\lambda^{2} - \frac{3 \lambda}{2} + \frac{1}{2}=\frac{\left(\lambda - 1\right) \left(2 \lambda - 1\right)}{2}.
   $$

7. Eigenspace for $\lambda=\frac{1}{2}$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

8. Row-reduce the homogeneous system: start with $A-(\frac{1}{2})I=\begin{bmatrix}\frac{1}{4}&\frac{1}{4}\\\frac{1}{4}&\frac{1}{4}\end{bmatrix}$.

9. Multiply row 1 by $4$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (4)R_{1}}\begin{bmatrix}1&1\\\frac{1}{4}&\frac{1}{4}\end{bmatrix}
   $$

10. Replace row 2 by itself plus $- \frac{1}{4}$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (- \frac{1}{4})R_{1}}\begin{bmatrix}1&1\\0&0\end{bmatrix}
   $$

11. The pivot columns are 1; the free variable is $x_2$.

12. The pivot equations give $x_1=- x_{2}$.

13. The resulting basis is $\left\{\begin{bmatrix}-1\\1\end{bmatrix}\right\}$.

14. Hence $\dim E_{\frac{1}{2}}=1$.

15. Eigenspace for $\lambda=1$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

16. Row-reduce the homogeneous system: start with $A-(1)I=\begin{bmatrix}- \frac{1}{4}&\frac{1}{4}\\\frac{1}{4}&- \frac{1}{4}\end{bmatrix}$.

17. Multiply row 1 by $-4$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (-4)R_{1}}\begin{bmatrix}1&-1\\\frac{1}{4}&- \frac{1}{4}\end{bmatrix}
   $$

18. Replace row 2 by itself plus $- \frac{1}{4}$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (- \frac{1}{4})R_{1}}\begin{bmatrix}1&-1\\0&0\end{bmatrix}
   $$

19. The pivot columns are 1; the free variable is $x_2$.

20. The pivot equations give $x_1=x_{2}$.

21. The resulting basis is $\left\{\begin{bmatrix}1\\1\end{bmatrix}\right\}$.

22. Hence $\dim E_{1}=1$.

23. Use the $\lambda=1$ null-space basis vector $\begin{bmatrix}1\\1\end{bmatrix}$, whose entries sum to $2$.

24. Divide by that sum to get $\mathbf{q}=\begin{bmatrix}\frac{1}{2}\\\frac{1}{2}\end{bmatrix}$.

25. Verify directly $P\mathbf{q}=\begin{bmatrix}\frac{1}{2}\\\frac{1}{2}\end{bmatrix}=\mathbf{q}$.

26. One step is $P\mathbf{x}_0=\begin{bmatrix}\frac{3}{4}&\frac{1}{4}\\\frac{1}{4}&\frac{3}{4}\end{bmatrix}\begin{bmatrix}1\\0\end{bmatrix}=\begin{bmatrix}\frac{3}{4}\\\frac{1}{4}\end{bmatrix}$.

27. A second is $P\mathbf{x}_1=\begin{bmatrix}\frac{3}{4}&\frac{1}{4}\\\frac{1}{4}&\frac{3}{4}\end{bmatrix}\begin{bmatrix}\frac{3}{4}\\\frac{1}{4}\end{bmatrix}=\begin{bmatrix}\frac{5}{8}\\\frac{3}{8}\end{bmatrix}$.

28. These are finite-time states, **not** the same question as steady state.

29. Check: $A\begin{bmatrix}-1\\1\end{bmatrix}=\begin{bmatrix}- \frac{1}{2}\\\frac{1}{2}\end{bmatrix}=\frac{1}{2}\begin{bmatrix}-1\\1\end{bmatrix}$.

30. Check: $A\begin{bmatrix}1\\1\end{bmatrix}=\begin{bmatrix}1\\1\end{bmatrix}=1\begin{bmatrix}1\\1\end{bmatrix}$.
::::

:::


### Worked examples: The steady state need not be uniform

:::example[Example 5.26 — The steady state need not be uniform]
For the column-stochastic transition matrix $P=\begin{bmatrix}\frac{3}{4}&\frac{1}{2}\\\frac{1}{4}&\frac{1}{2}\end{bmatrix}$ and $\mathbf{x}_0=\begin{bmatrix}0\\1\end{bmatrix}$, find the steady-state vector and the next two distributions.

::::answer[Answer]
**Answer:** $\mathbf{q}=\begin{bmatrix}\frac{2}{3}\\\frac{1}{3}\end{bmatrix}$, $\mathbf{x}_1=\begin{bmatrix}\frac{1}{2}\\\frac{1}{2}\end{bmatrix}$, and $\mathbf{x}_2=\begin{bmatrix}\frac{5}{8}\\\frac{3}{8}\end{bmatrix}$.

1. Check the columns: their sums are 1 and 1, and every entry is nonnegative.

2. Find the eigenspaces using the usual determinant and homogeneous row reduction:

3. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

4. Form $A-\lambda I=\begin{bmatrix}\frac{3}{4} - \lambda&\frac{1}{2}\\\frac{1}{4}&\frac{1}{2} - \lambda\end{bmatrix}$.

5. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=(\frac{3}{4}-\lambda)(\frac{1}{2}-\lambda)-(\frac{1}{2})(\frac{1}{4})
   $$

6. Expand, simplify, and factor the preceding expression.

   $$
   =\lambda^{2} - \frac{5 \lambda}{4} + \frac{1}{4}=\frac{\left(\lambda - 1\right) \left(4 \lambda - 1\right)}{4}.
   $$

7. Eigenspace for $\lambda=\frac{1}{4}$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

8. Row-reduce the homogeneous system: start with $A-(\frac{1}{4})I=\begin{bmatrix}\frac{1}{2}&\frac{1}{2}\\\frac{1}{4}&\frac{1}{4}\end{bmatrix}$.

9. Multiply row 1 by $2$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (2)R_{1}}\begin{bmatrix}1&1\\\frac{1}{4}&\frac{1}{4}\end{bmatrix}
   $$

10. Replace row 2 by itself plus $- \frac{1}{4}$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (- \frac{1}{4})R_{1}}\begin{bmatrix}1&1\\0&0\end{bmatrix}
   $$

11. The pivot columns are 1; the free variable is $x_2$.

12. The pivot equations give $x_1=- x_{2}$.

13. The resulting basis is $\left\{\begin{bmatrix}-1\\1\end{bmatrix}\right\}$.

14. Hence $\dim E_{\frac{1}{4}}=1$.

15. Eigenspace for $\lambda=1$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

16. Row-reduce the homogeneous system: start with $A-(1)I=\begin{bmatrix}- \frac{1}{4}&\frac{1}{2}\\\frac{1}{4}&- \frac{1}{2}\end{bmatrix}$.

17. Multiply row 1 by $-4$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (-4)R_{1}}\begin{bmatrix}1&-2\\\frac{1}{4}&- \frac{1}{2}\end{bmatrix}
   $$

18. Replace row 2 by itself plus $- \frac{1}{4}$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (- \frac{1}{4})R_{1}}\begin{bmatrix}1&-2\\0&0\end{bmatrix}
   $$

19. The pivot columns are 1; the free variable is $x_2$.

20. The pivot equations give $x_1=2 x_{2}$.

21. The resulting basis is $\left\{\begin{bmatrix}2\\1\end{bmatrix}\right\}$.

22. Hence $\dim E_{1}=1$.

23. Use the $\lambda=1$ null-space basis vector $\begin{bmatrix}2\\1\end{bmatrix}$, whose entries sum to $3$.

24. Divide by that sum to get $\mathbf{q}=\begin{bmatrix}\frac{2}{3}\\\frac{1}{3}\end{bmatrix}$.

25. Verify directly $P\mathbf{q}=\begin{bmatrix}\frac{2}{3}\\\frac{1}{3}\end{bmatrix}=\mathbf{q}$.

26. One step is $P\mathbf{x}_0=\begin{bmatrix}\frac{3}{4}&\frac{1}{2}\\\frac{1}{4}&\frac{1}{2}\end{bmatrix}\begin{bmatrix}0\\1\end{bmatrix}=\begin{bmatrix}\frac{1}{2}\\\frac{1}{2}\end{bmatrix}$.

27. A second is $P\mathbf{x}_1=\begin{bmatrix}\frac{3}{4}&\frac{1}{2}\\\frac{1}{4}&\frac{1}{2}\end{bmatrix}\begin{bmatrix}\frac{1}{2}\\\frac{1}{2}\end{bmatrix}=\begin{bmatrix}\frac{5}{8}\\\frac{3}{8}\end{bmatrix}$.

28. These are finite-time states, **not** the same question as steady state.

29. Check: $A\begin{bmatrix}-1\\1\end{bmatrix}=\begin{bmatrix}- \frac{1}{4}\\\frac{1}{4}\end{bmatrix}=\frac{1}{4}\begin{bmatrix}-1\\1\end{bmatrix}$.

30. Check: $A\begin{bmatrix}2\\1\end{bmatrix}=\begin{bmatrix}2\\1\end{bmatrix}=1\begin{bmatrix}2\\1\end{bmatrix}$.
::::

:::

:::callout-pitfall[Pitfalls in §5.9]
(1) Checking row sums rather than column sums. (2) Treating the unnormalized null-space vector as a probability vector. (3) Mistaking an eigenvalue-1 eigenvector for the unique limiting state without checking regularity. (4) Computing one or two steps instead of a steady state when the question says long run.
:::

:::problem[Problem 5.36 — Two-state stationary distribution]{difficulty=easy}
Verify that $\begin{bmatrix}0.8&0.4\\0.2&0.6\end{bmatrix}$ is a stochastic matrix and find its steady-state vector.

::::solution[Solution]
**Answer:** Stochastic; $\mathbf{q}=(2/3,1/3)^T$.

1. Both columns sum to 1 and all entries $\ge 0$: stochastic. ✓

2. Solve $(P-I)\mathbf{q}=\mathbf{0}$: $\begin{bmatrix}-0.2&0.4\\0.2&-0.4\end{bmatrix}\to\begin{bmatrix}1&-2\\0&0\end{bmatrix}$.

3. So $q_1=2q_2$.

4. With $q_1+q_2=1$: $q_2=1/3, q_1=2/3$.

5. Steady state: $\begin{bmatrix}2/3\\1/3\end{bmatrix}$.

6. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

7. Form $A-\lambda I=\begin{bmatrix}\frac{4}{5} - \lambda&\frac{2}{5}\\\frac{1}{5}&\frac{3}{5} - \lambda\end{bmatrix}$.

8. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=(\frac{4}{5}-\lambda)(\frac{3}{5}-\lambda)-(\frac{2}{5})(\frac{1}{5})
   $$

9. Expand, simplify, and factor the preceding expression.

   $$
   =\lambda^{2} - \frac{7 \lambda}{5} + \frac{2}{5}=\frac{\left(\lambda - 1\right) \left(5 \lambda - 2\right)}{5}.
   $$

10. Eigenspace for $\lambda=\frac{2}{5}$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

11. Row-reduce the homogeneous system: start with $A-(\frac{2}{5})I=\begin{bmatrix}\frac{2}{5}&\frac{2}{5}\\\frac{1}{5}&\frac{1}{5}\end{bmatrix}$.

12. Multiply row 1 by $\frac{5}{2}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (\frac{5}{2})R_{1}}\begin{bmatrix}1&1\\\frac{1}{5}&\frac{1}{5}\end{bmatrix}
   $$

13. Replace row 2 by itself plus $- \frac{1}{5}$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (- \frac{1}{5})R_{1}}\begin{bmatrix}1&1\\0&0\end{bmatrix}
   $$

14. The pivot columns are 1; the free variable is $x_2$.

15. The pivot equations give $x_1=- x_{2}$.

16. The resulting basis is $\left\{\begin{bmatrix}-1\\1\end{bmatrix}\right\}$.

17. Hence $\dim E_{\frac{2}{5}}=1$.

18. Eigenspace for $\lambda=1$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

19. Row-reduce the homogeneous system: start with $A-(1)I=\begin{bmatrix}- \frac{1}{5}&\frac{2}{5}\\\frac{1}{5}&- \frac{2}{5}\end{bmatrix}$.

20. Multiply row 1 by $-5$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (-5)R_{1}}\begin{bmatrix}1&-2\\\frac{1}{5}&- \frac{2}{5}\end{bmatrix}
   $$

21. Replace row 2 by itself plus $- \frac{1}{5}$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (- \frac{1}{5})R_{1}}\begin{bmatrix}1&-2\\0&0\end{bmatrix}
   $$

22. The pivot columns are 1; the free variable is $x_2$.

23. The pivot equations give $x_1=2 x_{2}$.

24. The resulting basis is $\left\{\begin{bmatrix}2\\1\end{bmatrix}\right\}$.

25. Hence $\dim E_{1}=1$.

26. Check: $A\begin{bmatrix}-1\\1\end{bmatrix}=\begin{bmatrix}- \frac{2}{5}\\\frac{2}{5}\end{bmatrix}=\frac{2}{5}\begin{bmatrix}-1\\1\end{bmatrix}$.

27. Check: $A\begin{bmatrix}2\\1\end{bmatrix}=\begin{bmatrix}2\\1\end{bmatrix}=1\begin{bmatrix}2\\1\end{bmatrix}$.
::::

:::


### Practice problems: Three-state steady state

:::problem[Problem 5.37 — Three-state steady state]{difficulty=standard}
A $3$-state Markov chain has transition matrix $P=\begin{bmatrix}0.5&0.3&0.2\\0.3&0.4&0.3\\0.2&0.3&0.5\end{bmatrix}$. Find the steady-state vector.

::::solution[Solution]
**Answer:** $\mathbf{q}=(1/3,1/3,1/3)^T$.

1. Solve $(P-I)\mathbf{q}=\mathbf{0}$ with constraint $q_1+q_2+q_3=1$.

2. $P-I$: first row $(-0.5, 0.3, 0.2)$, etc.

3. Row reducing (augmented with normalization): by symmetry, $q_1=q_3$.

4. Let $q_1=q_3=s$, $q_2=t$.

5. From row 1: $-0.5s+0.3t+0.2s=0\Rightarrow 0.3t=0.3s\Rightarrow t=s$.

6. Thus $q_1=q_2=q_3=1/3$.

7. Steady state: $\begin{bmatrix}1/3\\1/3\\1/3\end{bmatrix}$.

8. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

9. Form $A-\lambda I=\begin{bmatrix}\frac{1}{2} - \lambda&\frac{3}{10}&\frac{1}{5}\\\frac{3}{10}&\frac{2}{5} - \lambda&\frac{3}{10}\\\frac{1}{5}&\frac{3}{10}&\frac{1}{2} - \lambda\end{bmatrix}$.

10. Expand along column 1, which has the most zeros (ties favor columns).

11. The cofactor signs alternate $+,-,+$ across the first row.

12. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=(\frac{1}{2} - \lambda)\left[(\frac{2}{5} - \lambda)(\frac{1}{2} - \lambda)-(\frac{3}{10})(\frac{3}{10})\right]-(\frac{3}{10})\left[(\frac{3}{10})(\frac{1}{2} - \lambda)-(\frac{1}{5})(\frac{3}{10})\right]+(\frac{1}{5})\left[(\frac{3}{10})(\frac{3}{10})-(\frac{1}{5})(\frac{2}{5} - \lambda)\right]
   $$

13. Expand, simplify, and factor the preceding expression.

   $$
   =- \lambda^{3} + \frac{7 \lambda^{2}}{5} - \frac{43 \lambda}{100} + \frac{3}{100}=- \frac{\left(\lambda - 1\right) \left(10 \lambda - 3\right) \left(10 \lambda - 1\right)}{100}.
   $$

14. Eigenspace for $\lambda=\frac{1}{10}$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

15. Row-reduce the homogeneous system: start with $A-(\frac{1}{10})I=\begin{bmatrix}\frac{2}{5}&\frac{3}{10}&\frac{1}{5}\\\frac{3}{10}&\frac{3}{10}&\frac{3}{10}\\\frac{1}{5}&\frac{3}{10}&\frac{2}{5}\end{bmatrix}$.

16. Multiply row 1 by $\frac{5}{2}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (\frac{5}{2})R_{1}}\begin{bmatrix}1&\frac{3}{4}&\frac{1}{2}\\\frac{3}{10}&\frac{3}{10}&\frac{3}{10}\\\frac{1}{5}&\frac{3}{10}&\frac{2}{5}\end{bmatrix}
   $$

17. Replace row 2 by itself plus $- \frac{3}{10}$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (- \frac{3}{10})R_{1}}\begin{bmatrix}1&\frac{3}{4}&\frac{1}{2}\\0&\frac{3}{40}&\frac{3}{20}\\\frac{1}{5}&\frac{3}{10}&\frac{2}{5}\end{bmatrix}
   $$

18. Replace row 3 by itself plus $- \frac{1}{5}$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{3}\leftarrow R_{3} + (- \frac{1}{5})R_{1}}\begin{bmatrix}1&\frac{3}{4}&\frac{1}{2}\\0&\frac{3}{40}&\frac{3}{20}\\0&\frac{3}{20}&\frac{3}{10}\end{bmatrix}
   $$

19. Multiply row 2 by $\frac{40}{3}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{2}\leftarrow (\frac{40}{3})R_{2}}\begin{bmatrix}1&\frac{3}{4}&\frac{1}{2}\\0&1&2\\0&\frac{3}{20}&\frac{3}{10}\end{bmatrix}
   $$

20. Replace row 1 by itself plus $- \frac{3}{4}$ times row 2 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{1}\leftarrow R_{1} + (- \frac{3}{4})R_{2}}\begin{bmatrix}1&0&-1\\0&1&2\\0&\frac{3}{20}&\frac{3}{10}\end{bmatrix}
   $$

21. Replace row 3 by itself plus $- \frac{3}{20}$ times row 2 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{3}\leftarrow R_{3} + (- \frac{3}{20})R_{2}}\begin{bmatrix}1&0&-1\\0&1&2\\0&0&0\end{bmatrix}
   $$

22. The pivot columns are 1, 2; the free variable is $x_3$.

23. The pivot equations give $x_1=x_{3}$, $x_2=- 2 x_{3}$.

24. The resulting basis is $\left\{\begin{bmatrix}1\\-2\\1\end{bmatrix}\right\}$.

25. Hence $\dim E_{\frac{1}{10}}=1$.

26. Eigenspace for $\lambda=\frac{3}{10}$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

27. Row-reduce the homogeneous system: start with $A-(\frac{3}{10})I=\begin{bmatrix}\frac{1}{5}&\frac{3}{10}&\frac{1}{5}\\\frac{3}{10}&\frac{1}{10}&\frac{3}{10}\\\frac{1}{5}&\frac{3}{10}&\frac{1}{5}\end{bmatrix}$.

28. Multiply row 1 by $5$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (5)R_{1}}\begin{bmatrix}1&\frac{3}{2}&1\\\frac{3}{10}&\frac{1}{10}&\frac{3}{10}\\\frac{1}{5}&\frac{3}{10}&\frac{1}{5}\end{bmatrix}
   $$

29. Replace row 2 by itself plus $- \frac{3}{10}$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (- \frac{3}{10})R_{1}}\begin{bmatrix}1&\frac{3}{2}&1\\0&- \frac{7}{20}&0\\\frac{1}{5}&\frac{3}{10}&\frac{1}{5}\end{bmatrix}
   $$

30. Replace row 3 by itself plus $- \frac{1}{5}$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{3}\leftarrow R_{3} + (- \frac{1}{5})R_{1}}\begin{bmatrix}1&\frac{3}{2}&1\\0&- \frac{7}{20}&0\\0&0&0\end{bmatrix}
   $$

31. Multiply row 2 by $- \frac{20}{7}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{2}\leftarrow (- \frac{20}{7})R_{2}}\begin{bmatrix}1&\frac{3}{2}&1\\0&1&0\\0&0&0\end{bmatrix}
   $$

32. Replace row 1 by itself plus $- \frac{3}{2}$ times row 2 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{1}\leftarrow R_{1} + (- \frac{3}{2})R_{2}}\begin{bmatrix}1&0&1\\0&1&0\\0&0&0\end{bmatrix}
   $$

33. The pivot columns are 1, 2; the free variable is $x_3$.

34. The pivot equations give $x_1=- x_{3}$, $x_2=0$.

35. The resulting basis is $\left\{\begin{bmatrix}-1\\0\\1\end{bmatrix}\right\}$.

36. Hence $\dim E_{\frac{3}{10}}=1$.

37. Eigenspace for $\lambda=1$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

38. Row-reduce the homogeneous system: start with $A-(1)I=\begin{bmatrix}- \frac{1}{2}&\frac{3}{10}&\frac{1}{5}\\\frac{3}{10}&- \frac{3}{5}&\frac{3}{10}\\\frac{1}{5}&\frac{3}{10}&- \frac{1}{2}\end{bmatrix}$.

39. Multiply row 1 by $-2$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (-2)R_{1}}\begin{bmatrix}1&- \frac{3}{5}&- \frac{2}{5}\\\frac{3}{10}&- \frac{3}{5}&\frac{3}{10}\\\frac{1}{5}&\frac{3}{10}&- \frac{1}{2}\end{bmatrix}
   $$

40. Replace row 2 by itself plus $- \frac{3}{10}$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (- \frac{3}{10})R_{1}}\begin{bmatrix}1&- \frac{3}{5}&- \frac{2}{5}\\0&- \frac{21}{50}&\frac{21}{50}\\\frac{1}{5}&\frac{3}{10}&- \frac{1}{2}\end{bmatrix}
   $$

41. Replace row 3 by itself plus $- \frac{1}{5}$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{3}\leftarrow R_{3} + (- \frac{1}{5})R_{1}}\begin{bmatrix}1&- \frac{3}{5}&- \frac{2}{5}\\0&- \frac{21}{50}&\frac{21}{50}\\0&\frac{21}{50}&- \frac{21}{50}\end{bmatrix}
   $$

42. Multiply row 2 by $- \frac{50}{21}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{2}\leftarrow (- \frac{50}{21})R_{2}}\begin{bmatrix}1&- \frac{3}{5}&- \frac{2}{5}\\0&1&-1\\0&\frac{21}{50}&- \frac{21}{50}\end{bmatrix}
   $$

43. Replace row 1 by itself plus $\frac{3}{5}$ times row 2 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{1}\leftarrow R_{1} + (\frac{3}{5})R_{2}}\begin{bmatrix}1&0&-1\\0&1&-1\\0&\frac{21}{50}&- \frac{21}{50}\end{bmatrix}
   $$

44. Replace row 3 by itself plus $- \frac{21}{50}$ times row 2 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{3}\leftarrow R_{3} + (- \frac{21}{50})R_{2}}\begin{bmatrix}1&0&-1\\0&1&-1\\0&0&0\end{bmatrix}
   $$

45. The pivot columns are 1, 2; the free variable is $x_3$.

46. The pivot equations give $x_1=x_{3}$, $x_2=x_{3}$.

47. The resulting basis is $\left\{\begin{bmatrix}1\\1\\1\end{bmatrix}\right\}$.

48. Hence $\dim E_{1}=1$.

49. Check: $A\begin{bmatrix}1\\-2\\1\end{bmatrix}=\begin{bmatrix}\frac{1}{10}\\- \frac{1}{5}\\\frac{1}{10}\end{bmatrix}=\frac{1}{10}\begin{bmatrix}1\\-2\\1\end{bmatrix}$.

50. Check: $A\begin{bmatrix}-1\\0\\1\end{bmatrix}=\begin{bmatrix}- \frac{3}{10}\\0\\\frac{3}{10}\end{bmatrix}=\frac{3}{10}\begin{bmatrix}-1\\0\\1\end{bmatrix}$.

51. Check: $A\begin{bmatrix}1\\1\\1\end{bmatrix}=\begin{bmatrix}1\\1\\1\end{bmatrix}=1\begin{bmatrix}1\\1\\1\end{bmatrix}$.
::::

:::


### Practice problems: Why a stochastic matrix has eigenvalue one

:::problem[Problem 5.38 — Why a stochastic matrix has eigenvalue one]{difficulty=challenge}
Show algebraically that $\lambda=1$ is always an eigenvalue of a stochastic matrix $P$.

::::solution[Solution]
**Answer:** Every column-stochastic matrix has eigenvalue $1$.

1. Each column of $P$ sums to 1, so $[1,1,\ldots,1]P=[1,1,\ldots,1]$.

2. This says $\mathbf{1}^T P = \mathbf{1}^T$, i.e., $\mathbf{1}^T(P-I)=\mathbf{0}^T$, so the rows of $P-I$ are linearly dependent $\Rightarrow\det(P-I)=0\Rightarrow\lambda=1$ is an eigenvalue of $P$. ∎

3. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

4. Form $A-\lambda I=\begin{bmatrix}\frac{4}{5} - \lambda&\frac{2}{5}\\\frac{1}{5}&\frac{3}{5} - \lambda\end{bmatrix}$.

5. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=(\frac{4}{5}-\lambda)(\frac{3}{5}-\lambda)-(\frac{2}{5})(\frac{1}{5})
   $$

6. Expand, simplify, and factor the preceding expression.

   $$
   =\lambda^{2} - \frac{7 \lambda}{5} + \frac{2}{5}=\frac{\left(\lambda - 1\right) \left(5 \lambda - 2\right)}{5}.
   $$

7. Eigenspace for $\lambda=\frac{2}{5}$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

8. Row-reduce the homogeneous system: start with $A-(\frac{2}{5})I=\begin{bmatrix}\frac{2}{5}&\frac{2}{5}\\\frac{1}{5}&\frac{1}{5}\end{bmatrix}$.

9. Multiply row 1 by $\frac{5}{2}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (\frac{5}{2})R_{1}}\begin{bmatrix}1&1\\\frac{1}{5}&\frac{1}{5}\end{bmatrix}
   $$

10. Replace row 2 by itself plus $- \frac{1}{5}$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (- \frac{1}{5})R_{1}}\begin{bmatrix}1&1\\0&0\end{bmatrix}
   $$

11. The pivot columns are 1; the free variable is $x_2$.

12. The pivot equations give $x_1=- x_{2}$.

13. The resulting basis is $\left\{\begin{bmatrix}-1\\1\end{bmatrix}\right\}$.

14. Hence $\dim E_{\frac{2}{5}}=1$.

15. Eigenspace for $\lambda=1$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

16. Row-reduce the homogeneous system: start with $A-(1)I=\begin{bmatrix}- \frac{1}{5}&\frac{2}{5}\\\frac{1}{5}&- \frac{2}{5}\end{bmatrix}$.

17. Multiply row 1 by $-5$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (-5)R_{1}}\begin{bmatrix}1&-2\\\frac{1}{5}&- \frac{2}{5}\end{bmatrix}
   $$

18. Replace row 2 by itself plus $- \frac{1}{5}$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (- \frac{1}{5})R_{1}}\begin{bmatrix}1&-2\\0&0\end{bmatrix}
   $$

19. The pivot columns are 1; the free variable is $x_2$.

20. The pivot equations give $x_1=2 x_{2}$.

21. The resulting basis is $\left\{\begin{bmatrix}2\\1\end{bmatrix}\right\}$.

22. Hence $\dim E_{1}=1$.

23. Check: $A\begin{bmatrix}-1\\1\end{bmatrix}=\begin{bmatrix}- \frac{2}{5}\\\frac{2}{5}\end{bmatrix}=\frac{2}{5}\begin{bmatrix}-1\\1\end{bmatrix}$.

24. Check: $A\begin{bmatrix}2\\1\end{bmatrix}=\begin{bmatrix}2\\1\end{bmatrix}=1\begin{bmatrix}2\\1\end{bmatrix}$.
::::

:::

:::problem[Problem 5.39 — Uniform stationary distribution]{difficulty=easy}
For the transition matrix $P=\begin{bmatrix}\frac{1}{2}&\frac{1}{2}\\\frac{1}{2}&\frac{1}{2}\end{bmatrix}$, find the steady state.

::::solution[Solution]
**Answer:** $\mathbf{q}=\begin{bmatrix}\frac{1}{2}\\\frac{1}{2}\end{bmatrix}$.

1. Every column sums to 1 and all entries are nonnegative, so $P$ is stochastic.

2. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

3. Form $A-\lambda I=\begin{bmatrix}\frac{1}{2} - \lambda&\frac{1}{2}\\\frac{1}{2}&\frac{1}{2} - \lambda\end{bmatrix}$.

4. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=(\frac{1}{2}-\lambda)(\frac{1}{2}-\lambda)-(\frac{1}{2})(\frac{1}{2})
   $$

5. Expand, simplify, and factor the preceding expression.

   $$
   =\lambda \left(\lambda - 1\right)=\lambda \left(\lambda - 1\right).
   $$

6. Eigenspace for $\lambda=0$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

7. Row-reduce the homogeneous system: start with $A-(0)I=\begin{bmatrix}\frac{1}{2}&\frac{1}{2}\\\frac{1}{2}&\frac{1}{2}\end{bmatrix}$.

8. Multiply row 1 by $2$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (2)R_{1}}\begin{bmatrix}1&1\\\frac{1}{2}&\frac{1}{2}\end{bmatrix}
   $$

9. Replace row 2 by itself plus $- \frac{1}{2}$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (- \frac{1}{2})R_{1}}\begin{bmatrix}1&1\\0&0\end{bmatrix}
   $$

10. The pivot columns are 1; the free variable is $x_2$.

11. The pivot equations give $x_1=- x_{2}$.

12. The resulting basis is $\left\{\begin{bmatrix}-1\\1\end{bmatrix}\right\}$.

13. Hence $\dim E_{0}=1$.

14. Eigenspace for $\lambda=1$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

15. Row-reduce the homogeneous system: start with $A-(1)I=\begin{bmatrix}- \frac{1}{2}&\frac{1}{2}\\\frac{1}{2}&- \frac{1}{2}\end{bmatrix}$.

16. Multiply row 1 by $-2$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (-2)R_{1}}\begin{bmatrix}1&-1\\\frac{1}{2}&- \frac{1}{2}\end{bmatrix}
   $$

17. Replace row 2 by itself plus $- \frac{1}{2}$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (- \frac{1}{2})R_{1}}\begin{bmatrix}1&-1\\0&0\end{bmatrix}
   $$

18. The pivot columns are 1; the free variable is $x_2$.

19. The pivot equations give $x_1=x_{2}$.

20. The resulting basis is $\left\{\begin{bmatrix}1\\1\end{bmatrix}\right\}$.

21. Hence $\dim E_{1}=1$.

22. For $\lambda=1$, the free-variable basis gives $\mathbf{v}=\begin{bmatrix}1\\1\end{bmatrix}$.

23. Sum its coordinates: $2$.

24. Normalize $\mathbf{q}=\mathbf{v}/2=\begin{bmatrix}\frac{1}{2}\\\frac{1}{2}\end{bmatrix}$.

25. Check $P\mathbf{q}=\begin{bmatrix}\frac{1}{2}\\\frac{1}{2}\end{bmatrix}$.

26. Check: $A\begin{bmatrix}-1\\1\end{bmatrix}=\begin{bmatrix}0\\0\end{bmatrix}=0\begin{bmatrix}-1\\1\end{bmatrix}$.

27. Check: $A\begin{bmatrix}1\\1\end{bmatrix}=\begin{bmatrix}1\\1\end{bmatrix}=1\begin{bmatrix}1\\1\end{bmatrix}$.
::::

:::


### Practice problems: Two-step probability evolution

:::problem[Problem 5.40 — Two-step probability evolution]{difficulty=standard}
For the transition matrix $P=\begin{bmatrix}\frac{3}{4}&\frac{1}{2}\\\frac{1}{4}&\frac{1}{2}\end{bmatrix}$, find the steady state and the first two distributions for $\mathbf{x}_0=\begin{bmatrix}1\\0\end{bmatrix}$.

::::solution[Solution]
**Answer:** $\mathbf{q}=\begin{bmatrix}\frac{2}{3}\\\frac{1}{3}\end{bmatrix}$.

1. Every column sums to 1 and all entries are nonnegative, so $P$ is stochastic.

2. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

3. Form $A-\lambda I=\begin{bmatrix}\frac{3}{4} - \lambda&\frac{1}{2}\\\frac{1}{4}&\frac{1}{2} - \lambda\end{bmatrix}$.

4. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=(\frac{3}{4}-\lambda)(\frac{1}{2}-\lambda)-(\frac{1}{2})(\frac{1}{4})
   $$

5. Expand, simplify, and factor the preceding expression.

   $$
   =\lambda^{2} - \frac{5 \lambda}{4} + \frac{1}{4}=\frac{\left(\lambda - 1\right) \left(4 \lambda - 1\right)}{4}.
   $$

6. Eigenspace for $\lambda=\frac{1}{4}$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

7. Row-reduce the homogeneous system: start with $A-(\frac{1}{4})I=\begin{bmatrix}\frac{1}{2}&\frac{1}{2}\\\frac{1}{4}&\frac{1}{4}\end{bmatrix}$.

8. Multiply row 1 by $2$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (2)R_{1}}\begin{bmatrix}1&1\\\frac{1}{4}&\frac{1}{4}\end{bmatrix}
   $$

9. Replace row 2 by itself plus $- \frac{1}{4}$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (- \frac{1}{4})R_{1}}\begin{bmatrix}1&1\\0&0\end{bmatrix}
   $$

10. The pivot columns are 1; the free variable is $x_2$.

11. The pivot equations give $x_1=- x_{2}$.

12. The resulting basis is $\left\{\begin{bmatrix}-1\\1\end{bmatrix}\right\}$.

13. Hence $\dim E_{\frac{1}{4}}=1$.

14. Eigenspace for $\lambda=1$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

15. Row-reduce the homogeneous system: start with $A-(1)I=\begin{bmatrix}- \frac{1}{4}&\frac{1}{2}\\\frac{1}{4}&- \frac{1}{2}\end{bmatrix}$.

16. Multiply row 1 by $-4$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (-4)R_{1}}\begin{bmatrix}1&-2\\\frac{1}{4}&- \frac{1}{2}\end{bmatrix}
   $$

17. Replace row 2 by itself plus $- \frac{1}{4}$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (- \frac{1}{4})R_{1}}\begin{bmatrix}1&-2\\0&0\end{bmatrix}
   $$

18. The pivot columns are 1; the free variable is $x_2$.

19. The pivot equations give $x_1=2 x_{2}$.

20. The resulting basis is $\left\{\begin{bmatrix}2\\1\end{bmatrix}\right\}$.

21. Hence $\dim E_{1}=1$.

22. For $\lambda=1$, the free-variable basis gives $\mathbf{v}=\begin{bmatrix}2\\1\end{bmatrix}$.

23. Sum its coordinates: $3$.

24. Normalize $\mathbf{q}=\mathbf{v}/3=\begin{bmatrix}\frac{2}{3}\\\frac{1}{3}\end{bmatrix}$.

25. Check $P\mathbf{q}=\begin{bmatrix}\frac{2}{3}\\\frac{1}{3}\end{bmatrix}$.

26. With $\mathbf{x}_0=\begin{bmatrix}1\\0\end{bmatrix}$, multiply explicitly: $P\mathbf{x}_0=\begin{bmatrix}\frac{3}{4}\\\frac{1}{4}\end{bmatrix}$ and $P(P\mathbf{x}_0)=\begin{bmatrix}\frac{11}{16}\\\frac{5}{16}\end{bmatrix}$.

27. Check: $A\begin{bmatrix}-1\\1\end{bmatrix}=\begin{bmatrix}- \frac{1}{4}\\\frac{1}{4}\end{bmatrix}=\frac{1}{4}\begin{bmatrix}-1\\1\end{bmatrix}$.

28. Check: $A\begin{bmatrix}2\\1\end{bmatrix}=\begin{bmatrix}2\\1\end{bmatrix}=1\begin{bmatrix}2\\1\end{bmatrix}$.
::::

:::

:::problem[Problem 5.41 — Symmetric Markov dynamics]{difficulty=standard}
For the transition matrix $P=\begin{bmatrix}\frac{2}{3}&\frac{1}{3}\\\frac{1}{3}&\frac{2}{3}\end{bmatrix}$, find the steady state and the first two distributions for $\mathbf{x}_0=\begin{bmatrix}1\\0\end{bmatrix}$.

::::solution[Solution]
**Answer:** $\mathbf{q}=\begin{bmatrix}\frac{1}{2}\\\frac{1}{2}\end{bmatrix}$.

1. Every column sums to 1 and all entries are nonnegative, so $P$ is stochastic.

2. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

3. Form $A-\lambda I=\begin{bmatrix}\frac{2}{3} - \lambda&\frac{1}{3}\\\frac{1}{3}&\frac{2}{3} - \lambda\end{bmatrix}$.

4. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=(\frac{2}{3}-\lambda)(\frac{2}{3}-\lambda)-(\frac{1}{3})(\frac{1}{3})
   $$

5. Expand, simplify, and factor the preceding expression.

   $$
   =\lambda^{2} - \frac{4 \lambda}{3} + \frac{1}{3}=\frac{\left(\lambda - 1\right) \left(3 \lambda - 1\right)}{3}.
   $$

6. Eigenspace for $\lambda=\frac{1}{3}$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

7. Row-reduce the homogeneous system: start with $A-(\frac{1}{3})I=\begin{bmatrix}\frac{1}{3}&\frac{1}{3}\\\frac{1}{3}&\frac{1}{3}\end{bmatrix}$.

8. Multiply row 1 by $3$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (3)R_{1}}\begin{bmatrix}1&1\\\frac{1}{3}&\frac{1}{3}\end{bmatrix}
   $$

9. Replace row 2 by itself plus $- \frac{1}{3}$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (- \frac{1}{3})R_{1}}\begin{bmatrix}1&1\\0&0\end{bmatrix}
   $$

10. The pivot columns are 1; the free variable is $x_2$.

11. The pivot equations give $x_1=- x_{2}$.

12. The resulting basis is $\left\{\begin{bmatrix}-1\\1\end{bmatrix}\right\}$.

13. Hence $\dim E_{\frac{1}{3}}=1$.

14. Eigenspace for $\lambda=1$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

15. Row-reduce the homogeneous system: start with $A-(1)I=\begin{bmatrix}- \frac{1}{3}&\frac{1}{3}\\\frac{1}{3}&- \frac{1}{3}\end{bmatrix}$.

16. Multiply row 1 by $-3$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (-3)R_{1}}\begin{bmatrix}1&-1\\\frac{1}{3}&- \frac{1}{3}\end{bmatrix}
   $$

17. Replace row 2 by itself plus $- \frac{1}{3}$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (- \frac{1}{3})R_{1}}\begin{bmatrix}1&-1\\0&0\end{bmatrix}
   $$

18. The pivot columns are 1; the free variable is $x_2$.

19. The pivot equations give $x_1=x_{2}$.

20. The resulting basis is $\left\{\begin{bmatrix}1\\1\end{bmatrix}\right\}$.

21. Hence $\dim E_{1}=1$.

22. For $\lambda=1$, the free-variable basis gives $\mathbf{v}=\begin{bmatrix}1\\1\end{bmatrix}$.

23. Sum its coordinates: $2$.

24. Normalize $\mathbf{q}=\mathbf{v}/2=\begin{bmatrix}\frac{1}{2}\\\frac{1}{2}\end{bmatrix}$.

25. Check $P\mathbf{q}=\begin{bmatrix}\frac{1}{2}\\\frac{1}{2}\end{bmatrix}$.

26. With $\mathbf{x}_0=\begin{bmatrix}1\\0\end{bmatrix}$, multiply explicitly: $P\mathbf{x}_0=\begin{bmatrix}\frac{2}{3}\\\frac{1}{3}\end{bmatrix}$ and $P(P\mathbf{x}_0)=\begin{bmatrix}\frac{5}{9}\\\frac{4}{9}\end{bmatrix}$.

27. Check: $A\begin{bmatrix}-1\\1\end{bmatrix}=\begin{bmatrix}- \frac{1}{3}\\\frac{1}{3}\end{bmatrix}=\frac{1}{3}\begin{bmatrix}-1\\1\end{bmatrix}$.

28. Check: $A\begin{bmatrix}1\\1\end{bmatrix}=\begin{bmatrix}1\\1\end{bmatrix}=1\begin{bmatrix}1\\1\end{bmatrix}$.
::::

:::


### Practice problems: Three-state stationary distribution

:::problem[Problem 5.42 — Three-state stationary distribution]{difficulty=challenge}
For the transition matrix $P=\begin{bmatrix}\frac{1}{2}&\frac{1}{4}&\frac{1}{4}\\\frac{1}{4}&\frac{1}{2}&\frac{1}{4}\\\frac{1}{4}&\frac{1}{4}&\frac{1}{2}\end{bmatrix}$, find the steady state and the first two distributions for $\mathbf{x}_0=\begin{bmatrix}1\\0\\0\end{bmatrix}$.

::::solution[Solution]
**Answer:** $\mathbf{q}=\begin{bmatrix}\frac{1}{3}\\\frac{1}{3}\\\frac{1}{3}\end{bmatrix}$.

1. Every column sums to 1 and all entries are nonnegative, so $P$ is stochastic.

2. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

3. Form $A-\lambda I=\begin{bmatrix}\frac{1}{2} - \lambda&\frac{1}{4}&\frac{1}{4}\\\frac{1}{4}&\frac{1}{2} - \lambda&\frac{1}{4}\\\frac{1}{4}&\frac{1}{4}&\frac{1}{2} - \lambda\end{bmatrix}$.

4. Expand along column 1, which has the most zeros (ties favor columns).

5. The cofactor signs alternate $+,-,+$ across the first row.

6. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=(\frac{1}{2} - \lambda)\left[(\frac{1}{2} - \lambda)(\frac{1}{2} - \lambda)-(\frac{1}{4})(\frac{1}{4})\right]-(\frac{1}{4})\left[(\frac{1}{4})(\frac{1}{2} - \lambda)-(\frac{1}{4})(\frac{1}{4})\right]+(\frac{1}{4})\left[(\frac{1}{4})(\frac{1}{4})-(\frac{1}{4})(\frac{1}{2} - \lambda)\right]
   $$

7. Expand, simplify, and factor the preceding expression.

   $$
   =- \lambda^{3} + \frac{3 \lambda^{2}}{2} - \frac{9 \lambda}{16} + \frac{1}{16}=\frac{\left(1 - \lambda\right) \left(4 \lambda - 1\right)^{2}}{16}.
   $$

8. Eigenspace for $\lambda=\frac{1}{4}$ (algebraic multiplicity 2): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

9. Row-reduce the homogeneous system: start with $A-(\frac{1}{4})I=\begin{bmatrix}\frac{1}{4}&\frac{1}{4}&\frac{1}{4}\\\frac{1}{4}&\frac{1}{4}&\frac{1}{4}\\\frac{1}{4}&\frac{1}{4}&\frac{1}{4}\end{bmatrix}$.

10. Multiply row 1 by $4$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (4)R_{1}}\begin{bmatrix}1&1&1\\\frac{1}{4}&\frac{1}{4}&\frac{1}{4}\\\frac{1}{4}&\frac{1}{4}&\frac{1}{4}\end{bmatrix}
   $$

11. Replace row 2 by itself plus $- \frac{1}{4}$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (- \frac{1}{4})R_{1}}\begin{bmatrix}1&1&1\\0&0&0\\\frac{1}{4}&\frac{1}{4}&\frac{1}{4}\end{bmatrix}
   $$

12. Replace row 3 by itself plus $- \frac{1}{4}$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{3}\leftarrow R_{3} + (- \frac{1}{4})R_{1}}\begin{bmatrix}1&1&1\\0&0&0\\0&0&0\end{bmatrix}
   $$

13. The pivot columns are 1; the free variables are $x_2$, $x_3$.

14. The pivot equations give $x_1=- x_{2} - x_{3}$.

15. The resulting basis is $\left\{\begin{bmatrix}-1\\1\\0\end{bmatrix},\;\begin{bmatrix}-1\\0\\1\end{bmatrix}\right\}$.

16. Hence $\dim E_{\frac{1}{4}}=2$.

17. Eigenspace for $\lambda=1$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

18. Row-reduce the homogeneous system: start with $A-(1)I=\begin{bmatrix}- \frac{1}{2}&\frac{1}{4}&\frac{1}{4}\\\frac{1}{4}&- \frac{1}{2}&\frac{1}{4}\\\frac{1}{4}&\frac{1}{4}&- \frac{1}{2}\end{bmatrix}$.

19. Multiply row 1 by $-2$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (-2)R_{1}}\begin{bmatrix}1&- \frac{1}{2}&- \frac{1}{2}\\\frac{1}{4}&- \frac{1}{2}&\frac{1}{4}\\\frac{1}{4}&\frac{1}{4}&- \frac{1}{2}\end{bmatrix}
   $$

20. Replace row 2 by itself plus $- \frac{1}{4}$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (- \frac{1}{4})R_{1}}\begin{bmatrix}1&- \frac{1}{2}&- \frac{1}{2}\\0&- \frac{3}{8}&\frac{3}{8}\\\frac{1}{4}&\frac{1}{4}&- \frac{1}{2}\end{bmatrix}
   $$

21. Replace row 3 by itself plus $- \frac{1}{4}$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{3}\leftarrow R_{3} + (- \frac{1}{4})R_{1}}\begin{bmatrix}1&- \frac{1}{2}&- \frac{1}{2}\\0&- \frac{3}{8}&\frac{3}{8}\\0&\frac{3}{8}&- \frac{3}{8}\end{bmatrix}
   $$

22. Multiply row 2 by $- \frac{8}{3}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{2}\leftarrow (- \frac{8}{3})R_{2}}\begin{bmatrix}1&- \frac{1}{2}&- \frac{1}{2}\\0&1&-1\\0&\frac{3}{8}&- \frac{3}{8}\end{bmatrix}
   $$

23. Replace row 1 by itself plus $\frac{1}{2}$ times row 2 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{1}\leftarrow R_{1} + (\frac{1}{2})R_{2}}\begin{bmatrix}1&0&-1\\0&1&-1\\0&\frac{3}{8}&- \frac{3}{8}\end{bmatrix}
   $$

24. Replace row 3 by itself plus $- \frac{3}{8}$ times row 2 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{3}\leftarrow R_{3} + (- \frac{3}{8})R_{2}}\begin{bmatrix}1&0&-1\\0&1&-1\\0&0&0\end{bmatrix}
   $$

25. The pivot columns are 1, 2; the free variable is $x_3$.

26. The pivot equations give $x_1=x_{3}$, $x_2=x_{3}$.

27. The resulting basis is $\left\{\begin{bmatrix}1\\1\\1\end{bmatrix}\right\}$.

28. Hence $\dim E_{1}=1$.

29. For $\lambda=1$, the free-variable basis gives $\mathbf{v}=\begin{bmatrix}1\\1\\1\end{bmatrix}$.

30. Sum its coordinates: $3$.

31. Normalize $\mathbf{q}=\mathbf{v}/3=\begin{bmatrix}\frac{1}{3}\\\frac{1}{3}\\\frac{1}{3}\end{bmatrix}$.

32. Check $P\mathbf{q}=\begin{bmatrix}\frac{1}{3}\\\frac{1}{3}\\\frac{1}{3}\end{bmatrix}$.

33. With $\mathbf{x}_0=\begin{bmatrix}1\\0\\0\end{bmatrix}$, multiply explicitly: $P\mathbf{x}_0=\begin{bmatrix}\frac{1}{2}\\\frac{1}{4}\\\frac{1}{4}\end{bmatrix}$ and $P(P\mathbf{x}_0)=\begin{bmatrix}\frac{3}{8}\\\frac{5}{16}\\\frac{5}{16}\end{bmatrix}$.

34. Check: $A\begin{bmatrix}-1\\1\\0\end{bmatrix}=\begin{bmatrix}- \frac{1}{4}\\\frac{1}{4}\\0\end{bmatrix}=\frac{1}{4}\begin{bmatrix}-1\\1\\0\end{bmatrix}$.

35. Check: $A\begin{bmatrix}-1\\0\\1\end{bmatrix}=\begin{bmatrix}- \frac{1}{4}\\0\\\frac{1}{4}\end{bmatrix}=\frac{1}{4}\begin{bmatrix}-1\\0\\1\end{bmatrix}$.

36. Check: $A\begin{bmatrix}1\\1\\1\end{bmatrix}=\begin{bmatrix}1\\1\\1\end{bmatrix}=1\begin{bmatrix}1\\1\\1\end{bmatrix}$.
::::

:::

## Chapter Summary

:::summary[Written-exam memory sheet]
**Identify what the question actually requests.** A proposed eigenvector: multiply $A\mathbf{v}$. A proposed eigenvalue: row-reduce $A-\lambda I$ to see whether a nonzero solution exists. All eigenvalues: solve $\det(A-\lambda I)=0$. Each eigenspace: solve $\Nul(A-\lambda I)$ and list a basis. Eigenspace dimension equals the number of free variables.

**One calculation chain:**
$$
A\mathbf{v}=\lambda\mathbf{v},\quad \mathbf{v}\ne\mathbf{0}
\iff (A-\lambda I)\mathbf{v}=\mathbf{0}
\iff \det(A-\lambda I)=0\text{ for some nonzero }\mathbf{v}.
$$
The final equivalence is about the **existence** of a nonzero $\mathbf{v}$, not about an arbitrary fixed vector.

**2 by 2:** $\det(A-\lambda I)=\lambda^2-(\tr A)\lambda+\det A$. **3 by 3:** expand cofactors across the row or column with the most zeros; write the signed two by two minors in full. **Triangular matrix:** its eigenvalues are its diagonal entries, with repetitions. The determinant is the product of eigenvalues, and $0$ is an eigenvalue exactly when $A$ is noninvertible (IMT).

**Multiplicity:** algebraic multiplicity is the number of occurrences as a characteristic root. Geometric multiplicity is $\dim\Nul(A-\lambda I)$. Always $1\leq \text{geom}\leq\text{alg}$. Eigenvectors for distinct eigenvalues are independent, so $n$ distinct eigenvalues always give diagonalizability. A repeated root may or may not.

**Diagonalization:** $A=PDP^{-1}$ with eigenvectors in the columns of $P$ and their corresponding eigenvalues in the same-order diagonal positions of $D$. Check $AP=PD$ and $\det P\ne0$. If an eigenspace is missing enough free variables to reach $n$ independent eigenvectors, write **not diagonalizable** and cite the multiplicity gap. If diagonalizable, $A^k=PD^kP^{-1}$.

**Similarity:** $B=P^{-1}AP$ shares characteristic polynomial, eigenvalues, multiplicities, trace, determinant and diagonalizability with $A$. It need not share eigenvectors. Same characteristic polynomial alone does **not** prove similarity.

**Complex pairs:** for a real $A$, $a+bi$ comes with $a-bi$. For $\lambda=a-bi$, $\mathbf{v}=\mathbf{p}+i\mathbf{q}$, the real basis $P=[\mathbf{p}\ \mathbf{q}]$ gives $P^{-1}AP=\begin{bmatrix}a&-b\\b&a\end{bmatrix}$. The scale is $\sqrt{a^2+b^2}$; the rotation interpretation is in that basis.

**Differential equations:** $\mathbf{x}(t)=\sum_i c_i e^{\lambda_i t}\mathbf{v}_i$, with $P\mathbf{c}=\mathbf{x}(0)$. Real eigenvalues below zero decay; those above zero grow in that mode. Complex eigenvalues use real parts for growth/decay.

**Markov:** columns sum to one. $\mathbf{x}_{k}=P^k\mathbf{x}_0$. Find $\mathbf{q}$ from $(P-I)\mathbf{q}=0$ plus $\sum q_i=1$, with $q_i\ge0$. A regular stochastic matrix has a unique attracting steady state.

**Grading checklist:** correct matrix minus $\lambda I$; explicit expanded and factored characteristic polynomial; full RREF with row operations; pivot/free variables; basis and its dimension; multiplicities; correctly ordered $P,D$ or a precise obstruction; boxed final answer.
:::

## Mixed Practice

:::problem[Problem M.1 — Triangular eigenvalues without a determinant]{difficulty=easy}
For $A=\begin{bmatrix}4&0\\-3&1\end{bmatrix}$, find all eigenvalues and corresponding eigenspaces without using the characteristic polynomial formula. (Use the triangular matrix theorem.)

::::solution[Solution]
**Answer:** $\lambda=4,1$; bases $E_4=\span\{(1,-1)^T\}$ and $E_1=\span\{(0,1)^T\}$.

1. Because $A$ is lower triangular, apply the triangular-matrix theorem: its eigenvalues are the diagonal entries, $4$ and $1$. No determinant formula is needed.
2. For $\lambda=4$, subtract $4I$: $A-4I=\begin{bmatrix}0&0\\-3&-3\end{bmatrix}$. Divide row $2$ by $-3$ to obtain $\begin{bmatrix}0&0\\1&1\end{bmatrix}$.
3. Solve the nonzero row: $x_1+x_2=0$, so $x_1=-x_2$. Taking $x_2=-t$ gives $x=t(1,-1)^T$ and basis $\{(1,-1)^T\}$.
4. For $\lambda=1$, subtract $I$: $A-I=\begin{bmatrix}3&0\\-3&0\end{bmatrix}$. Apply $R_2\leftarrow R_2+R_1$, then $R_1\leftarrow R_1/3$, obtaining $\begin{bmatrix}1&0\\0&0\end{bmatrix}$.
5. The equation is $x_1=0$; $x_2=t$ is free. Therefore $x=t(0,1)^T$ and basis $\{(0,1)^T\}$.
**Check:** $A(1,-1)^T=(4,-4)^T=4(1,-1)^T$ and $A(0,1)^T=(0,1)^T$.
::::

:::

:::problem[Problem M.2 — Diagonalization from two eigenvalues]{difficulty=standard}
Find the eigenvalues of $A=\begin{bmatrix}2&-4\\1&-3\end{bmatrix}$ and determine whether $A$ is diagonalizable. If so, find $P$ and $D$.

::::solution[Solution]
**Answer:** Eigenvalues $-2,1$; $P=\begin{bmatrix}1&4\\1&1\end{bmatrix}$ and $D=\operatorname{diag}(-2,1)$.

1. Form $A-\lambda I=\begin{bmatrix}2-\lambda&-4\\1&-3-\lambda\end{bmatrix}$. Expand the $2\times2$ determinant: $(2-\lambda)(-3-\lambda)-(-4)(1)$.
2. Multiply out: $-6-2\lambda+3\lambda+\lambda^2+4=\lambda^2+\lambda-2=(\lambda+2)(\lambda-1)$. Setting this equal to zero gives $\lambda=-2,1$.
3. For $\lambda=-2$, $A+2I=\begin{bmatrix}4&-4\\1&-1\end{bmatrix}$. Swap rows and then do $R_2\leftarrow R_2-4R_1$ to obtain $\begin{bmatrix}1&-1\\0&0\end{bmatrix}$. Thus $x_1=x_2$; choose $v_1=(1,1)^T$.
4. For $\lambda=1$, $A-I=\begin{bmatrix}1&-4\\1&-4\end{bmatrix}$. Perform $R_2\leftarrow R_2-R_1$ to get $\begin{bmatrix}1&-4\\0&0\end{bmatrix}$. Hence $x_1=4x_2$; choose $v_2=(4,1)^T$.
5. Put eigenvectors in the same order as eigenvalues: $P=[v_1\ v_2]=\begin{bmatrix}1&4\\1&1\end{bmatrix}$ and $D=\begin{bmatrix}-2&0\\0&1\end{bmatrix}$. Since $\det P=1-4=-3\ne0$, $P$ is invertible and $A=PDP^{-1}$.
**Check:** $Av_1=(-2,-2)^T=-2v_1$ and $Av_2=(4,1)^T=v_2$, so $AP=PD$.
::::

:::

:::problem[Problem M.3 — General solution from eigenmodes]{difficulty=standard}
A matrix $A$ has eigenvalues $\lambda_1=2$ (alg. mult. 2, geom. mult. 2) and $\lambda_2=-1$ (alg. mult. 1). Write the general solution to $\mathbf{x}'=A\mathbf{x}$ symbolically, using eigenvectors $\mathbf{v}_1,\mathbf{v}_2,\mathbf{v}_3$ for the respective eigenspaces.

::::solution[Solution]
**Answer:** $\mathbf{x}(t)=c_1e^{2t}\mathbf v_1+c_2e^{2t}\mathbf v_2+c_3e^{-t}\mathbf v_3$.

1. Use the eigenmode rule for a constant-coefficient system $x'=Ax$: if $Av=\lambda v$, then $x(t)=e^{\lambda t}v$ is a solution.
2. The eigenvalue $2$ has a two-dimensional eigenspace, so choose independent eigenvectors $v_1,v_2$ with $Av_1=2v_1$ and $Av_2=2v_2$. Their separate modes are $e^{2t}v_1$ and $e^{2t}v_2$.
3. The eigenvalue $-1$ has algebraic multiplicity one, so choose $v_3$ satisfying $Av_3=-v_3$. Its mode is $e^{-t}v_3$.
4. The geometric multiplicities sum to $2+1=3$, the dimension of the system. Therefore these eigenvectors are independent and their linear combination supplies the general solution, with arbitrary constants $c_1,c_2,c_3$.
**Check:** Differentiating gives $x'=2c_1e^{2t}v_1+2c_2e^{2t}v_2-c_3e^{-t}v_3=Ax$; at $t=0$, $x(0)=c_1v_1+c_2v_2+c_3v_3$.
::::

:::

:::problem[Problem M.4 — True or false about eigenvalues]{difficulty=standard}
True or False. Justify each.

(a) A matrix with eigenvalue 0 is singular.

(b) If $A^2=I$, then the eigenvalues of $A$ are $\pm 1$.

(c) If $A\mathbf{x}=\lambda\mathbf{x}$, then $A^3\mathbf{x}=\lambda^3\mathbf{x}$.

(d) Two matrices with the same eigenvalues must be similar.

::::solution[Solution]
**Answer:** (a) True; (b) True; (c) True; (d) False.

1. (a) **True.** Eigenvalue 0 means $A\mathbf{x}=\mathbf{0}$ has a nontrivial solution $\Rightarrow\det A=0\Rightarrow A$ is singular.

2. (b) **True.** If $\lambda$ is an eigenvalue of $A$, then $\lambda^2$ is an eigenvalue of $A^2=I$, so $\lambda^2=1\Rightarrow\lambda=\pm 1$.

3. (c) **True.** $A^2\mathbf{x}=A(\lambda\mathbf{x})=\lambda A\mathbf{x}=\lambda^2\mathbf{x}$; $A^3\mathbf{x}=\lambda^3\mathbf{x}$.

4. (d) **False.** Two matrices can have the same eigenvalues but different algebraic/geometric multiplicities, or neither may be diagonalizable.

5. Example: $I$ and $\begin{bmatrix}1&1\\0&1\end{bmatrix}$ both have eigenvalue 1 but are not similar.
::::

:::

:::problem[Problem M.5 — Three-brand stationary distribution]{difficulty=challenge}
A brand loyalty model has three brands. The monthly transition matrix is:

$$
P=\begin{bmatrix}0.7&0.1&0.1\\0.2&0.8&0.1\\0.1&0.1&0.8\end{bmatrix}
$$

Find the long-run market shares if the model is regular (accept without proof). Set up and solve the system $(P-I)\mathbf{q}=\mathbf{0}$ with $q_1+q_2+q_3=1$.

::::solution[Solution]
**Answer:** $\mathbf q=(1/4,5/12,1/3)^T$.

1. For a regular column-stochastic transition matrix, find the long-run distribution from $Pq=q$ and $q_1+q_2+q_3=1$.
2. Subtract the identity: $P-I=\begin{bmatrix}-0.3&0.1&0.1\\0.2&-0.2&0.1\\0.1&0.1&-0.2\end{bmatrix}$. Multiply every row equation by $10$ to work with $B=\begin{bmatrix}-3&1&1\\2&-2&1\\1&1&-2\end{bmatrix}$.
3. Swap $R_1\leftrightarrow R_3$: $\begin{bmatrix}1&1&-2\\2&-2&1\\-3&1&1\end{bmatrix}$. Eliminate below the first pivot with $R_2\leftarrow R_2-2R_1$ and $R_3\leftarrow R_3+3R_1$, giving $\begin{bmatrix}1&1&-2\\0&-4&5\\0&4&-5\end{bmatrix}$.
4. Add $R_2$ to $R_3$ to get a zero row: $\begin{bmatrix}1&1&-2\\0&-4&5\\0&0&0\end{bmatrix}$. Thus $-4q_2+5q_3=0$ and $q_1+q_2-2q_3=0$.
5. Choose the free variable $q_3=4t$ to avoid fractions. The second row gives $-4q_2+20t=0$, so $q_2=5t$. The first row gives $q_1=2(4t)-5t=3t$.
6. Impose total probability one: $q_1+q_2+q_3=(3+5+4)t=12t=1$, hence $t=1/12$ and $q=(3/12,5/12,4/12)^T=(1/4,5/12,1/3)^T$.
**Check:** $Pq=((21+5+4)/120,(3+20+2)/60,(3+5+32)/120)^T=(1/4,5/12,1/3)^T$, and the entries sum to $1$.
::::

:::

:::problem[Problem M.6 — Quick singularity check]{difficulty=easy}
For $A=\begin{bmatrix}2&4\\1&2\end{bmatrix}$, decide if 0 is an eigenvalue and justify with a null-space basis.

::::solution[Solution]
**Answer:** Eigenvalues $0$, $4$.  Eigenspace bases: $E_{0}=\span\left\{\begin{bmatrix}-2\\1\end{bmatrix}\right\}$, $E_{4}=\span\left\{\begin{bmatrix}2\\1\end{bmatrix}\right\}$.

1. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

2. Form $A-\lambda I=\begin{bmatrix}2 - \lambda&4\\1&2 - \lambda\end{bmatrix}$.

3. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=(2-\lambda)(2-\lambda)-(4)(1)
   $$

4. Expand, simplify, and factor the preceding expression.

   $$
   =\lambda \left(\lambda - 4\right)=\lambda \left(\lambda - 4\right).
   $$

5. Eigenspace for $\lambda=0$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

6. Row-reduce the homogeneous system: start with $A-(0)I=\begin{bmatrix}2&4\\1&2\end{bmatrix}$.

7. Multiply row 1 by $\frac{1}{2}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (\frac{1}{2})R_{1}}\begin{bmatrix}1&2\\1&2\end{bmatrix}
   $$

8. Replace row 2 by itself plus $-1$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (-1)R_{1}}\begin{bmatrix}1&2\\0&0\end{bmatrix}
   $$

9. The pivot columns are 1; the free variable is $x_2$.

10. The pivot equations give $x_1=- 2 x_{2}$.

11. Choose one free variable at a time and set the others to zero.

12. Clear fractions where necessary.

13. The resulting basis is $\left\{\begin{bmatrix}-2\\1\end{bmatrix}\right\}$.

14. Hence $\dim E_{0}=1$.

15. Eigenspace for $\lambda=4$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

16. Row-reduce the homogeneous system: start with $A-(4)I=\begin{bmatrix}-2&4\\1&-2\end{bmatrix}$.

17. Multiply row 1 by $- \frac{1}{2}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (- \frac{1}{2})R_{1}}\begin{bmatrix}1&-2\\1&-2\end{bmatrix}
   $$

18. Replace row 2 by itself plus $-1$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (-1)R_{1}}\begin{bmatrix}1&-2\\0&0\end{bmatrix}
   $$

19. The pivot columns are 1; the free variable is $x_2$.

20. The pivot equations give $x_1=2 x_{2}$.

21. Choose one free variable at a time and set the others to zero.

22. Clear fractions where necessary.

23. The resulting basis is $\left\{\begin{bmatrix}2\\1\end{bmatrix}\right\}$.

24. Hence $\dim E_{4}=1$.

25. The roots of the factored polynomial are $\lambda=4$ (algebraic multiplicity 1), $\lambda=0$ (algebraic multiplicity 1).

26. Check: $A\begin{bmatrix}-2\\1\end{bmatrix}=\begin{bmatrix}0\\0\end{bmatrix}=0\begin{bmatrix}-2\\1\end{bmatrix}$.

27. Check: $A\begin{bmatrix}2\\1\end{bmatrix}=\begin{bmatrix}8\\4\end{bmatrix}=4\begin{bmatrix}2\\1\end{bmatrix}$.
::::

:::

:::problem[Problem M.7 — Cofactor expansion along a sparse column]{difficulty=standard}
For $A=\begin{bmatrix}2&0&1\\0&3&0\\1&0&2\end{bmatrix}$, expand by cofactors along the best column and find all eigenvalues and eigenspaces.

::::solution[Solution]
**Answer:** Eigenvalues $1$, $3$.  Eigenspace bases: $E_{1}=\span\left\{\begin{bmatrix}-1\\0\\1\end{bmatrix}\right\}$, $E_{3}=\span\left\{\begin{bmatrix}0\\1\\0\end{bmatrix}, \begin{bmatrix}1\\0\\1\end{bmatrix}\right\}$.

1. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

2. Form $A-\lambda I=\begin{bmatrix}2 - \lambda&0&1\\0&3 - \lambda&0\\1&0&2 - \lambda\end{bmatrix}$.

3. Expand along column 2, which has the most zeros (ties favor columns).

4. The cofactor signs alternate $+,-,+$ across the first row.

5. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=(3 - \lambda)\left[(2 - \lambda)(2 - \lambda)-(1)(1)\right]
   $$

6. Expand, simplify, and factor the preceding expression.

   $$
   =- \lambda^{3} + 7 \lambda^{2} - 15 \lambda + 9=\left(1 - \lambda\right) \left(\lambda - 3\right)^{2}.
   $$

7. Eigenspace for $\lambda=1$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

8. Row-reduce the homogeneous system: start with $A-(1)I=\begin{bmatrix}1&0&1\\0&2&0\\1&0&1\end{bmatrix}$.

9. Replace row 3 by itself plus $-1$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{3}\leftarrow R_{3} + (-1)R_{1}}\begin{bmatrix}1&0&1\\0&2&0\\0&0&0\end{bmatrix}
   $$

10. Multiply row 2 by $\frac{1}{2}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{2}\leftarrow (\frac{1}{2})R_{2}}\begin{bmatrix}1&0&1\\0&1&0\\0&0&0\end{bmatrix}
   $$

11. The pivot columns are 1, 2; the free variable is $x_3$.

12. The pivot equations give $x_1=- x_{3}$, $x_2=0$.

13. Choose one free variable at a time and set the others to zero.

14. Clear fractions where necessary.

15. The resulting basis is $\left\{\begin{bmatrix}-1\\0\\1\end{bmatrix}\right\}$.

16. Hence $\dim E_{1}=1$.

17. Eigenspace for $\lambda=3$ (algebraic multiplicity 2): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

18. Row-reduce the homogeneous system: start with $A-(3)I=\begin{bmatrix}-1&0&1\\0&0&0\\1&0&-1\end{bmatrix}$.

19. Multiply row 1 by $-1$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (-1)R_{1}}\begin{bmatrix}1&0&-1\\0&0&0\\1&0&-1\end{bmatrix}
   $$

20. Replace row 3 by itself plus $-1$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{3}\leftarrow R_{3} + (-1)R_{1}}\begin{bmatrix}1&0&-1\\0&0&0\\0&0&0\end{bmatrix}
   $$

21. The pivot columns are 1; the free variables are $x_2$, $x_3$.

22. The pivot equations give $x_1=x_{3}$.

23. Choose one free variable at a time and set the others to zero.

24. Clear fractions where necessary.

25. The resulting basis is $\left\{\begin{bmatrix}0\\1\\0\end{bmatrix},\;\begin{bmatrix}1\\0\\1\end{bmatrix}\right\}$.

26. Hence $\dim E_{3}=2$.

27. The roots of the factored polynomial are $\lambda=1$ (algebraic multiplicity 1), $\lambda=3$ (algebraic multiplicity 2).

28. Check: $A\begin{bmatrix}-1\\0\\1\end{bmatrix}=\begin{bmatrix}-1\\0\\1\end{bmatrix}=1\begin{bmatrix}-1\\0\\1\end{bmatrix}$.

29. Check: $A\begin{bmatrix}0\\1\\0\end{bmatrix}=\begin{bmatrix}0\\3\\0\end{bmatrix}=3\begin{bmatrix}0\\1\\0\end{bmatrix}$.

30. Check: $A\begin{bmatrix}1\\0\\1\end{bmatrix}=\begin{bmatrix}3\\0\\3\end{bmatrix}=3\begin{bmatrix}1\\0\\1\end{bmatrix}$.
::::

:::

:::problem[Problem M.8 — Eigenspace dimension versus multiplicity]{difficulty=standard}
For $A=\begin{bmatrix}1&1&0\\0&1&0\\0&0&3\end{bmatrix}$, find all algebraic and geometric multiplicities and decide diagonalizability.

::::solution[Solution]
**Answer:** **not diagonalizable**; Eigenvalues $1$, $3$.  Eigenspace bases: $E_{1}=\span\left\{\begin{bmatrix}1\\0\\0\end{bmatrix}\right\}$, $E_{3}=\span\left\{\begin{bmatrix}0\\0\\1\end{bmatrix}\right\}$.

1. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

2. Form $A-\lambda I=\begin{bmatrix}1 - \lambda&1&0\\0&1 - \lambda&0\\0&0&3 - \lambda\end{bmatrix}$.

3. The matrix is triangular, so multiply its three diagonal entries after subtracting $\lambda$:

4. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=\left(3 - \lambda\right) \left(\lambda - 1\right)^{2}=- \lambda^{3} + 5 \lambda^{2} - 7 \lambda + 3.
   $$

5. Eigenspace for $\lambda=1$ (algebraic multiplicity 2): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

6. Row-reduce the homogeneous system: start with $A-(1)I=\begin{bmatrix}0&1&0\\0&0&0\\0&0&2\end{bmatrix}$.

7. Swap rows 2 and 3 to place a nonzero pivot or reorder the equations.

   $$
   \xrightarrow{R_{2}\leftrightarrow R_{3}}\begin{bmatrix}0&1&0\\0&0&2\\0&0&0\end{bmatrix}
   $$

8. Multiply row 2 by $\frac{1}{2}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{2}\leftarrow (\frac{1}{2})R_{2}}\begin{bmatrix}0&1&0\\0&0&1\\0&0&0\end{bmatrix}
   $$

9. The pivot columns are 2, 3; the free variable is $x_1$.

10. The pivot equations give $x_2=0$, $x_3=0$.

11. Choose one free variable at a time and set the others to zero.

12. Clear fractions where necessary.

13. The resulting basis is $\left\{\begin{bmatrix}1\\0\\0\end{bmatrix}\right\}$.

14. Hence $\dim E_{1}=1$.

15. Eigenspace for $\lambda=3$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

16. Row-reduce the homogeneous system: start with $A-(3)I=\begin{bmatrix}-2&1&0\\0&-2&0\\0&0&0\end{bmatrix}$.

17. Multiply row 1 by $- \frac{1}{2}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (- \frac{1}{2})R_{1}}\begin{bmatrix}1&- \frac{1}{2}&0\\0&-2&0\\0&0&0\end{bmatrix}
   $$

18. Multiply row 2 by $- \frac{1}{2}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{2}\leftarrow (- \frac{1}{2})R_{2}}\begin{bmatrix}1&- \frac{1}{2}&0\\0&1&0\\0&0&0\end{bmatrix}
   $$

19. Replace row 1 by itself plus $\frac{1}{2}$ times row 2 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{1}\leftarrow R_{1} + (\frac{1}{2})R_{2}}\begin{bmatrix}1&0&0\\0&1&0\\0&0&0\end{bmatrix}
   $$

20. The pivot columns are 1, 2; the free variable is $x_3$.

21. The pivot equations give $x_1=0$, $x_2=0$.

22. Choose one free variable at a time and set the others to zero.

23. Clear fractions where necessary.

24. The resulting basis is $\left\{\begin{bmatrix}0\\0\\1\end{bmatrix}\right\}$.

25. Hence $\dim E_{3}=1$.

26. The roots of the factored polynomial are $\lambda=3$ (algebraic multiplicity 1), $\lambda=1$ (algebraic multiplicity 2).

27. **Diagonalization verdict:** The matrix is **not diagonalizable**: the total number of independent eigenvectors is 2, fewer than 3.

28. Check: $A\begin{bmatrix}1\\0\\0\end{bmatrix}=\begin{bmatrix}1\\0\\0\end{bmatrix}=1\begin{bmatrix}1\\0\\0\end{bmatrix}$.

29. Check: $A\begin{bmatrix}0\\0\\1\end{bmatrix}=\begin{bmatrix}0\\0\\3\end{bmatrix}=3\begin{bmatrix}0\\0\\1\end{bmatrix}$.
::::

:::

:::problem[Problem M.9 — Triangular eigenvalue shortcut]{difficulty=easy}
For $A=\begin{bmatrix}3&-1&2\\0&-2&0\\0&0&3\end{bmatrix}$, use triangular structure to find the eigenvalues and all eigenspaces.

::::solution[Solution]
**Answer:** Eigenvalues $-2$, $3$.  Eigenspace bases: $E_{-2}=\span\left\{\begin{bmatrix}1\\5\\0\end{bmatrix}\right\}$, $E_{3}=\span\left\{\begin{bmatrix}1\\0\\0\end{bmatrix}\right\}$.

1. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

2. Form $A-\lambda I=\begin{bmatrix}3 - \lambda&-1&2\\0&- \lambda - 2&0\\0&0&3 - \lambda\end{bmatrix}$.

3. The matrix is triangular, so multiply its three diagonal entries after subtracting $\lambda$:

4. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=\left(- \lambda - 2\right) \left(\lambda - 3\right)^{2}=- \lambda^{3} + 4 \lambda^{2} + 3 \lambda - 18.
   $$

5. Eigenspace for $\lambda=-2$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

6. Row-reduce the homogeneous system: start with $A-(-2)I=\begin{bmatrix}5&-1&2\\0&0&0\\0&0&5\end{bmatrix}$.

7. Multiply row 1 by $\frac{1}{5}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (\frac{1}{5})R_{1}}\begin{bmatrix}1&- \frac{1}{5}&\frac{2}{5}\\0&0&0\\0&0&5\end{bmatrix}
   $$

8. Swap rows 2 and 3 to place a nonzero pivot or reorder the equations.

   $$
   \xrightarrow{R_{2}\leftrightarrow R_{3}}\begin{bmatrix}1&- \frac{1}{5}&\frac{2}{5}\\0&0&5\\0&0&0\end{bmatrix}
   $$

9. Multiply row 2 by $\frac{1}{5}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{2}\leftarrow (\frac{1}{5})R_{2}}\begin{bmatrix}1&- \frac{1}{5}&\frac{2}{5}\\0&0&1\\0&0&0\end{bmatrix}
   $$

10. Replace row 1 by itself plus $- \frac{2}{5}$ times row 2 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{1}\leftarrow R_{1} + (- \frac{2}{5})R_{2}}\begin{bmatrix}1&- \frac{1}{5}&0\\0&0&1\\0&0&0\end{bmatrix}
   $$

11. The pivot columns are 1, 3; the free variable is $x_2$.

12. The pivot equations give $x_1=\frac{x_{2}}{5}$, $x_3=0$.

13. Choose one free variable at a time and set the others to zero.

14. Clear fractions where necessary.

15. The resulting basis is $\left\{\begin{bmatrix}1\\5\\0\end{bmatrix}\right\}$.

16. Hence $\dim E_{-2}=1$.

17. Eigenspace for $\lambda=3$ (algebraic multiplicity 2): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

18. Row-reduce the homogeneous system: start with $A-(3)I=\begin{bmatrix}0&-1&2\\0&-5&0\\0&0&0\end{bmatrix}$.

19. Multiply row 1 by $-1$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (-1)R_{1}}\begin{bmatrix}0&1&-2\\0&-5&0\\0&0&0\end{bmatrix}
   $$

20. Replace row 2 by itself plus $5$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (5)R_{1}}\begin{bmatrix}0&1&-2\\0&0&-10\\0&0&0\end{bmatrix}
   $$

21. Multiply row 2 by $- \frac{1}{10}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{2}\leftarrow (- \frac{1}{10})R_{2}}\begin{bmatrix}0&1&-2\\0&0&1\\0&0&0\end{bmatrix}
   $$

22. Replace row 1 by itself plus $2$ times row 2 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{1}\leftarrow R_{1} + (2)R_{2}}\begin{bmatrix}0&1&0\\0&0&1\\0&0&0\end{bmatrix}
   $$

23. The pivot columns are 2, 3; the free variable is $x_1$.

24. The pivot equations give $x_2=0$, $x_3=0$.

25. Choose one free variable at a time and set the others to zero.

26. Clear fractions where necessary.

27. The resulting basis is $\left\{\begin{bmatrix}1\\0\\0\end{bmatrix}\right\}$.

28. Hence $\dim E_{3}=1$.

29. The roots of the factored polynomial are $\lambda=-2$ (algebraic multiplicity 1), $\lambda=3$ (algebraic multiplicity 2).

30. Check: $A\begin{bmatrix}1\\5\\0\end{bmatrix}=\begin{bmatrix}-2\\-10\\0\end{bmatrix}=-2\begin{bmatrix}1\\5\\0\end{bmatrix}$.

31. Check: $A\begin{bmatrix}1\\0\\0\end{bmatrix}=\begin{bmatrix}3\\0\\0\end{bmatrix}=3\begin{bmatrix}1\\0\\0\end{bmatrix}$.
::::

:::

:::problem[Problem M.10 — Diagonalizable repeated root]{difficulty=standard}
For $A=\begin{bmatrix}2&0&0\\0&2&0\\0&0&4\end{bmatrix}$, find a basis for each eigenspace and decide diagonalizability.

::::solution[Solution]
**Answer:** $P=\begin{bmatrix}1&0&0\\0&1&0\\0&0&1\end{bmatrix}$, $D=\begin{bmatrix}2&0&0\\0&2&0\\0&0&4\end{bmatrix}$; Eigenvalues $2$, $4$.  Eigenspace bases: $E_{2}=\span\left\{\begin{bmatrix}1\\0\\0\end{bmatrix}, \begin{bmatrix}0\\1\\0\end{bmatrix}\right\}$, $E_{4}=\span\left\{\begin{bmatrix}0\\0\\1\end{bmatrix}\right\}$.

1. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

2. Form $A-\lambda I=\begin{bmatrix}2 - \lambda&0&0\\0&2 - \lambda&0\\0&0&4 - \lambda\end{bmatrix}$.

3. The matrix is triangular, so multiply its three diagonal entries after subtracting $\lambda$:

4. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=\left(4 - \lambda\right) \left(\lambda - 2\right)^{2}=- \lambda^{3} + 8 \lambda^{2} - 20 \lambda + 16.
   $$

5. Eigenspace for $\lambda=2$ (algebraic multiplicity 2): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

6. Row-reduce the homogeneous system: start with $A-(2)I=\begin{bmatrix}0&0&0\\0&0&0\\0&0&2\end{bmatrix}$.

7. Swap rows 1 and 3 to place a nonzero pivot or reorder the equations.

   $$
   \xrightarrow{R_{1}\leftrightarrow R_{3}}\begin{bmatrix}0&0&2\\0&0&0\\0&0&0\end{bmatrix}
   $$

8. Multiply row 1 by $\frac{1}{2}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (\frac{1}{2})R_{1}}\begin{bmatrix}0&0&1\\0&0&0\\0&0&0\end{bmatrix}
   $$

9. The pivot columns are 3; the free variables are $x_1$, $x_2$.

10. The pivot equations give $x_3=0$.

11. Choose one free variable at a time and set the others to zero.

12. Clear fractions where necessary.

13. The resulting basis is $\left\{\begin{bmatrix}1\\0\\0\end{bmatrix},\;\begin{bmatrix}0\\1\\0\end{bmatrix}\right\}$.

14. Hence $\dim E_{2}=2$.

15. Eigenspace for $\lambda=4$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

16. Row-reduce the homogeneous system: start with $A-(4)I=\begin{bmatrix}-2&0&0\\0&-2&0\\0&0&0\end{bmatrix}$.

17. Multiply row 1 by $- \frac{1}{2}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (- \frac{1}{2})R_{1}}\begin{bmatrix}1&0&0\\0&-2&0\\0&0&0\end{bmatrix}
   $$

18. Multiply row 2 by $- \frac{1}{2}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{2}\leftarrow (- \frac{1}{2})R_{2}}\begin{bmatrix}1&0&0\\0&1&0\\0&0&0\end{bmatrix}
   $$

19. The pivot columns are 1, 2; the free variable is $x_3$.

20. The pivot equations give $x_1=0$, $x_2=0$.

21. Choose one free variable at a time and set the others to zero.

22. Clear fractions where necessary.

23. The resulting basis is $\left\{\begin{bmatrix}0\\0\\1\end{bmatrix}\right\}$.

24. Hence $\dim E_{4}=1$.

25. The roots of the factored polynomial are $\lambda=4$ (algebraic multiplicity 1), $\lambda=2$ (algebraic multiplicity 2).

26. **Diagonalization:** the eigenspace bases give $P=\begin{bmatrix}1&0&0\\0&1&0\\0&0&1\end{bmatrix}$ and $D=\begin{bmatrix}2&0&0\\0&2&0\\0&0&4\end{bmatrix}$.

27. Check $AP=\begin{bmatrix}2&0&0\\0&2&0\\0&0&4\end{bmatrix}=PD$.

28. Since $\det P=1\ne0$, $P$ is invertible, and $A=PDP^{-1}$.

29. Check: $A\begin{bmatrix}1\\0\\0\end{bmatrix}=\begin{bmatrix}2\\0\\0\end{bmatrix}=2\begin{bmatrix}1\\0\\0\end{bmatrix}$.

30. Check: $A\begin{bmatrix}0\\1\\0\end{bmatrix}=\begin{bmatrix}0\\2\\0\end{bmatrix}=2\begin{bmatrix}0\\1\\0\end{bmatrix}$.

31. Check: $A\begin{bmatrix}0\\0\\1\end{bmatrix}=\begin{bmatrix}0\\0\\4\end{bmatrix}=4\begin{bmatrix}0\\0\\1\end{bmatrix}$.
::::

:::

:::problem[Problem M.11 — Differential equations by eigenmodes]{difficulty=standard}
Solve $\mathbf{x}'=A\mathbf{x}$ for $A=\begin{bmatrix}1&1\\0&2\end{bmatrix}$, $\mathbf{x}(0)=\begin{bmatrix}1\\1\end{bmatrix}$.

::::solution[Solution]
**Answer:** $\mathbf{x}(t)=(0)e^{1t}\begin{bmatrix}1\\0\end{bmatrix} + (1)e^{2t}\begin{bmatrix}1\\1\end{bmatrix}$.

1. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

2. Form $A-\lambda I=\begin{bmatrix}1 - \lambda&1\\0&2 - \lambda\end{bmatrix}$.

3. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=(1-\lambda)(2-\lambda)-(1)(0)
   $$

4. Expand, simplify, and factor the preceding expression.

   $$
   =\lambda^{2} - 3 \lambda + 2=\left(\lambda - 2\right) \left(\lambda - 1\right).
   $$

5. Eigenspace for $\lambda=1$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

6. Row-reduce the homogeneous system: start with $A-(1)I=\begin{bmatrix}0&1\\0&1\end{bmatrix}$.

7. Replace row 2 by itself plus $-1$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (-1)R_{1}}\begin{bmatrix}0&1\\0&0\end{bmatrix}
   $$

8. The pivot columns are 2; the free variable is $x_1$.

9. The pivot equations give $x_2=0$.

10. Choose one free variable at a time and set the others to zero.

11. Clear fractions where necessary.

12. The resulting basis is $\left\{\begin{bmatrix}1\\0\end{bmatrix}\right\}$.

13. Hence $\dim E_{1}=1$.

14. Eigenspace for $\lambda=2$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

15. Row-reduce the homogeneous system: start with $A-(2)I=\begin{bmatrix}-1&1\\0&0\end{bmatrix}$.

16. Multiply row 1 by $-1$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (-1)R_{1}}\begin{bmatrix}1&-1\\0&0\end{bmatrix}
   $$

17. The pivot columns are 1; the free variable is $x_2$.

18. The pivot equations give $x_1=x_{2}$.

19. Choose one free variable at a time and set the others to zero.

20. Clear fractions where necessary.

21. The resulting basis is $\left\{\begin{bmatrix}1\\1\end{bmatrix}\right\}$.

22. Hence $\dim E_{2}=1$.

23. The roots of the factored polynomial are $\lambda=2$ (algebraic multiplicity 1), $\lambda=1$ (algebraic multiplicity 1).

24. Build $P=\begin{bmatrix}1&1\\0&1\end{bmatrix}$ from eigenvectors and solve the initial condition $P\mathbf{c}=\begin{bmatrix}1\\1\end{bmatrix}$.

25. The system gives $\mathbf{c}=\begin{bmatrix}0\\1\end{bmatrix}$.

26. Consequently

27. $\mathbf{x}(t)=(0)e^{1t}\begin{bmatrix}1\\0\end{bmatrix} + (1)e^{2t}\begin{bmatrix}1\\1\end{bmatrix}.$
28. Check at $t=0$: $P\mathbf{c}=\begin{bmatrix}1\\1\end{bmatrix}=\begin{bmatrix}1\\1\end{bmatrix}$.

29. Each exponential term differentiates into $\lambda$ times itself, exactly $A$ acting on its eigenvector.

30. Check: $A\begin{bmatrix}1\\0\end{bmatrix}=\begin{bmatrix}1\\0\end{bmatrix}=1\begin{bmatrix}1\\0\end{bmatrix}$.

31. Check: $A\begin{bmatrix}1\\1\end{bmatrix}=\begin{bmatrix}2\\2\end{bmatrix}=2\begin{bmatrix}1\\1\end{bmatrix}$.
::::

:::

:::problem[Problem M.12 — Complex spectral test]{difficulty=challenge}
Find complex eigenvalues and an eigenspace basis for $A=\begin{bmatrix}1&-2\\2&1\end{bmatrix}$.

::::solution[Solution]
**Answer:** $\lambda=1 + 2 i,\;1 - 2 i$; respective bases $\begin{bmatrix}i\\1\end{bmatrix}$ and $\begin{bmatrix}- i\\1\end{bmatrix}$.

1. $\det(A-\lambda I)=(1-\lambda)(1-\lambda)-(-2)(2)=\lambda^{2} - 2 \lambda + 5=\lambda^{2} - 2 \lambda + 5.$

2. For the positive imaginary root:

3. $A-(1 + 2 i)I=\begin{bmatrix}- 2 i&-2\\2&- 2 i\end{bmatrix}$.

4. $\xrightarrow{R_{1}\leftarrow (\frac{i}{2})R_{1}}\begin{bmatrix}1&- i\\2&- 2 i\end{bmatrix}$

5. $\xrightarrow{R_{2}\leftarrow R_{2} + (-2)R_{1}}\begin{bmatrix}1&- i\\0&0\end{bmatrix}$

6. Pivot column 1, free variable $x_{2}$.

7. Choose $x_2=1$; then $x_1=i$, so $E_{1 + 2 i}=\span\{\begin{bmatrix}i\\1\end{bmatrix}\}$.

8. Direct multiplication gives $A\begin{bmatrix}i\\1\end{bmatrix}=\begin{bmatrix}-2 + i\\1 + 2 i\end{bmatrix}=(1 + 2 i)\begin{bmatrix}i\\1\end{bmatrix}$.

9. For the conjugate root:

10. $A-(1 - 2 i)I=\begin{bmatrix}2 i&-2\\2&2 i\end{bmatrix}$.

11. $\xrightarrow{R_{1}\leftarrow (- \frac{i}{2})R_{1}}\begin{bmatrix}1&i\\2&2 i\end{bmatrix}$

12. $\xrightarrow{R_{2}\leftarrow R_{2} + (-2)R_{1}}\begin{bmatrix}1&i\\0&0\end{bmatrix}$

13. Pivot column 1, free variable $x_{2}$.

14. Choose $x_2=1$; then $x_1=- i$, so $E_{1 - 2 i}=\span\{\begin{bmatrix}- i\\1\end{bmatrix}\}$.

15. Direct multiplication gives $A\begin{bmatrix}- i\\1\end{bmatrix}=\begin{bmatrix}-2 - i\\1 - 2 i\end{bmatrix}=(1 - 2 i)\begin{bmatrix}- i\\1\end{bmatrix}$.
::::

:::

:::problem[Problem M.13 — Three-state steady distribution]{difficulty=challenge}
For the transition matrix $P=\begin{bmatrix}\frac{1}{2}&\frac{1}{4}&\frac{1}{4}\\\frac{1}{4}&\frac{1}{2}&\frac{1}{4}\\\frac{1}{4}&\frac{1}{4}&\frac{1}{2}\end{bmatrix}$, find the steady state.

::::solution[Solution]
**Answer:** $\mathbf{q}=\begin{bmatrix}\frac{1}{3}\\\frac{1}{3}\\\frac{1}{3}\end{bmatrix}$.

1. Every column sums to 1 and all entries are nonnegative, so $P$ is stochastic.

2. Use the characteristic equation $\det(A-\lambda I)=0$ to find the eigenvalues.

3. Form $A-\lambda I=\begin{bmatrix}\frac{1}{2} - \lambda&\frac{1}{4}&\frac{1}{4}\\\frac{1}{4}&\frac{1}{2} - \lambda&\frac{1}{4}\\\frac{1}{4}&\frac{1}{4}&\frac{1}{2} - \lambda\end{bmatrix}$.

4. Expand along column 1, which has the most zeros (ties favor columns).

5. The cofactor signs alternate $+,-,+$ across the first row.

6. Compute the determinant of the shifted matrix.

   $$
   \det(A-\lambda I)=(\frac{1}{2} - \lambda)\left[(\frac{1}{2} - \lambda)(\frac{1}{2} - \lambda)-(\frac{1}{4})(\frac{1}{4})\right]-(\frac{1}{4})\left[(\frac{1}{4})(\frac{1}{2} - \lambda)-(\frac{1}{4})(\frac{1}{4})\right]+(\frac{1}{4})\left[(\frac{1}{4})(\frac{1}{4})-(\frac{1}{4})(\frac{1}{2} - \lambda)\right]
   $$

7. Expand, simplify, and factor the preceding expression.

   $$
   =- \lambda^{3} + \frac{3 \lambda^{2}}{2} - \frac{9 \lambda}{16} + \frac{1}{16}=\frac{\left(1 - \lambda\right) \left(4 \lambda - 1\right)^{2}}{16}.
   $$

8. Eigenspace for $\lambda=\frac{1}{4}$ (algebraic multiplicity 2): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

9. Row-reduce the homogeneous system: start with $A-(\frac{1}{4})I=\begin{bmatrix}\frac{1}{4}&\frac{1}{4}&\frac{1}{4}\\\frac{1}{4}&\frac{1}{4}&\frac{1}{4}\\\frac{1}{4}&\frac{1}{4}&\frac{1}{4}\end{bmatrix}$.

10. Multiply row 1 by $4$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (4)R_{1}}\begin{bmatrix}1&1&1\\\frac{1}{4}&\frac{1}{4}&\frac{1}{4}\\\frac{1}{4}&\frac{1}{4}&\frac{1}{4}\end{bmatrix}
   $$

11. Replace row 2 by itself plus $- \frac{1}{4}$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (- \frac{1}{4})R_{1}}\begin{bmatrix}1&1&1\\0&0&0\\\frac{1}{4}&\frac{1}{4}&\frac{1}{4}\end{bmatrix}
   $$

12. Replace row 3 by itself plus $- \frac{1}{4}$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{3}\leftarrow R_{3} + (- \frac{1}{4})R_{1}}\begin{bmatrix}1&1&1\\0&0&0\\0&0&0\end{bmatrix}
   $$

13. The pivot columns are 1; the free variables are $x_2$, $x_3$.

14. The pivot equations give $x_1=- x_{2} - x_{3}$.

15. Choose one free variable at a time and set the others to zero.

16. Clear fractions where necessary.

17. The resulting basis is $\left\{\begin{bmatrix}-1\\1\\0\end{bmatrix},\;\begin{bmatrix}-1\\0\\1\end{bmatrix}\right\}$.

18. Hence $\dim E_{\frac{1}{4}}=2$.

19. Eigenspace for $\lambda=1$ (algebraic multiplicity 1): solve $(A-\lambda I)\mathbf x=0$ to get its basis.

20. Row-reduce the homogeneous system: start with $A-(1)I=\begin{bmatrix}- \frac{1}{2}&\frac{1}{4}&\frac{1}{4}\\\frac{1}{4}&- \frac{1}{2}&\frac{1}{4}\\\frac{1}{4}&\frac{1}{4}&- \frac{1}{2}\end{bmatrix}$.

21. Multiply row 1 by $-2$ to normalize its leading entry.

   $$
   \xrightarrow{R_{1}\leftarrow (-2)R_{1}}\begin{bmatrix}1&- \frac{1}{2}&- \frac{1}{2}\\\frac{1}{4}&- \frac{1}{2}&\frac{1}{4}\\\frac{1}{4}&\frac{1}{4}&- \frac{1}{2}\end{bmatrix}
   $$

22. Replace row 2 by itself plus $- \frac{1}{4}$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{2}\leftarrow R_{2} + (- \frac{1}{4})R_{1}}\begin{bmatrix}1&- \frac{1}{2}&- \frac{1}{2}\\0&- \frac{3}{8}&\frac{3}{8}\\\frac{1}{4}&\frac{1}{4}&- \frac{1}{2}\end{bmatrix}
   $$

23. Replace row 3 by itself plus $- \frac{1}{4}$ times row 1 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{3}\leftarrow R_{3} + (- \frac{1}{4})R_{1}}\begin{bmatrix}1&- \frac{1}{2}&- \frac{1}{2}\\0&- \frac{3}{8}&\frac{3}{8}\\0&\frac{3}{8}&- \frac{3}{8}\end{bmatrix}
   $$

24. Multiply row 2 by $- \frac{8}{3}$ to normalize its leading entry.

   $$
   \xrightarrow{R_{2}\leftarrow (- \frac{8}{3})R_{2}}\begin{bmatrix}1&- \frac{1}{2}&- \frac{1}{2}\\0&1&-1\\0&\frac{3}{8}&- \frac{3}{8}\end{bmatrix}
   $$

25. Replace row 1 by itself plus $\frac{1}{2}$ times row 2 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{1}\leftarrow R_{1} + (\frac{1}{2})R_{2}}\begin{bmatrix}1&0&-1\\0&1&-1\\0&\frac{3}{8}&- \frac{3}{8}\end{bmatrix}
   $$

26. Replace row 3 by itself plus $- \frac{3}{8}$ times row 2 to eliminate a pivot-column entry.

   $$
   \xrightarrow{R_{3}\leftarrow R_{3} + (- \frac{3}{8})R_{2}}\begin{bmatrix}1&0&-1\\0&1&-1\\0&0&0\end{bmatrix}
   $$

27. The pivot columns are 1, 2; the free variable is $x_3$.

28. The pivot equations give $x_1=x_{3}$, $x_2=x_{3}$.

29. Choose one free variable at a time and set the others to zero.

30. Clear fractions where necessary.

31. The resulting basis is $\left\{\begin{bmatrix}1\\1\\1\end{bmatrix}\right\}$.

32. Hence $\dim E_{1}=1$.

33. The roots of the factored polynomial are $\lambda=1$ (algebraic multiplicity 1), $\lambda=\frac{1}{4}$ (algebraic multiplicity 2).

34. For $\lambda=1$, the free-variable basis gives $\mathbf{v}=\begin{bmatrix}1\\1\\1\end{bmatrix}$.

35. Sum its coordinates: $3$.

36. Normalize $\mathbf{q}=\mathbf{v}/3=\begin{bmatrix}\frac{1}{3}\\\frac{1}{3}\\\frac{1}{3}\end{bmatrix}$.

37. Check $P\mathbf{q}=\begin{bmatrix}\frac{1}{3}\\\frac{1}{3}\\\frac{1}{3}\end{bmatrix}$.

38. Check: $A\begin{bmatrix}-1\\1\\0\end{bmatrix}=\begin{bmatrix}- \frac{1}{4}\\\frac{1}{4}\\0\end{bmatrix}=\frac{1}{4}\begin{bmatrix}-1\\1\\0\end{bmatrix}$.

39. Check: $A\begin{bmatrix}-1\\0\\1\end{bmatrix}=\begin{bmatrix}- \frac{1}{4}\\0\\\frac{1}{4}\end{bmatrix}=\frac{1}{4}\begin{bmatrix}-1\\0\\1\end{bmatrix}$.

40. Check: $A\begin{bmatrix}1\\1\\1\end{bmatrix}=\begin{bmatrix}1\\1\\1\end{bmatrix}=1\begin{bmatrix}1\\1\\1\end{bmatrix}$.
::::

:::

