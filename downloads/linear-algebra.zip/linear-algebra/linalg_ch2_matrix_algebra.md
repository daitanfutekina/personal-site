---
title: "Matrix Algebra"
crumb: "Linear Algebra · Chapter 2"
meta:
  - "Est. study time: ~105 min"
  - "MA 3113 · Mississippi State University"
source: "markdown"
---

## Overview

Chapter 1 treated matrices mainly as bookkeeping tools for systems of equations. Now we study
 matrices as objects in their own right: we multiply them, invert them, and factor them.
 The key concept is the **matrix inverse** — the matrix equivalent of dividing by a number.
 Not every matrix has one, and the precise conditions for invertibility turn out to unify almost
 every important idea from Chapter 1 into a single elegant theorem.

:::callout-key[What you'll learn]
- How to add, scale, and multiply matrices — and why multiplication is *not* commutative
- How to compute and use the matrix inverse $A^{-1}$
- The Invertible Matrix Theorem: 10+ equivalent conditions for a square matrix to be invertible
- LU factorization: how row reduction factors $A = LU$ for efficient repeated solving
- Subspaces, basis, dimension, and the rank of a matrix
:::

:::callout-tip[Prerequisites]
All of Chapter 1: augmented matrices, row reduction, RREF, linear independence, and linear transformations.
:::

## 2.1 Matrix Operations

:::callout-intuition[Intuition first]
Addition and scalar multiplication of matrices are completely natural — do them entry by entry.
 Matrix multiplication is the surprising one: the $(i,j)$ entry of $AB$ is the dot product
 of row $i$ of $A$ with column $j$ of $B$. This definition isn't arbitrary — it's designed
 so that $AB\mathbf{x} = A(B\mathbf{x})$, meaning "apply $B$ first, then $A$."
 That's why multiplying matrices from the right corresponds to composing transformations.
:::

:::definition[Definition 2.1 — Matrix Addition & Scalar Multiple]
If $A$ and $B$ are $m \times n$ matrices and $c$ is a scalar, then $A + B$ and $cA$
 are the $m \times n$ matrices obtained by adding (or scaling) corresponding entries:

$$
(A+B)_{ij} = a_{ij} + b_{ij}, \qquad (cA)_{ij} = c\,a_{ij}.
$$

 Addition requires the same size. The **transpose** of $A$ is $A^T$, with
 $(A^T)_{ij} = a_{ji}$ (rows become columns).
:::

:::definition[Definition 2.2 — Matrix Multiplication]
If $A$ is $m\times n$ and $B$ is $n\times p$, the product $AB$ is the $m\times p$
 matrix whose $(i,j)$ entry is

$$
(AB)_{ij} = a_{i1}b_{1j} + a_{i2}b_{2j} + \cdots + a_{in}b_{nj} = \sum_{k=1}^n a_{ik}b_{kj}.
$$

 The number of columns of $A$ must equal the number of rows of $B$.
:::

### Key properties of matrix multiplication

:::theorem[Theorem 2.1 — Algebraic Properties]
Let $A, B, C$ be matrices of compatible sizes and $r, s$ scalars. Then:

- $A(BC) = (AB)C$ (associativity)
- $A(B+C) = AB + AC$ (left distributivity)
- $(B+C)A = BA + CA$ (right distributivity)
- $r(AB) = (rA)B = A(rB)$
- $I_m A = A = A I_n$ (identity matrix)
- $(AB)^T = B^T A^T$ (transpose reverses order)

**Warning:** In general, $AB \neq BA$. Matrix multiplication is *not* commutative.
:::

### Worked examples

<figure class="fig">
<svg class="fig-hue-1" viewBox="0 0 440 240" role="img" aria-label="Composition of transformations B followed by A maps three labeled vectors.">
<circle class="fig-point" cx="58" cy="105" r="5"/><circle class="fig-point" cx="218" cy="105" r="5"/><circle class="fig-point" cx="378" cy="105" r="5"/><path class="fig-curve" d="M68 105 L208 105"/><path class="fig-arrow" d="M196 99 L208 105 L196 111"/><path class="fig-curve-alt" d="M228 105 L368 105"/><path class="fig-arrow" d="M356 99 L368 105 L356 111"/><text class="fig-label" x="22" y="85">x=(1,1)</text><text class="fig-label" x="177" y="85">Bx=(2,1)</text><text class="fig-label" x="327" y="85">ABx=(2,3)</text><text class="fig-label-em" x="135" y="125">B first</text><text class="fig-label-em" x="292" y="125">A next</text>
</svg>
<figcaption>For $B=\begin{bmatrix}1&1\\0&1\end{bmatrix}$ and $A=\begin{bmatrix}1&0\\1&1\end{bmatrix}$, $x=(1,1)^T\to Bx=(2,1)^T\to A(Bx)=(2,3)^T$. Thus $AB$ means $B$ first, then $A$.</figcaption>
</figure>

:::example[Example 2.1 — Matrix multiplication]
Compute $AB$ where
 $A = \begin{bmatrix}1&2\\3&4\end{bmatrix}$ and
 $B = \begin{bmatrix}0&-1\\2&1\end{bmatrix}$.

::::answer[Answer]
**Answer:** $AB = \begin{bmatrix}4&1\\8&1\end{bmatrix}$

1. The $(i,j)$ entry of a product is row $i$ dotted with column $j$; the inner dimensions must match.

2. Each entry = (row of $A$) $\cdot$ (column of $B$):

3. Use the displayed equality to perform the next algebraic operation:

    $$
    (AB)_{11} = (1)(0)+(2)(2) = 4
    $$

4. Use the displayed equality to perform the next algebraic operation:

    $$
    (AB)_{12} = (1)(-1)+(2)(1) = 1
    $$

5. Use the displayed equality to perform the next algebraic operation:

    $$
    (AB)_{21} = (3)(0)+(4)(2) = 8
    $$

6. Use the displayed equality to perform the next algebraic operation:

    $$
    (AB)_{22} = (3)(-1)+(4)(1) = 1
    $$

7. So $AB = \begin{bmatrix}4&1\\8&1\end{bmatrix}$. Now check $BA$ to see non-commutativity:

8. Evaluate each displayed entry using the corresponding definition:

    $$
    BA = \begin{bmatrix}0&-1\\2&1\end{bmatrix}\begin{bmatrix}1&2\\3&4\end{bmatrix}
               = \begin{bmatrix}-3&-4\\5&8\end{bmatrix} \neq AB.
    $$

9. Check the product size before comparing the computed matrix entries.
::::
:::

:::example[Example 2.2 — Transpose properties]
Let $A = \begin{bmatrix}1&2\\3&4\\5&6\end{bmatrix}$. Compute $A^T A$.

::::answer[Answer]
**Answer:** $A^T A = \begin{bmatrix}35&44\\44&56\end{bmatrix}$

1. Transposition switches row and column indices; for a product it reverses multiplication order.

2. $A^T = \begin{bmatrix}1&3&5\\2&4&6\end{bmatrix}$, so $A^T A$ is $2\times2$:

3. Evaluate each displayed entry using the corresponding definition:

    $$
    A^T A = \begin{bmatrix}1\cdot1+3\cdot3+5\cdot5 & 1\cdot2+3\cdot4+5\cdot6\\
                                   2\cdot1+4\cdot3+6\cdot5 & 2\cdot2+4\cdot4+6\cdot6\end{bmatrix}
                 = \begin{bmatrix}35&44\\44&56\end{bmatrix}
    $$

4. Notice $A^T A$ is always square and *symmetric*: $(A^T A)^T = A^T(A^T)^T = A^T A$. This matrix appears constantly in least-squares problems (Chapter 6).

5. Compare the dimensions and every corresponding entry in the two displayed matrices.
::::
:::

:::callout-pitfall[Watch out for]
- **$AB \neq BA$ in general.** Always check the order. "Pre-multiplying by $A$" vs. "post-multiplying by $A$" are different operations.
- **$AB = AC$ does not imply $B = C$.** You cannot "cancel" $A$ from both sides unless $A$ is invertible.
- **$AB = 0$ does not imply $A = 0$ or $B = 0$.** Zero divisors exist in matrix algebra.
- **Size compatibility.** $A_{m\times n} \cdot B_{p\times q}$ is defined only when $n = p$; the result is $m\times q$.
:::

### Matrix notation and equality

The lecture uses four interchangeable representations of a matrix:

1. A capital letter such as $A$, $B$, or $C$.
2. Its indexed entries, such as $[a_{ij}]$, $[b_{ij}]$, or $[c_{ij}]$.
3. Its full rectangular array,

$$
A=[a_{ij}]=\begin{bmatrix}
a_{11}&a_{12}&\cdots&a_{1n}\\
a_{21}&a_{22}&\cdots&a_{2n}\\
\vdots&\vdots&&\vdots\\
a_{m1}&a_{m2}&\cdots&a_{mn}
\end{bmatrix}.
$$

4. Its list of columns,

$$
A=[\mathbf{a}_1\ \mathbf{a}_2\ \cdots\ \mathbf{a}_n],
\qquad
\mathbf{a}_j=\begin{bmatrix}a_{1j}\\a_{2j}\\\vdots\\a_{mj}\end{bmatrix}.
$$

:::definition[Definition 2.1A — Equality of Matrices]
For $A=[a_{ij}]$ and $B=[b_{ij}]$, the equality $A=B$ holds if and only if the matrices have the same order $m\times n$ and $a_{ij}=b_{ij}$ for every row $i$ and column $j$.
:::

### Entrywise operations from the lecture

:::example[Example 2.3 — Matrix addition and an undefined sum]
Add the two matrices and compare their dimensions with the vector and incompatible-matrix cases in the walkthrough:

$$
A=\begin{bmatrix}-1&2\\3&-4\end{bmatrix},\qquad
    B=\begin{bmatrix}0&1\\-1&2\end{bmatrix},
$$

::::answer[Answer]
**Answer:** $A+B=\begin{bmatrix}-1&3\\2&-2\end{bmatrix}$; vector sum $=(0,4,0)^T$; $3\times3+2\times3$ is undefined.

1. Combine matching entries only when matrix dimensions agree; apply scalar factors to every entry.

2. For

3. Evaluate each displayed entry using the corresponding definition:

    $$
    A=\begin{bmatrix}-1&2\\3&-4\end{bmatrix},\qquad
    B=\begin{bmatrix}0&1\\-1&2\end{bmatrix},
    $$

4. entrywise addition gives

5. Evaluate each displayed entry using the corresponding definition:

    $$
    A+B=\begin{bmatrix}-1&3\\2&-2\end{bmatrix}.
    $$

6. Likewise,

7. Evaluate each displayed entry using the corresponding definition:

    $$
    \begin{bmatrix}1\\2\\3\end{bmatrix}
    +\begin{bmatrix}-1\\2\\-3\end{bmatrix}
    =\begin{bmatrix}0\\4\\0\end{bmatrix}.
    $$

8. However, if $A$ is $3\times3$ and $B$ is $2\times3$, then $A+B$ is undefined. Corresponding entries cannot be paired because the matrices do not have the same order.

9. Check at least one row and the dimensions against the original matrices.
::::
:::

For $A=[a_{ij}]_{m\times n}$ and a scalar $c$, scalar multiplication is

$$
cA=[ca_{ij}]_{m\times n}.
$$

Subtraction is defined by addition of the additive inverse:

$$
A-B=A+(-1)B.
$$

:::example[Example 2.4 — Scalar multiplication and subtraction]
Compute $\frac12 A$, $-B$, and $\frac12A-B$ for these matrices:

$$
A=\begin{bmatrix}1&0&2\\-1&2&3\\4&5&-2\end{bmatrix},\qquad
    B=\begin{bmatrix}0&1&0\\1&3&2\\-2&3&1\end{bmatrix}.
$$

::::answer[Answer]
**Answer:** $\frac12A-B=\begin{bmatrix}\tfrac12&-1&1\\-\tfrac32&-2&-\tfrac12\\4&-\tfrac12&-2\end{bmatrix}$.

1. The $(i,j)$ entry of a product is row $i$ dotted with column $j$; the inner dimensions must match.

2. Let

3. Evaluate each displayed entry using the corresponding definition:

    $$
    A=\begin{bmatrix}1&0&2\\-1&2&3\\4&5&-2\end{bmatrix},\qquad
    B=\begin{bmatrix}0&1&0\\1&3&2\\-2&3&1\end{bmatrix}.
    $$

4. Then

5. Evaluate each displayed entry using the corresponding definition:

    $$
    \frac12A=\begin{bmatrix}\tfrac12&0&1\\-\tfrac12&1&\tfrac32\\2&\tfrac52&-1\end{bmatrix},
    \qquad
    -B=\begin{bmatrix}0&-1&0\\-1&-3&-2\\2&-3&-1\end{bmatrix},
    $$

6. and

7. Evaluate each displayed entry using the corresponding definition:

    $$
    \frac12A-B=
    \begin{bmatrix}\tfrac12&-1&1\\-\tfrac32&-2&-\tfrac12\\4&-\tfrac12&-2\end{bmatrix}.
    $$

8. Check the product size before comparing the computed matrix entries.
::::
:::

### Two views of matrix multiplication

If $A=[a_{ij}]$ is $m\times n$ and $B=[b_{ij}]$ is $n\times p$, define $AB=[c_{ij}]_{m\times p}$ by

$$
c_{ij}=\sum_{k=1}^{n}a_{ik}b_{kj}
=a_{i1}b_{1j}+a_{i2}b_{2j}+\cdots+a_{in}b_{nj}.
$$

The same product can be read one output column at a time. If
$B=[\mathbf{b}_1\ \cdots\ \mathbf{b}_p]$, then

$$
AB=A[\mathbf{b}_1\ \cdots\ \mathbf{b}_p]
=[A\mathbf{b}_1\ A\mathbf{b}_2\ \cdots\ A\mathbf{b}_p].
$$

<figure class="fig">
<svg class="fig-hue-2" viewBox="0 0 320 150" role="img" aria-label="Row i of A and column j of B meet to determine entry c i j of AB">
<path class="fig-guide" d="M15 20 L125 20 L125 125 L15 125 Z M148 20 L244 20 L244 125 L148 125 Z M266 45 L309 45 L309 102 L266 102 Z"/>
<path class="fig-fill" d="M18 65 L122 65 L122 82 L18 82 Z"/>
<path class="fig-fill-alt" d="M187 23 L205 23 L205 122 L187 122 Z"/>
<circle class="fig-point" cx="287" cy="74" r="7"/>
<path class="fig-arrow" d="M122 74 L181 74 M181 74 L170 68 M181 74 L170 80 M205 74 L278 74 M278 74 L267 68 M278 74 L267 80"/>
<text class="fig-label-em" x="55" y="59">row i</text>
<text class="fig-label-em" x="178" y="137">column j</text>
<text class="fig-label" x="61" y="143">A</text>
<text class="fig-label" x="191" y="143">B</text>
<text class="fig-label-em" x="277" y="79">cᵢⱼ</text>
</svg>
<figcaption>The $(i,j)$ entry of $AB$ is the dot product of row $i$ of $A$ with column $j$ of $B$.</figcaption>
</figure>

:::example[Example 2.5 — One product exists and the reverse does not]
Compute $AB$ and decide whether $BA$ exists:

$$
A=\begin{bmatrix}-1&3\\4&-2\\5&0\end{bmatrix}_{3\times2},
    \qquad
    B=\begin{bmatrix}-3&2\\-4&1\end{bmatrix}_{2\times2}.
$$

::::answer[Answer]
**Answer:** $AB=\begin{bmatrix}-9&1\\-4&6\\-15&10\end{bmatrix}$; $BA$ is undefined.

1. The $(i,j)$ entry of a product is row $i$ dotted with column $j$; the inner dimensions must match.

2. Let

3. Evaluate each displayed entry using the corresponding definition:

    $$
    A=\begin{bmatrix}-1&3\\4&-2\\5&0\end{bmatrix}_{3\times2},
    \qquad
    B=\begin{bmatrix}-3&2\\-4&1\end{bmatrix}_{2\times2}.
    $$

4. The inner dimensions in $AB$ match, and

5. Evaluate each displayed entry using the corresponding definition:

    $$
    AB=\begin{bmatrix}-9&1\\-4&6\\-15&10\end{bmatrix}_{3\times2}.
    $$

6. The reverse product would have sizes $(2\times2)(3\times2)$. Its inner dimensions $2$ and $3$ do not match, so $BA$ is undefined. Matrix products are undefined for a dimension reason, not because an entrywise computation happens to fail.

7. Check the product size before comparing the computed matrix entries.
::::
:::

:::example[Example 2.6 — A worked counterexample to commutativity]
Compute $AB$ and $BA$ to test commutativity:

$$
A=\begin{bmatrix}1&2\\-1&2\end{bmatrix},\qquad
    B=\begin{bmatrix}-1&2\\4&3\end{bmatrix}.
$$

::::answer[Answer]
**Answer:** $AB=\begin{bmatrix}7&8\\9&4\end{bmatrix}\ne BA=\begin{bmatrix}-3&2\\1&14\end{bmatrix}$.

1. Combine matching entries only when matrix dimensions agree; apply scalar factors to every entry.

2. Let

3. Evaluate each displayed entry using the corresponding definition:

    $$
    A=\begin{bmatrix}1&2\\-1&2\end{bmatrix},\qquad
    B=\begin{bmatrix}-1&2\\4&3\end{bmatrix}.
    $$

4. Then

5. Evaluate each displayed entry using the corresponding definition:

    $$
    AB=\begin{bmatrix}7&8\\9&4\end{bmatrix},
    \qquad
    BA=\begin{bmatrix}-3&2\\1&14\end{bmatrix}.
    $$

6. Thus $AB\neq BA$. This single counterexample is enough to show that matrix multiplication is not commutative in general.

7. Check at least one row and the dimensions against the original matrices.
::::
:::

### Addition, scalar multiplication, and the zero matrix

:::theorem[Theorem 2.1A — Six Entrywise Properties]
If $A,B,C$ are $m\times n$ matrices and $c,d$ are scalars, then

1. $A+B=B+A$.
2. $A+(B+C)=(A+B)+C$.
3. $(cd)A=c(dA)$.
4. $1A=A$.
5. $c(A+B)=cA+cB$.
6. $(c+d)A=cA+dA$.
:::

For example,

$$
\begin{bmatrix}1\\2\\3\end{bmatrix}
+\begin{bmatrix}0\\-1\\2\end{bmatrix}
+\begin{bmatrix}-2\\1\\-3\end{bmatrix}
=\begin{bmatrix}-1\\2\\2\end{bmatrix}.
$$

:::definition[Definition 2.1B — Zero Matrix]
The matrix $O_{m\times n}$ whose entries are all zero is the **zero matrix**. It serves as the additive identity among $m\times n$ matrices.
:::

:::theorem[Theorem 2.1B — Three Zero-Matrix Properties]
For an $m\times n$ matrix $A$ and a scalar $c$,

1. $A+O=A$.
2. $A+(-A)=O$, so $-A$ is the additive inverse of $A$.
3. If $cA=O$, then $c=0$ or $A=O$.
:::

To solve a matrix equation, perform the same legal addition on both sides that you would use for a scalar equation:

| Scalar equation | Matrix equation |
| --- | --- |
| $x+a=b$ | $X+A=B$ |
| $x+a+(-a)=b+(-a)$ | $X+A+(-A)=B+(-A)$ |
| $x+0=b-a$ | $X+O=B-A$ |
| $x=b-a$ | $X=B-A$ |

:::example[Example 2.7 — Solve a matrix equation]
Solve $2X+A=B$ for

$$
A=\begin{bmatrix}-1&2\\3&0\end{bmatrix},\qquad
B=\begin{bmatrix}2&1\\-1&3\end{bmatrix}.
$$

::::answer[Answer]
**Answer:** $X=\begin{bmatrix}\tfrac32&-\tfrac12\\-2&\tfrac32\end{bmatrix}$

1. Combine matching entries only when matrix dimensions agree; apply scalar factors to every entry.

2. $X=\begin{bmatrix}\tfrac32&-\tfrac12\\-2&\tfrac32\end{bmatrix}$.

3. Evaluate each displayed entry using the corresponding definition:

    $$
    2X=B-A
    =\begin{bmatrix}3&-1\\-4&3\end{bmatrix},
    $$

4. so

5. Evaluate each displayed entry using the corresponding definition:

    $$
    X=\frac12(B-A)
    =\begin{bmatrix}\tfrac32&-\tfrac12\\-2&\tfrac32\end{bmatrix}.
    $$

6. Check at least one row and the dimensions against the original matrices.
::::
:::

### Five multiplication properties and two warnings

:::theorem[Theorem 2.1C — Five Properties of Matrix Multiplication]
For matrices of compatible orders and a scalar $c$,

1. $A(BC)=(AB)C$.
2. $A(B+C)=AB+AC$.
3. $(A+B)C=AC+BC$.
4. $c(AB)=(cA)B=A(cB)$.
5. $I_mA=A=AI_n$ for an $m\times n$ matrix $A$.
:::

:::example[Example 2.8 — Associativity computed both ways]
Compute $(AB)C$ and $A(BC)$ separately to check associativity:

$$
A=\begin{bmatrix}0&1\\3&2\end{bmatrix},\quad
    B=\begin{bmatrix}2&1&0\\3&-2&1\end{bmatrix},\quad
    C=\begin{bmatrix}0&-1\\1&3\\2&4\end{bmatrix}.
$$

::::answer[Answer]
**Answer:** $(AB)C=A(BC)=\begin{bmatrix}0&-5\\3&-7\end{bmatrix}$.

1. Combine matching entries only when matrix dimensions agree; apply scalar factors to every entry.

2. Let

3. Evaluate each displayed entry using the corresponding definition:

    $$
    A=\begin{bmatrix}0&1\\3&2\end{bmatrix},\quad
    B=\begin{bmatrix}2&1&0\\3&-2&1\end{bmatrix},\quad
    C=\begin{bmatrix}0&-1\\1&3\\2&4\end{bmatrix}.
    $$

4. First,

5. Evaluate each displayed entry using the corresponding definition:

    $$
    AB=\begin{bmatrix}3&-2&1\\12&-1&2\end{bmatrix},
    $$

6. so

7. Evaluate each displayed entry using the corresponding definition:

    $$
    (AB)C=\begin{bmatrix}0&-5\\3&-7\end{bmatrix}.
    $$

8. On the other hand,

9. Evaluate each displayed entry using the corresponding definition:

    $$
    BC=\begin{bmatrix}1&1\\0&-5\end{bmatrix},
    \qquad
    A(BC)=\begin{bmatrix}0&-5\\3&-7\end{bmatrix}.
    $$

10. Both orders of grouping agree, as associativity requires. The $(2,2)$ entry is $-7$; the lecture notes give $13$ at this point, an arithmetic slip; the two computations agree with the displayed value.

11. Check at least one row and the dimensions against the original matrices.
::::
:::

:::note[Lecture notes — Noncommutativity and failed cancellation]
First, $AB\neq BA$ in general. Second, $AC=BC$ does not imply $A=B$ unless an additional hypothesis permits cancellation.
:::

:::example[Example 2.9 — $AC=BC$ with $A\neq B$]
Compute $AC$ and $BC$ to test whether $AC=BC$ forces $A=B$:

$$
A=\begin{bmatrix}1&3\\0&1\end{bmatrix},\quad
    B=\begin{bmatrix}2&4\\2&3\end{bmatrix},\quad
    C=\begin{bmatrix}1&-2\\-1&2\end{bmatrix}.
$$

::::answer[Answer]
**Answer:** $AC=BC=\begin{bmatrix}-2&4\\-1&2\end{bmatrix}$ despite $A\ne B$.

1. The $(i,j)$ entry of a product is row $i$ dotted with column $j$; the inner dimensions must match.

2. Take

3. Evaluate each displayed entry using the corresponding definition:

    $$
    A=\begin{bmatrix}1&3\\0&1\end{bmatrix},\quad
    B=\begin{bmatrix}2&4\\2&3\end{bmatrix},\quad
    C=\begin{bmatrix}1&-2\\-1&2\end{bmatrix}.
    $$

4. Direct multiplication gives

5. Evaluate each displayed entry using the corresponding definition:

    $$
    AC=\begin{bmatrix}-2&4\\-1&2\end{bmatrix}
    =BC,
    $$

6. although $A\neq B$. The matrix $C$ loses information, so it cannot be canceled here.

7. Check the product size before comparing the computed matrix entries.
::::
:::

### Powers and transposes

If $A$ is $n\times n$ and $k$ is a positive integer, then

$$
A^k=\underbrace{A\cdot A\cdots A}_{k\text{ factors}}.
$$

:::definition[Definition 2.1C — Transpose]
If $A=[a_{ij}]$ is $m\times n$, then its **transpose** $A^T$ is the $n\times m$ matrix whose entries satisfy $(A^T)_{ij}=a_{ji}$. Equivalently, the rows of $A$ become the columns of $A^T$.
:::

:::example[Example 2.10 — Three transposes]
Transpose the row matrix $[1\ 2\ 3]$, and then the matrices shown in the walkthrough, writing all new row and column positions explicitly.

::::answer[Answer]
**Answer:** $[1\ 2\ 3]^T=(1,2,3)^T$; $B^T=\begin{bmatrix}1&2&0\\0&1&0\\2&0&1\end{bmatrix}$; $C^T=\begin{bmatrix}0&1&2\\2&3&-1\end{bmatrix}$.

1. Transposition switches row and column indices; for a product it reverses multiplication order.

2. For a row matrix,

3. Evaluate each displayed entry using the corresponding definition:

    $$
    \begin{bmatrix}1&2&3\end{bmatrix}^T
    =\begin{bmatrix}1\\2\\3\end{bmatrix}.
    $$

4. For

5. Evaluate each displayed entry using the corresponding definition:

    $$
    B=\begin{bmatrix}1&0&2\\2&1&0\\0&0&1\end{bmatrix},
    $$

6. the transpose is

7. Evaluate each displayed entry using the corresponding definition:

    $$
    B^T=\begin{bmatrix}1&2&0\\0&1&0\\2&0&1\end{bmatrix}.
    $$

8. For

9. Evaluate each displayed entry using the corresponding definition:

    $$
    C=\begin{bmatrix}0&2\\1&3\\2&-1\end{bmatrix},
    $$

10. the transpose is

11. Evaluate each displayed entry using the corresponding definition:

    $$
    C^T=\begin{bmatrix}0&1&2\\2&3&-1\end{bmatrix}.
    $$

12. Compare the dimensions and every corresponding entry in the two displayed matrices.
::::
:::

:::theorem[Theorem 2.1D — Four Transpose Properties]
For compatible matrices and a scalar $r$,

1. $(A^T)^T=A$.
2. $(A+B)^T=A^T+B^T$.
3. $(rA)^T=rA^T$.
4. $(AB)^T=B^TA^T$.

The fourth property extends to any finite product by reversing every factor:

$$
(A_1A_2\cdots A_p)^T=A_p^TA_{p-1}^T\cdots A_1^T.
$$
:::

### Practice problems

:::problem[Problem 2.1 — Matrix scaling and transpose]{difficulty=easy}
Compute $2A - B^T$ where $A=\begin{bmatrix}1&0\\-1&3\end{bmatrix}$ and $B=\begin{bmatrix}2&-1\\0&4\end{bmatrix}$.

::::solution[Solution]
**Answer:** $2A-B^T=\begin{bmatrix}0&0\\-1&2\end{bmatrix}$.

1. Scalar multiplication and transposition are entrywise operations. Multiply all four entries of $A$ by $2$, and change the two rows of $B$ into the columns of $B^T$.

2. Evaluate each displayed entry using the corresponding definition:

    $$
    2A = \begin{bmatrix}2&0\\-2&6\end{bmatrix},\quad B^T=\begin{bmatrix}2&0\\-1&4\end{bmatrix}
    $$

3. Evaluate each displayed entry using the corresponding definition:

    $$
    2A - B^T = \begin{bmatrix}0&0\\-1&2\end{bmatrix}
    $$

4. Subtract corresponding entries: top row $(2-2,\,0-0)=(0,0)$ and bottom row $(-2-(-1),\,6-4)=(-1,2)$. Both matrices are $2\times2$, so the subtraction is defined.
::::
:::

:::problem[Problem 2.2 — Two multiplication orders]{difficulty=standard}
Compute $AB$ and $BA$ for $A=\begin{bmatrix}1&-1\\2&0\end{bmatrix}$, $B=\begin{bmatrix}3&1\\1&2\end{bmatrix}$. Are they equal?

::::solution[Solution]
**Answer:** $AB=\begin{bmatrix}2&-1\\6&2\end{bmatrix}$ and $BA=\begin{bmatrix}5&-3\\5&-1\end{bmatrix}$; $AB\ne BA$.

1. Both products exist because both factors are $2\times2$. For each position, take the appropriate row of the left matrix dotted with the matching column of the right matrix.

2. Evaluate each displayed entry using the corresponding definition:

    $$
    AB=\begin{bmatrix}2&-1\\6&2\end{bmatrix},\quad BA=\begin{bmatrix}5&-3\\5&-1\end{bmatrix}.
    $$

3. $AB \neq BA$ — multiplication is not commutative here.

4. Check the product size before comparing the computed matrix entries.

5. For example, $(AB)_{11}=1(3)+(-1)(1)=2$ whereas $(BA)_{11}=3(1)+1(2)=5$. This single differing entry is enough to establish $AB\ne BA$.
::::
:::

:::problem[Problem 2.3 — Commuting with a diagonal matrix]{difficulty=standard}
Find all $2\times2$ matrices $B$ such that $AB = BA$ where $A = \begin{bmatrix}1&0\\0&2\end{bmatrix}$.

::::solution[Solution]
**Answer:** $b=c=0$, so $B$ must be diagonal.

1. Write an arbitrary matrix as $B=\begin{bmatrix}a&b\\c&d\end{bmatrix}$. Multiplication by $A=\operatorname{diag}(1,2)$ scales rows in $AB$ but scales columns in $BA$.

2. Let $B=\begin{bmatrix}a&b\\c&d\end{bmatrix}$. Then $AB=\begin{bmatrix}a&b\\2c&2d\end{bmatrix}$ and $BA=\begin{bmatrix}a&2b\\c&2d\end{bmatrix}$.

3. Setting equal: $b=2b\Rightarrow b=0$ and $2c=c\Rightarrow c=0$. So $B=\begin{bmatrix}a&0\\0&d\end{bmatrix}$ — any diagonal matrix commutes with $A$.

4. Equating the off-diagonal entries gives $b=2b$ and $2c=c$. Subtract to obtain $b=c=0$; conversely, diagonal matrices commute with this diagonal $A$.
::::
:::

:::problem[Problem 2.4 — Transpose of a product]{difficulty=challenge}
Prove that $(AB)^T = B^T A^T$. (Use the definition of transpose and matrix multiplication.)

::::solution[Solution]
**Answer:** $(AB)^T=B^TA^T$.

1. Let $A$ be $m\times n$ and $B$ be $n\times p$. The $(i,j)$ entry of $(AB)^T$ is the $(j,i)$ entry of $AB$:

2. Compare corresponding indexed entries to establish the matrix identity.

    $$
    ((AB)^T)_{ij} = (AB)_{ji} = \sum_{k=1}^n a_{jk}b_{ki}.
    $$

3. The $(i,j)$ entry of $B^T A^T$: $(B^T)_{ik} = b_{ki}$ and $(A^T)_{kj} = a_{jk}$, so

4. Compare corresponding indexed entries to establish the matrix identity.

    $$
    (B^T A^T)_{ij} = \sum_{k=1}^n (B^T)_{ik}(A^T)_{kj} = \sum_{k=1}^n b_{ki}a_{jk} = \sum_{k=1}^n a_{jk}b_{ki}.
    $$

5. The two are equal for all $i,j$, so $(AB)^T = B^T A^T$. $\square$
::::
:::

:::problem[Problem 2.5 — Matrix equality]{difficulty=easy}
Find $x,y,z$ if

$$
\begin{bmatrix}x&2y\\z-1&4\end{bmatrix}
=\begin{bmatrix}3&-6\\5&4\end{bmatrix}.
$$

::::solution[Solution]
**Answer:** $x=3$, $y=-3$, $z=6$.

1. Combine matching entries only when matrix dimensions agree; apply scalar factors to every entry.

2. Equality requires corresponding entries to agree. Thus $x=3$, $2y=-6$, and $z-1=5$. Therefore

3. Use the displayed equality to perform the next algebraic operation:

    $$
    x=3,\qquad y=-3,\qquad z=6.
    $$

4. Check at least one row and the dimensions against the original matrices.
::::
:::

:::problem[Problem 2.6 — Combined entrywise operations]{difficulty=standard}
For

$$
A=\begin{bmatrix}2&-1\\0&3\end{bmatrix},\qquad
B=\begin{bmatrix}-4&2\\5&1\end{bmatrix},
$$

compute $3A-2B$.

::::solution[Solution]
**Answer:** $3A-2B=\begin{bmatrix}14&-7\\-10&7\end{bmatrix}$.

1. Because $A$ and $B$ have the same dimensions, the subtraction is defined. Compute the two scalar multiples first and only then subtract their corresponding entries.

2. Evaluate each displayed entry using the corresponding definition:

    $$
    3A=\begin{bmatrix}6&-3\\0&9\end{bmatrix},\qquad
    2B=\begin{bmatrix}-8&4\\10&2\end{bmatrix},
    $$

3. so

4. Evaluate each displayed entry using the corresponding definition:

    $$
    3A-2B=\begin{bmatrix}14&-7\\-10&7\end{bmatrix}.
    $$

5. Check the first row directly: $3(2)-2(-4)=6+8=14$ and $3(-1)-2(2)=-3-4=-7$. The second row gives $0-10=-10$ and $9-2=7$.
::::
:::

:::problem[Problem 2.7 — Product dimensions]{difficulty=easy}
Let $A$ be $2\times3$, $B$ be $3\times4$, and $C$ be $2\times2$. Which of $AB$, $BA$, $CA$, and $AC$ are defined, and what are their sizes?

::::solution[Solution]
**Answer:** $AB$ is $2\times4$; $BA$ is undefined; $CA$ is $2\times3$; $AC$ is undefined.

1. A product $(m\times n)(n\times p)$ is defined only when its two inner dimensions agree; the result has $m$ rows and $p$ columns.

2. $AB$ is defined because the inner dimensions are both $3$; its size is $2\times4$.
$BA$ is undefined because the inner dimensions are $4$ and $2$.
$CA$ is defined because the inner dimensions are both $2$; its size is $2\times3$.
$AC$ is undefined because the inner dimensions are $3$ and $2$.

3. Check every requested order: $(2\times3)(3\times4)$ works; $(3\times4)(2\times3)$ fails; $(2\times2)(2\times3)$ works; $(2\times3)(2\times2)$ fails. Thus $CA$ is $2\times3$ and $AC$ is undefined.
::::
:::

:::problem[Problem 2.8 — Product by columns]{difficulty=standard}
Let

$$
A=\begin{bmatrix}1&2\\-1&3\end{bmatrix},\qquad
B=\begin{bmatrix}2&0&-1\\1&4&2\end{bmatrix}.
$$

Compute $AB$ by applying $A$ to each column of $B$.

::::solution[Solution]
**Answer:** $AB=\begin{bmatrix}4&8&3\\1&12&7\end{bmatrix}$.

1. The columns of $B$ are $(2,1)^T$, $(0,4)^T$, and $(-1,2)^T$. Therefore

2. Evaluate each displayed entry using the corresponding definition:

    $$
    A\begin{bmatrix}2\\1\end{bmatrix}=\begin{bmatrix}4\\1\end{bmatrix},\quad
    A\begin{bmatrix}0\\4\end{bmatrix}=\begin{bmatrix}8\\12\end{bmatrix},\quad
    A\begin{bmatrix}-1\\2\end{bmatrix}=\begin{bmatrix}3\\7\end{bmatrix}.
    $$

3. Thus

4. Evaluate each displayed entry using the corresponding definition:

    $$
    AB=\begin{bmatrix}4&8&3\\1&12&7\end{bmatrix}.
    $$

5. Verify the columns separately: $A(2,1)^T=(4,1)^T$, $A(0,4)^T=(8,12)^T$, and $A(-1,2)^T=(3,7)^T$. Their order matches the three columns in the product.
::::
:::

:::problem[Problem 2.9 — Solve for a matrix]{difficulty=standard}
Solve $3X+A=B$ where

$$
A=\begin{bmatrix}1&-2\\4&0\end{bmatrix},\qquad
B=\begin{bmatrix}7&1\\-2&6\end{bmatrix}.
$$

::::solution[Solution]
**Answer:** $X=\begin{bmatrix}2&1\\-2&2\end{bmatrix}$.

1. Isolate the unknown matrix before working with its entries: subtract $A$ on both sides of $3X+A=B$, obtaining $3X=B-A$, then divide every entry by $3$.

2. Subtract $A$ from both sides and multiply by $1/3$:

3. Evaluate each displayed entry using the corresponding definition:

    $$
    X=\frac13(B-A)
    =\frac13\begin{bmatrix}6&3\\-6&6\end{bmatrix}
    =\begin{bmatrix}2&1\\-2&2\end{bmatrix}.
    $$

4. Check the product size before comparing the computed matrix entries.

5. Check by direct substitution: $3X=\begin{bmatrix}6&3\\-6&6\end{bmatrix}$. Adding $A$ gives $\begin{bmatrix}7&1\\-2&6\end{bmatrix}=B$.
::::
:::

:::problem[Problem 2.10 — Transpose of a product]{difficulty=challenge}
Let

$$
A=\begin{bmatrix}1&2\\0&-1\end{bmatrix},\qquad
B=\begin{bmatrix}3&1\\2&4\end{bmatrix}.
$$

Compute $(AB)^T$ and $B^TA^T$ to verify the order-reversal property numerically.

::::solution[Solution]
**Answer:** $(AB)^T=B^TA^T=\begin{bmatrix}7&-2\\9&-4\end{bmatrix}$.

1. First,

2. Evaluate each displayed entry using the corresponding definition:

    $$
    AB=\begin{bmatrix}7&9\\-2&-4\end{bmatrix},
    \qquad
    (AB)^T=\begin{bmatrix}7&-2\\9&-4\end{bmatrix}.
    $$

3. Also,

4. Evaluate each displayed entry using the corresponding definition:

    $$
    B^T=\begin{bmatrix}3&2\\1&4\end{bmatrix},\qquad
    A^T=\begin{bmatrix}1&0\\2&-1\end{bmatrix},
    $$

5. so

6. Evaluate each displayed entry using the corresponding definition:

    $$
    B^TA^T
    =\begin{bmatrix}3&2\\1&4\end{bmatrix}
    \begin{bmatrix}1&0\\2&-1\end{bmatrix}
    =\begin{bmatrix}7&-2\\9&-4\end{bmatrix}
    =(AB)^T.
    $$
::::
:::

## 2.2 The Inverse of a Matrix

:::callout-intuition[Intuition first]
For a scalar $a \neq 0$, the inverse is $a^{-1} = 1/a$, and $a \cdot a^{-1} = 1$.
 For an $n\times n$ matrix $A$, the inverse $A^{-1}$ plays the same role:
 $A A^{-1} = I$. If you know $A^{-1}$, you can solve $A\mathbf{x} = \mathbf{b}$
 instantly for *any* right-hand side $\mathbf{b}$ — just multiply:
 $\mathbf{x} = A^{-1}\mathbf{b}$. But not every matrix has an inverse (just like $0$
 has no reciprocal), and the condition for invertibility is exactly the condition for
 the linear system to have a unique solution.
:::

:::definition[Definition 2.3 — Invertible Matrix]
An $n\times n$ matrix $A$ is **invertible** (or *nonsingular*) if
 there exists an $n\times n$ matrix $C$ such that

$$
AC = I_n \quad\text{and}\quad CA = I_n.
$$

 Such $C$ is unique and is called the **inverse** of $A$, written $A^{-1}$.
 A matrix that is not invertible is called **singular**.
:::

:::theorem[Theorem 2.2 — $2\times2$ Inverse Formula]
If $A = \begin{bmatrix}a&b\\c&d\end{bmatrix}$ and $\det(A) = ad - bc \neq 0$, then

$$
A^{-1} = \frac{1}{ad-bc}\begin{bmatrix}d&-b\\-c&a\end{bmatrix}.
$$

If $ad - bc = 0$, then $A$ is singular (not invertible).
:::

### Computing the inverse by row reduction

For larger matrices, form the augmented matrix $[A \mid I_n]$ and row-reduce.
 If $A$ is invertible, the left block reduces to $I_n$ and the right block becomes $A^{-1}$:

$$
[A \mid I] \xrightarrow{\text{row ops}} [I \mid A^{-1}]
$$

If the left block cannot be reduced to $I$ (a zero row appears), then $A$ is singular.

:::theorem[Theorem 2.3 — Properties of the Inverse]
- $(A^{-1})^{-1} = A$
- $(AB)^{-1} = B^{-1}A^{-1}$ (order reverses — put on socks before shoes; take off shoes before socks)
- $(A^T)^{-1} = (A^{-1})^T$
- If $A$ is invertible, the unique solution of $A\mathbf{x}=\mathbf{b}$ is $\mathbf{x} = A^{-1}\mathbf{b}$.
:::

### Worked examples

<figure class="fig">
<svg class="fig-hue-2" viewBox="0 0 440 240" role="img" aria-label="A shearing transformation followed by its inverse restores the original vector.">
<circle class="fig-point" cx="58" cy="105" r="5"/><circle class="fig-point" cx="218" cy="105" r="5"/><circle class="fig-point" cx="378" cy="105" r="5"/><path class="fig-curve" d="M68 105 L208 105"/><path class="fig-arrow" d="M196 99 L208 105 L196 111"/><path class="fig-curve-alt" d="M228 105 L368 105"/><path class="fig-arrow" d="M356 99 L368 105 L356 111"/><text class="fig-label" x="27" y="85">(1,1)</text><text class="fig-label" x="188" y="85">(2,1)</text><text class="fig-label" x="346" y="85">(1,1)</text><text class="fig-label-em" x="130" y="125">A</text><text class="fig-label-em" x="285" y="125">A⁻¹</text>
</svg>
<figcaption>The shear $A=\begin{bmatrix}1&1\\0&1\end{bmatrix}$ sends $(1,1)^T$ to $(2,1)^T$. Its inverse $A^{-1}=\begin{bmatrix}1&-1\\0&1\end{bmatrix}$ sends the result back to $(1,1)^T$.</figcaption>
</figure>

:::example[Example 2.11 — Inverse of a 2×2 matrix]
Find $A^{-1}$ for $A = \begin{bmatrix}3&1\\5&2\end{bmatrix}$ and use it to solve $A\mathbf{x} = \begin{pmatrix}4\\7\end{pmatrix}$.

::::answer[Answer]
**Answer:** $A^{-1} = \begin{bmatrix}2&-1\\-5&3\end{bmatrix}$, \quad $\mathbf{x} = \begin{pmatrix}1\\1\end{pmatrix}$

1. $\det(A) = (3)(2)-(1)(5) = 6-5 = 1$. Since $\det \neq 0$, $A$ is invertible:

2. Evaluate each displayed entry using the corresponding definition:

    $$
    A^{-1} = \frac{1}{1}\begin{bmatrix}2&-1\\-5&3\end{bmatrix} = \begin{bmatrix}2&-1\\-5&3\end{bmatrix}
    $$

3. Solve $A\mathbf{x} = \mathbf{b}$:

4. Evaluate each displayed entry using the corresponding definition:

    $$
    \mathbf{x} = A^{-1}\mathbf{b} = \begin{bmatrix}2&-1\\-5&3\end{bmatrix}\begin{pmatrix}4\\7\end{pmatrix} = \begin{pmatrix}8-7\\-20+21\end{pmatrix} = \begin{pmatrix}1\\1\end{pmatrix}
    $$

5. Verify: $A\begin{pmatrix}1\\1\end{pmatrix} = \begin{pmatrix}4\\7\end{pmatrix}\,\checkmark$
::::
:::

:::example[Example 2.12 — Inverse of a 3×3 matrix by row reduction]
Find $A^{-1}$ for $A = \begin{bmatrix}1&0&0\\2&1&0\\-1&3&1\end{bmatrix}$.

::::answer[Answer]
**Answer:** $A^{-1} = \begin{bmatrix}1&0&0\\-2&1&0\\7&-3&1\end{bmatrix}$

1. Form $[A \mid I]$ and row-reduce:

2. Perform the next displayed row operation, applying it to every entry on both sides of the augmented matrix.

    $$
    \left[\begin{array}{rrr|rrr}1&0&0&1&0&0\\2&1&0&0&1&0\\-1&3&1&0&0&1\end{array}\right]
          \xrightarrow{R_2-2R_1,\;R_3+R_1}
          \left[\begin{array}{rrr|rrr}1&0&0&1&0&0\\0&1&0&-2&1&0\\0&3&1&1&0&1\end{array}\right]
    $$

3. Perform the next displayed row operation, applying it to every entry on both sides of the augmented matrix.

    $$
    \xrightarrow{R_3-3R_2}
          \left[\begin{array}{rrr|rrr}1&0&0&1&0&0\\0&1&0&-2&1&0\\0&0&1&7&-3&1\end{array}\right]
    $$

4. Left block is $I$, so the right block is $A^{-1}$. Verify: $AA^{-1}$ should be $I$ — check row 3 of $A$ times column 1 of $A^{-1}$: $(-1)(1)+(3)(-2)+(1)(7) = -1-6+7 = 0\,\checkmark$.
::::
:::

:::callout-pitfall[Watch out for]
- **$A^{-1}$ only exists for square matrices.** Non-square matrices are never invertible (in the full sense).
- **The $2\times2$ formula doesn't generalize.** For $3\times3$ and larger, use row reduction on $[A\mid I]$.
- **$(AB)^{-1} = B^{-1}A^{-1}$, not $A^{-1}B^{-1}$.** The order reverses.
- **Do not "divide" matrices.** Write $A^{-1}B$, not $B/A$.
:::

### The lecture route from scalar reciprocals to matrix inverses

For a scalar equation $ax=b$ with $a\neq0$, multiplication by $a^{-1}$ gives

$$
a^{-1}(ax)=a^{-1}b,
\qquad
(a^{-1}a)x=a^{-1}b,
\qquad
x=a^{-1}b.
$$

The matrix equation $AX=B$ motivates the same idea, but order matters and not every square matrix has an inverse.

:::definition[Definition 2.3A — Invertible and Singular]
An $n\times n$ matrix $A$ is **invertible**, or **nonsingular**, if an $n\times n$ matrix $B$ exists such that

$$
AB=BA=I_n.
$$

The matrix $B$ is the multiplicative inverse of $A$. A matrix with no inverse is **noninvertible**, or **singular**. Not every square matrix has an inverse.
:::

:::theorem[Theorem 2.2A — Uniqueness of the Inverse]
If $A$ is invertible, then its inverse is unique.
:::

:::proof[Proof]
Suppose $B$ and $C$ are both inverses of $A$. Then $AB=BA=I$ and $AC=CA=I$. Starting from $AB=I$, multiply on the left by $C$:

$$
C(AB)=CI.
$$

Associativity and the inverse identities give

$$
(CA)B=C,\qquad IB=C,\qquad B=C.
$$

Thus an invertible matrix has only one inverse, denoted $A^{-1}$.
:::

:::example[Example 2.13 — Verify an inverse on both sides]
Compute both $AB$ and $BA$ to determine whether $B=A^{-1}$:

$$
A=\begin{bmatrix}-1&2\\-1&1\end{bmatrix},\qquad
    B=\begin{bmatrix}1&-2\\1&-1\end{bmatrix}.
$$

::::answer[Answer]
**Answer:** $AB=BA=\begin{bmatrix}1&0\\0&1\end{bmatrix}=I_2$; therefore $B=A^{-1}$.

1. Let

2. Evaluate each displayed entry using the corresponding definition:

    $$
    A=\begin{bmatrix}-1&2\\-1&1\end{bmatrix},\qquad
    B=\begin{bmatrix}1&-2\\1&-1\end{bmatrix}.
    $$

3. Then

4. Evaluate each displayed entry using the corresponding definition:

    $$
    AB=\begin{bmatrix}1&0\\0&1\end{bmatrix}
    \qquad\text{and}\qquad
    BA=\begin{bmatrix}1&0\\0&1\end{bmatrix}.
    $$

5. Because both products are the identity, $B=A^{-1}$.
::::
:::

:::theorem[Lecture theorem — The $2\times2$ inverse formula]
For

$$
A=\begin{bmatrix}a&b\\c&d\end{bmatrix},
$$

the number

$$
\det A=ad-bc
$$

is the **determinant** of $A$. If $ad-bc\neq0$, then $A$ is invertible and

$$
A^{-1}=\frac{1}{ad-bc}\begin{bmatrix}d&-b\\-c&a\end{bmatrix}.
$$
:::

:::example[Example 2.14 — The $2\times2$ formula]
Find the inverse of

$$
A=\begin{bmatrix}1&2\\-2&-1\end{bmatrix}.
$$

::::answer[Answer]
**Answer:** $A^{-1}=\begin{bmatrix}-\tfrac13&-\tfrac23\\\tfrac23&\tfrac13\end{bmatrix}$

1. $A^{-1}=\begin{bmatrix}-\tfrac13&-\tfrac23\\\tfrac23&\tfrac13\end{bmatrix}$.
The determinant is

2. Calculate the next cofactor or determinant term with its indicated sign:

    $$
    \det A=ad-bc=1(-1)-2(-2)=3\neq0.
    $$

3. Therefore

4. Evaluate each displayed entry using the corresponding definition:

    $$
    A^{-1}=\frac13\begin{bmatrix}-1&-2\\2&1\end{bmatrix}
    =\begin{bmatrix}-\tfrac13&-\tfrac23\\\tfrac23&\tfrac13\end{bmatrix}.
    $$
::::
:::

### Why Gauss–Jordan inversion works

To find the inverse of the same matrix without the formula, write an unknown matrix

$$
X=\begin{bmatrix}x_{11}&x_{12}\\x_{21}&x_{22}\end{bmatrix}
$$

and solve $AX=I$. Matrix multiplication separates this into one linear system for each column of $X$:

$$
\begin{array}{ll}
x_{11}+2x_{21}=1,&x_{12}+2x_{22}=0,\\
-2x_{11}-x_{21}=0,&-2x_{12}-x_{22}=1.
\end{array}
$$

The coefficient matrix is the same in both systems, so solve them simultaneously by adjoining both right-hand sides:

$$
\begin{bmatrix}1&2&\vline&1&0\\-2&-1&\vline&0&1\end{bmatrix}
\sim
\begin{bmatrix}1&0&\vline&-\tfrac13&-\tfrac23\\0&1&\vline&\tfrac23&\tfrac13\end{bmatrix}.
$$

The right block is the matrix whose columns solve the two systems, so it is $A^{-1}$. The inverse's $(2,2)$ entry is $1/3$; the lecture notes give $2/3$ in the final boxed matrix, although their row reduction and the $2\times2$ formula both give the value $1/3$.

:::callout-key[The three-step Gauss–Jordan procedure]
1. Form $[A\mid I]$ by adjoining the identity matrix to $A$.
2. Use elementary row operations. If $[A\mid I]\to[I\mid B]$, then $A^{-1}=B$. If the left block cannot become $I$, then $A^{-1}$ does not exist; failure appears as a missing pivot and a zero row on the left.
3. Check the result by verifying $AA^{-1}=I=A^{-1}A$.
:::

:::example[Example 2.15 — A $3\times3$ matrix that inverts]
Find the inverse of this matrix by Gauss–Jordan elimination:

$$
A=\begin{bmatrix}1&0&-1\\1&-1&0\\-6&2&3\end{bmatrix}.
$$

::::answer[Answer]
**Answer:** $A^{-1}=\begin{bmatrix}-3&-2&-1\\-3&-3&-1\\-4&-2&-1\end{bmatrix}$.

1. Let

2. Evaluate each displayed entry using the corresponding definition:

    $$
    A=\begin{bmatrix}1&0&-1\\1&-1&0\\-6&2&3\end{bmatrix}.
    $$

3. Row reduction gives

4. Perform the next displayed row operation, applying it to every entry on both sides of the augmented matrix.

    $$
    \left[\begin{array}{rrr|rrr}
    1&0&-1&1&0&0\\
    1&-1&0&0&1&0\\
    -6&2&3&0&0&1
    \end{array}\right]
    \sim
    \left[\begin{array}{rrr|rrr}
    1&0&0&-3&-2&-1\\
    0&1&0&-3&-3&-1\\
    0&0&1&-4&-2&-1
    \end{array}\right].
    $$

5. Hence

6. Evaluate each displayed entry using the corresponding definition:

    $$
    A^{-1}=\begin{bmatrix}-3&-2&-1\\-3&-3&-1\\-4&-2&-1\end{bmatrix}.
    $$
::::
:::

:::example[Example 2.16 — A $3\times3$ matrix that does not invert]
Use row reduction to determine whether this matrix is invertible:

$$
A=\begin{bmatrix}1&2&0\\3&-1&2\\-2&3&-2\end{bmatrix}.
$$

::::answer[Answer]
**Answer:** $A$ is singular; $A^{-1}$ does not exist.

1. Let

2. Evaluate each displayed entry using the corresponding definition:

    $$
    A=\begin{bmatrix}1&2&0\\3&-1&2\\-2&3&-2\end{bmatrix}.
    $$

3. The augmented matrix reduces to a form containing

4. Perform the next displayed row operation, applying it to every entry on both sides of the augmented matrix.

    $$
    \left[\begin{array}{rrr|rrr}
    1&2&0&1&0&0\\
    0&-7&2&-3&1&0\\
    0&0&0&-1&1&1
    \end{array}\right].
    $$

5. The left block has a zero row and cannot become $I_3$. Thus $A^{-1}$ does not exist; $A$ is singular.
::::
:::

### Four inverse properties

:::theorem[Theorem 2.3A — Inverses of Inverses, Powers, Scalars, and Transposes]
If $A$ is invertible, $k$ is a positive integer, and $c\neq0$ is a scalar, then

1. $(A^{-1})^{-1}=A$.
2. $(A^k)^{-1}=(A^{-1})^k$.
3. $(cA)^{-1}=\dfrac1cA^{-1}$.
4. $(A^T)^{-1}=(A^{-1})^T$.
:::

:::proof[Proof]
For property 1, $(A^{-1})A=A(A^{-1})=I$, so $A$ is the inverse of $A^{-1}$.

For property 2, associate the product so that adjacent factors cancel:

$$
A^k(A^{-1})^k
=\underbrace{A\cdots A}_{k}
\underbrace{A^{-1}\cdots A^{-1}}_{k}
=I.
$$

The reverse product also equals $I$, so $(A^{-1})^k$ is the inverse of $A^k$.

For property 3,

$$
(cA)\left(\frac1cA^{-1}\right)
=AA^{-1}=I,
$$

and the reverse product is also $I$.

For property 4, use the transpose product rule:

$$
A^T(A^{-1})^T=(A^{-1}A)^T=I^T=I,
$$

and similarly $(A^{-1})^TA^T=(AA^{-1})^T=I$.
:::

:::theorem[Theorem 2.3B — Inverse of a Product]
If $A$ and $B$ are invertible, then

$$
(AB)^{-1}=B^{-1}A^{-1}.
$$
:::

:::proof[Proof]
The proposed inverse works on both sides:

$$
(AB)(B^{-1}A^{-1})
=A(BB^{-1})A^{-1}
=AIA^{-1}=I,
$$

and

$$
(B^{-1}A^{-1})(AB)
=B^{-1}(A^{-1}A)B
=B^{-1}IB=I.
$$

Therefore $(AB)^{-1}=B^{-1}A^{-1}$.
:::

For more factors, the entire order reverses:

$$
(A_1A_2\cdots A_p)^{-1}
=A_p^{-1}A_{p-1}^{-1}\cdots A_2^{-1}A_1^{-1}.
$$

:::example[Example 2.17 — Inverse of a product]
Find $A^{-1}$, $B^{-1}$, and $(AB)^{-1}$, and verify the inverse-product rule:

$$
A=\begin{bmatrix}1&3&3\\1&4&3\\1&3&4\end{bmatrix},\qquad
    B=\begin{bmatrix}1&2&3\\1&3&3\\2&4&3\end{bmatrix}.
$$

::::answer[Answer]
**Answer:** $A^{-1}=\begin{bmatrix}7&-3&-3\\-1&1&0\\-1&0&1\end{bmatrix}$, $B^{-1}=\begin{bmatrix}1&-2&1\\-1&1&0\\\tfrac23&0&-\tfrac13\end{bmatrix}$, $(AB)^{-1}=\begin{bmatrix}8&-5&-2\\-8&4&3\\5&-2&-\tfrac73\end{bmatrix}$.

1. Let

2. Evaluate each displayed entry using the corresponding definition:

    $$
    A=\begin{bmatrix}1&3&3\\1&4&3\\1&3&4\end{bmatrix},\qquad
    B=\begin{bmatrix}1&2&3\\1&3&3\\2&4&3\end{bmatrix}.
    $$

3. The individual inverses are

4. Evaluate each displayed entry using the corresponding definition:

    $$
    A^{-1}=\begin{bmatrix}7&-3&-3\\-1&1&0\\-1&0&1\end{bmatrix},\qquad
    B^{-1}=\begin{bmatrix}1&-2&1\\-1&1&0\\\tfrac23&0&-\tfrac13\end{bmatrix}.
    $$

5. Method 1 applies the product rule:

6. Evaluate each displayed entry using the corresponding definition:

    $$
    (AB)^{-1}=B^{-1}A^{-1}
    =\begin{bmatrix}8&-5&-2\\-8&4&3\\5&-2&-\tfrac73\end{bmatrix}.
    $$

7. Method 2 first forms $AB$ and then row-reduces $[AB\mid I]$; it produces the same inverse. The first method is shorter because the individual inverses are already known.
::::
:::

### Cancellation with an invertible factor

:::theorem[Theorem 2.3C — Cancellation Property]
If $C^{-1}$ exists, then

1. $AC=BC$ implies $A=B$.
2. $CA=CB$ implies $A=B$.
:::

:::proof[Proof]
For the first statement, multiply on the right by $C^{-1}$:

$$
AC=BC
\Longrightarrow
(AC)C^{-1}=(BC)C^{-1}
\Longrightarrow
A(CC^{-1})=B(CC^{-1})
\Longrightarrow A=B.
$$

For the second statement, multiply on the left by $C^{-1}$:

$$
CA=CB
\Longrightarrow
C^{-1}(CA)=C^{-1}(CB)
\Longrightarrow
(C^{-1}C)A=(C^{-1}C)B
\Longrightarrow A=B.
$$
:::

For example, $C=\begin{bmatrix}1&2\\3&4\end{bmatrix}$ is invertible because its determinant is $-2\neq0$. Therefore

$$
A_{2\times2}C=B_{2\times2}C
$$

does imply $A=B$.

### Square systems solved by an inverse

:::theorem[Theorem 2.3D — Unique Solution of an Invertible Square System]
If $A$ is an invertible $n\times n$ matrix, then $A\mathbf{x}=\mathbf{b}$ has the unique solution

$$
\mathbf{x}=A^{-1}\mathbf{b}.
$$
:::

:::proof[Proof]
Existence follows by multiplying the equation on the left by $A^{-1}$:

$$
A\mathbf{x}=\mathbf{b}
\Longrightarrow
A^{-1}A\mathbf{x}=A^{-1}\mathbf{b}
\Longrightarrow
\mathbf{x}=A^{-1}\mathbf{b}.
$$

For uniqueness, suppose $A\mathbf{x}_1=\mathbf{b}$ and $A\mathbf{x}_2=\mathbf{b}$. Then

$$
A\mathbf{x}_1=A\mathbf{x}_2.
$$

Multiplying on the left by $A^{-1}$ gives

$$
(A^{-1}A)\mathbf{x}_1=(A^{-1}A)\mathbf{x}_2,
$$

so $\mathbf{x}_1=\mathbf{x}_2$. Thus $A^{-1}\mathbf{b}$ is the only solution.
:::

:::example[Example 2.18 — A system and its homogeneous partner]
Use the supplied inverse to solve a nonhomogeneous system, then characterize its homogeneous partner:

$$
A=\begin{bmatrix}2&3&1\\3&3&1\\2&4&1\end{bmatrix},
    \qquad
    A^{-1}=\begin{bmatrix}-1&1&0\\-1&0&1\\6&-2&-3\end{bmatrix}.
$$

::::answer[Answer]
**Answer:** $\mathbf{x}=\begin{bmatrix}2\\-1\\-2\end{bmatrix}$; the homogeneous system has only $\mathbf{x}=0$.

1. Combine matching entries only when matrix dimensions agree; apply scalar factors to every entry.

2. Consider

3. Evaluate each displayed entry using the corresponding definition:

    $$
    A=\begin{bmatrix}2&3&1\\3&3&1\\2&4&1\end{bmatrix},
    \qquad
    A^{-1}=\begin{bmatrix}-1&1&0\\-1&0&1\\6&-2&-3\end{bmatrix}.
    $$

4. For the system

5. Use the displayed equality to perform the next algebraic operation:

    $$
    \begin{cases}
    2x+3y+z=-1,\\
    3x+3y+z=1,\\
    2x+4y+z=-2,
    \end{cases}
    $$

6. we have

7. Evaluate each displayed entry using the corresponding definition:

    $$
    \begin{bmatrix}x\\y\\z\end{bmatrix}
    =A^{-1}\begin{bmatrix}-1\\1\\-2\end{bmatrix}
    =\begin{bmatrix}2\\-1\\-2\end{bmatrix}.
    $$

8. For the homogeneous system with the same coefficient matrix,

9. Use the displayed equality to perform the next algebraic operation:

    $$
    A\mathbf{x}=\mathbf{0},
    $$

10. the inverse formula gives

11. Use the displayed equality to perform the next algebraic operation:

    $$
    \mathbf{x}=A^{-1}\mathbf{0}=\mathbf{0}.
    $$

12. Thus an invertible square coefficient matrix makes every system have exactly one solution, and its homogeneous system has only the trivial solution.

13. Check at least one row and the dimensions against the original matrices.
::::
:::

### Elementary matrices

The Gauss–Jordan method says to row-reduce $[A\mid I]$ and read $A^{-1}$ off the right block. That is not a trick; it is a statement about matrix multiplication, and elementary matrices are the tool that makes it visible. The idea is that **each row operation is itself a matrix multiplication.**

:::callout-intuition[Intuition first]
Doing a row operation to $A$ is the same as multiplying $A$ on the *left* by a particular matrix. You find that matrix by doing the same row operation to the identity matrix. So a whole row reduction is just a product of such matrices, and "$A$ row reduces to $I$" becomes the equation (matrix)(matrix)$\cdots A = I$, which says the product of those matrices is $A^{-1}$.
:::

:::definition[Definition 2.3B — Elementary Matrix]
An **elementary matrix** is a matrix obtained by performing **one** elementary row operation on the identity matrix $I_n$. There are three types, matching the three row operations:

| Row operation | What it does | Elementary matrix $E$ (3×3 example) | Inverse operation, so $E^{-1}$ is |
| --- | --- | --- | --- |
| Replacement: $R_i \to R_i + cR_j$ | add $c$ times row $j$ to row $i$ | $R_2\to R_2-3R_1$ gives $\begin{bmatrix}1&0&0\\-3&1&0\\0&0&1\end{bmatrix}$ | $R_i \to R_i - cR_j$, here $\begin{bmatrix}1&0&0\\3&1&0\\0&0&1\end{bmatrix}$ |
| Interchange: $R_i \leftrightarrow R_j$ | swap two rows | $R_1\leftrightarrow R_3$ gives $\begin{bmatrix}0&0&1\\0&1&0\\1&0&0\end{bmatrix}$ | the same swap, so $E^{-1}=E$ |
| Scaling: $R_i \to cR_i$ ($c\ne0$) | multiply a row by a nonzero $c$ | $R_2\to5R_2$ gives $\begin{bmatrix}1&0&0\\0&5&0\\0&0&1\end{bmatrix}$ | $R_i \to \tfrac1c R_i$, here $\begin{bmatrix}1&0&0\\0&\tfrac15&0\\0&0&1\end{bmatrix}$ |
:::

:::theorem[Theorem 2.3E — $EA$ performs the row operation]
If an elementary row operation is performed on an $m\times n$ matrix $A$, the result is $EA$, where $E$ is the $m\times m$ elementary matrix made by performing that same operation on $I_m$.
:::

Two things to watch. First, $E$ goes on the **left** of $A$ (left multiplication acts on rows; right multiplication would act on columns). Second, the size of $E$ is the number of **rows** of $A$, so that $EA$ is defined.

:::theorem[Theorem 2.3F — Every elementary matrix is invertible]
Every elementary matrix $E$ is invertible, and $E^{-1}$ is the elementary matrix that performs the *reverse* row operation (see the last column of the table). Undoing "add $-3R_1$ to $R_2$" is "add $+3R_1$ to $R_2$"; undoing a swap is the same swap; undoing "multiply by 5" is "multiply by $\tfrac15$." This is why scaling requires $c\neq0$: scaling by $0$ cannot be undone.
:::

:::example[Example 2.19 — Build $E$, apply it, and invert it]
Let $A=\begin{bmatrix}1&2&0\\3&1&4\\0&5&2\end{bmatrix}$. (a) Write the elementary matrix $E$ that performs $R_2\to R_2-3R_1$. (b) Verify that $EA$ really performs that operation. (c) Write $E^{-1}$ and check $E^{-1}E=I$.

::::answer[Answer]
**Answer:** $E=\begin{bmatrix}1&0&0\\-3&1&0\\0&0&1\end{bmatrix}$, $\;E^{-1}=\begin{bmatrix}1&0&0\\3&1&0\\0&0&1\end{bmatrix}$

1. $E=\begin{bmatrix}1&0&0\\-3&1&0\\0&0&1\end{bmatrix}$, $\;E^{-1}=\begin{bmatrix}1&0&0\\3&1&0\\0&0&1\end{bmatrix}$.
(a) Perform the operation on $I_3$: row 2 of $I_3$ is $(0,1,0)$; subtracting $3\cdot(1,0,0)$ gives $(-3,1,0)$. Rows 1 and 3 are unchanged.

2. (b)

3. Evaluate each displayed entry using the corresponding definition:

    $$
    EA=\begin{bmatrix}1&0&0\\-3&1&0\\0&0&1\end{bmatrix}\begin{bmatrix}1&2&0\\3&1&4\\0&5&2\end{bmatrix}
    =\begin{bmatrix}1&2&0\\0&-5&4\\0&5&2\end{bmatrix}.
    $$

4. Row 2 is now $(3,1,4)-3(1,2,0)=(0,-5,4)$, and rows 1 and 3 did not change.

5. (c) The reverse operation is $R_2\to R_2+3R_1$, so $E^{-1}$ has $+3$ in the $(2,1)$ position. Then

6. Evaluate each displayed entry using the corresponding definition:

    $$
    E^{-1}E=\begin{bmatrix}1&0&0\\3&1&0\\0&0&1\end{bmatrix}\begin{bmatrix}1&0&0\\-3&1&0\\0&0&1\end{bmatrix}=\begin{bmatrix}1&0&0\\0&1&0\\0&0&1\end{bmatrix}.
    $$
::::
:::

:::example[Example 2.20 — A swap and a scaling]
With the same $A$, find the elementary matrices for (a) $R_1\leftrightarrow R_3$ and (b) $R_2\to5R_2$, apply each to $A$, and state each inverse.

::::answer[Answer]
**Answer:** (a) $P=\begin{bmatrix}0&0&1\\0&1&0\\1&0&0\end{bmatrix}$ and $P^{-1}=P$. (b) $S=\begin{bmatrix}1&0&0\\0&5&0\\0&0&1\end{bmatrix}$ and $S^{-1}=\begin{bmatrix}1&0&0\\0&\tfrac15&0\\0&0&1\end{bmatrix}$.

1. Combine matching entries only when matrix dimensions agree; apply scalar factors to every entry.

2. (a) $PA=\begin{bmatrix}0&5&2\\3&1&4\\1&2&0\end{bmatrix}$: rows 1 and 3 of $A$ have traded places. Swapping again restores $A$, so $P^2=I$ and $P^{-1}=P$.

3. (b) $SA=\begin{bmatrix}1&2&0\\15&5&20\\0&5&2\end{bmatrix}$: only row 2 changed, multiplied by 5. Multiplying by $\tfrac15$ undoes it, so $S^{-1}$ has $\tfrac15$ in the $(2,2)$ position.

4. Check at least one row and the dimensions against the original matrices.
::::
:::

Now put the pieces together. Suppose a sequence of row operations carries $A$ to $I$, using elementary matrices $E_1,E_2,\dots,E_p$ in that order. Each step multiplies on the left, so

$$
E_p\cdots E_2E_1A=I.
$$

The product $E_p\cdots E_1$ is therefore a matrix that multiplies $A$ to give $I$, which makes it $A^{-1}$. Conversely, since each $E_k$ is invertible, solving for $A$ gives $A=E_1^{-1}E_2^{-1}\cdots E_p^{-1}$: **an invertible matrix is a product of elementary matrices.**

:::theorem[Theorem 2.3G — Invertible $\iff$ row equivalent to $I$]
An $n\times n$ matrix $A$ is invertible if and only if $A$ is row equivalent to $I_n$. In that case, any sequence of row operations that reduces $A$ to $I_n$ also transforms $I_n$ into $A^{-1}$.
:::

This is exactly why the algorithm $[A\mid I]\to[I\mid A^{-1}]$ works. The row operations that turn the left block $A$ into $I$ are $E_1,\dots,E_p$. Applying them to the right block, which starts as $I$, produces $E_p\cdots E_1I=E_p\cdots E_1=A^{-1}$. If $A$ cannot be reduced to $I$ (a zero row appears on the left), the theorem says $A$ is not invertible.

:::example[Example 2.21 — $A^{-1}$ and $A$ as products of elementary matrices]
Reduce $A=\begin{bmatrix}1&2\\3&7\end{bmatrix}$ to $I$ with elementary matrices, then write $A^{-1}$ and $A$ as products.

::::answer[Answer]
**Answer:** $A^{-1}=E_2E_1=\begin{bmatrix}7&-2\\-3&1\end{bmatrix}$ and $A=E_1^{-1}E_2^{-1}=\begin{bmatrix}1&0\\3&1\end{bmatrix}\begin{bmatrix}1&2\\0&1\end{bmatrix}$

1. The $(i,j)$ entry of a product is row $i$ dotted with column $j$; the inner dimensions must match.

2. $A^{-1}=E_2E_1=\begin{bmatrix}7&-2\\-3&1\end{bmatrix}$ and $A=E_1^{-1}E_2^{-1}=\begin{bmatrix}1&0\\3&1\end{bmatrix}\begin{bmatrix}1&2\\0&1\end{bmatrix}$.
Step 1: $R_2\to R_2-3R_1$ turns $A$ into $\begin{bmatrix}1&2\\0&1\end{bmatrix}$. Here $E_1=\begin{bmatrix}1&0\\-3&1\end{bmatrix}$.

3. Step 2: $R_1\to R_1-2R_2$ turns that into $I$. Here $E_2=\begin{bmatrix}1&-2\\0&1\end{bmatrix}$.

4. So $E_2E_1A=I$, hence

5. Evaluate each displayed entry using the corresponding definition:

    $$
    A^{-1}=E_2E_1=\begin{bmatrix}1&-2\\0&1\end{bmatrix}\begin{bmatrix}1&0\\-3&1\end{bmatrix}=\begin{bmatrix}7&-2\\-3&1\end{bmatrix}.
    $$

6. Check: $A\,A^{-1}=\begin{bmatrix}1&2\\3&7\end{bmatrix}\begin{bmatrix}7&-2\\-3&1\end{bmatrix}=\begin{bmatrix}1&0\\0&1\end{bmatrix}$. Inverting the product (order reverses) gives $A=E_1^{-1}E_2^{-1}=\begin{bmatrix}1&0\\3&1\end{bmatrix}\begin{bmatrix}1&2\\0&1\end{bmatrix}=\begin{bmatrix}1&2\\3&7\end{bmatrix}$, as it should.
::::
:::

:::problem[Problem 2.11 — Build elementary matrices]{difficulty=easy}
Write the $3\times3$ elementary matrix that performs each operation, and its inverse: (a) $R_3\to R_3+4R_1$; (b) $R_2\leftrightarrow R_3$; (c) $R_1\to-2R_1$.

::::solution[Solution]
**Answer:** (a) $E=\begin{bmatrix}1&0&0\\0&1&0\\4&0&1\end{bmatrix}$, $E^{-1}=\begin{bmatrix}1&0&0\\0&1&0\\-4&0&1\end{bmatrix}$; (b) $E=E^{-1}=\begin{bmatrix}1&0&0\\0&0&1\\0&1&0\end{bmatrix}$; (c) $E=\begin{bmatrix}-2&0&0\\0&1&0\\0&0&1\end{bmatrix}$, $E^{-1}=\begin{bmatrix}-\tfrac12&0&0\\0&1&0\\0&0&1\end{bmatrix}$.

1. An elementary matrix is created by performing the stated row operation on $I_3$. Each inverse performs the operation backward: add becomes subtract, a swap undoes itself, and scaling by $-2$ is undone by scaling by $-1/2$.

2. (a) $E=\begin{bmatrix}1&0&0\\0&1&0\\4&0&1\end{bmatrix}$, $E^{-1}=\begin{bmatrix}1&0&0\\0&1&0\\-4&0&1\end{bmatrix}$.

3. (b) $E=\begin{bmatrix}1&0&0\\0&0&1\\0&1&0\end{bmatrix}$, and $E^{-1}=E$.

4. (c) $E=\begin{bmatrix}-2&0&0\\0&1&0\\0&0&1\end{bmatrix}$, $E^{-1}=\begin{bmatrix}-\tfrac12&0&0\\0&1&0\\0&0&1\end{bmatrix}$.

5. For (a), the entry $4$ appears at position $(3,1)$. For (b), exchange rows 2 and 3 of $I_3$. For (c), replace the first diagonal $1$ by $-2$; the inverse has $-1/2$ there.
::::
:::

:::problem[Problem 2.12 — Invert using elementary matrices]{difficulty=standard}
Reduce $A=\begin{bmatrix}1&3\\2&7\end{bmatrix}$ to $I$ using two replacement operations. Write each elementary matrix, then express $A^{-1}$ and $A$ as products of them.

::::solution[Solution]
**Answer:** $A^{-1}=E_2E_1=\begin{bmatrix}7&-3\\-2&1\end{bmatrix}$; $A=E_1^{-1}E_2^{-1}$.

1. Left multiplication by the first elementary matrix eliminates the $2$ below the pivot $1$; the second elementary matrix eliminates the $3$ above the next pivot.

2. $R_2\to R_2-2R_1$ gives $\begin{bmatrix}1&3\\0&1\end{bmatrix}$, with $E_1=\begin{bmatrix}1&0\\-2&1\end{bmatrix}$. Then $R_1\to R_1-3R_2$ gives $I$, with $E_2=\begin{bmatrix}1&-3\\0&1\end{bmatrix}$.

3. $A^{-1}=E_2E_1=\begin{bmatrix}7&-3\\-2&1\end{bmatrix}$. Check: $AA^{-1}=\begin{bmatrix}1&3\\2&7\end{bmatrix}\begin{bmatrix}7&-3\\-2&1\end{bmatrix}=I$.

4. $A=E_1^{-1}E_2^{-1}=\begin{bmatrix}1&0\\2&1\end{bmatrix}\begin{bmatrix}1&3\\0&1\end{bmatrix}=\begin{bmatrix}1&3\\2&7\end{bmatrix}$.

5. The equation $E_2E_1A=I$ gives $A^{-1}=E_2E_1$. Reverse the operations and their order to recover $A=E_1^{-1}E_2^{-1}$. Multiplying $AA^{-1}$ checks both matrix entries and ordering.
::::
:::

:::problem[Problem 2.13 — Elementary matrix facts]{difficulty=easy}
True or false, with a reason. (a) Every elementary matrix is invertible. (b) The product of two elementary matrices is an elementary matrix. (c) $\begin{bmatrix}1&0\\0&0\end{bmatrix}$ is an elementary matrix. (d) If $EA=B$ with $E$ elementary, then $A$ can be recovered from $B$.

::::solution[Solution]
**Answer:** (a) True: undo the row operation (Theorem 2.3F).

1. (a) True: undo the row operation (Theorem 2.3F).

2. (b) False in general. $E_2E_1=\begin{bmatrix}7&-2\\-3&1\end{bmatrix}$ from Example 2.4C differs from $I$ by two row operations, not one, so it is not elementary.

3. (c) False. It would come from $R_2\to0\cdot R_2$, and scaling by $0$ is not allowed. The matrix is singular, whereas every elementary matrix is invertible.

4. (d) True: $A=E^{-1}B$.
::::
:::

### Practice problems

:::problem[Problem 2.14 — Invert a two-by-two matrix]{difficulty=easy}
Use the formula to find the inverse of $A = \begin{bmatrix}4&7\\2&6\end{bmatrix}$, or state that it is singular.

::::solution[Solution]
**Answer:** $A^{-1}=\frac{1}{10}\begin{bmatrix}6&-7\\-2&4\end{bmatrix}$.

1. For a $2\times2$ matrix $\begin{bmatrix}a&b\\c&d\end{bmatrix}$, compute $ad-bc$ first. The inverse exists only if this determinant is nonzero.

2. $\det(A) = 24 - 14 = 10 \neq 0$, so invertible.

3. Evaluate each displayed entry using the corresponding definition:

    $$
    A^{-1} = \frac{1}{10}\begin{bmatrix}6&-7\\-2&4\end{bmatrix} = \begin{bmatrix}0.6&-0.7\\-0.2&0.4\end{bmatrix}
    $$

4. Here $4(6)-7(2)=24-14=10$. Swap the diagonal entries, negate the off-diagonal entries, and divide by $10$. Check that the diagonal entries of $AA^{-1}$ become $(24-14)/10=1$.
::::
:::

:::problem[Problem 2.15 — Three-by-three Gauss–Jordan inverse]{difficulty=standard}
Find $A^{-1}$ using row reduction: $A = \begin{bmatrix}2&1&0\\1&2&1\\0&1&2\end{bmatrix}$.

::::solution[Solution]
**Answer:** $A^{-1}=\frac14\begin{bmatrix}3&-2&1\\-2&4&-2\\1&-2&3\end{bmatrix}$.

1. Form $[A\mid I_3]$, because the same row operations that make $A$ into $I_3$ transform the right side into $A^{-1}$:

    $$
    \left[\begin{array}{rrr|rrr}2&1&0&1&0&0\\1&2&1&0&1&0\\0&1&2&0&0&1\end{array}\right].
    $$

2. Swap $R_1\leftrightarrow R_2$ to place a $1$ in the first pivot position. Then eliminate $R_2\leftarrow R_2-2R_1$, subtracting $2(1,2,1\mid0,1,0)$ from $(2,1,0\mid1,0,0)$:

    $$
    \rightarrow\left[\begin{array}{rrr|rrr}1&2&1&0&1&0\\0&-3&-2&1&-2&0\\0&1&2&0&0&1\end{array}\right].
    $$

3. Swap $R_2\leftrightarrow R_3$ to get a unit pivot in column two. Clear the $-3$ below it by $R_3\leftarrow R_3+3R_2$: the third row becomes $(0,0,4\mid1,-2,3)$.

    $$
    \rightarrow\left[\begin{array}{rrr|rrr}1&2&1&0&1&0\\0&1&2&0&0&1\\0&0&4&1&-2&3\end{array}\right].
    $$

4. Divide $R_3$ by $4$, producing $(0,0,1\mid\tfrac14,-\tfrac12,\tfrac34)$. Clear the $2$ in row two with $R_2\leftarrow R_2-2R_3$, giving $(0,1,0\mid-\tfrac12,1,-\tfrac12)$.

5. Clear column three in row one with $R_1\leftarrow R_1-R_3$. The first row becomes $(1,2,0\mid-\tfrac14,\tfrac32,-\tfrac34)$. Next clear column two with $R_1\leftarrow R_1-2R_2$, giving $(1,0,0\mid\tfrac34,-\tfrac12,\tfrac14)$.

6. The left half is now $I_3$. Read the right half as $A^{-1}=\frac{1}{4}\begin{bmatrix}3&-2&1\\-2&4&-2\\1&-2&3\end{bmatrix}$. Check the first row of $AA^{-1}$: $(2,1,0)$ dotted with the three inverse columns gives $(\frac{6-2}{4},\frac{-4+4}{4},\frac{2-2}{4})=(1,0,0)$.
::::
:::

:::problem[Problem 2.16 — Inverse of a product]{difficulty=challenge}
Suppose $A$ and $B$ are invertible $n\times n$ matrices. Show that $AB$ is invertible and find its inverse.

::::solution[Solution]
**Answer:** $(AB)^{-1}=B^{-1}A^{-1}$.

1. We claim $(AB)^{-1} = B^{-1}A^{-1}$. Verify both products equal $I$:

2. $(AB)(B^{-1}A^{-1}) = A(BB^{-1})A^{-1} = A I A^{-1} = AA^{-1} = I$.

3. $(B^{-1}A^{-1})(AB) = B^{-1}(A^{-1}A)B = B^{-1}IB = B^{-1}B = I$.

4. Both products equal $I$, so $AB$ is invertible with $(AB)^{-1} = B^{-1}A^{-1}$. $\square$
::::
:::

:::problem[Problem 2.17 — Verify an inverse]{difficulty=easy}
Show that

$$
B=\begin{bmatrix}2&-1\\-1&1\end{bmatrix}
$$

is the inverse of $A=\begin{bmatrix}1&1\\1&2\end{bmatrix}$.

::::solution[Solution]
**Answer:** $AB=BA=\begin{bmatrix}1&0\\0&1\end{bmatrix}=I_2$.

1. Compute both products:

2. Evaluate each displayed entry using the corresponding definition:

    $$
    AB=\begin{bmatrix}1&1\\1&2\end{bmatrix}
    \begin{bmatrix}2&-1\\-1&1\end{bmatrix}
    =\begin{bmatrix}1&0\\0&1\end{bmatrix},
    $$

3. and

4. Evaluate each displayed entry using the corresponding definition:

    $$
    BA=\begin{bmatrix}2&-1\\-1&1\end{bmatrix}
    \begin{bmatrix}1&1\\1&2\end{bmatrix}
    =\begin{bmatrix}1&0\\0&1\end{bmatrix}.
    $$

5. Therefore $B=A^{-1}$.

6. Check the off-diagonal entries explicitly: in $AB$, $1(-1)+1(1)=0$ and $1(2)+2(-1)=0$. In $BA$, $2(1)+(-1)(2)=0$ and $-1(1)+1(1)=0$, confirming both products have zero off-diagonal entries.
::::
:::

:::problem[Problem 2.18 — Use the $2\times2$ formula]{difficulty=easy}
Find the inverse of $A=\begin{bmatrix}2&5\\1&3\end{bmatrix}$.

::::solution[Solution]
**Answer:** $A^{-1}=\begin{bmatrix}3&-5\\-1&2\end{bmatrix}$.

1. Start with $\det A=ad-bc$: $2(3)-5(1)=6-5=1\ne0$. Hence the two-by-two inverse formula is permitted.

2. The determinant is $2(3)-5(1)=1$, so

3. Evaluate each displayed entry using the corresponding definition:

    $$
    A^{-1}=\begin{bmatrix}3&-5\\-1&2\end{bmatrix}.
    $$

4. Form the adjugate by swapping $2$ and $3$ and changing $5,1$ to $-5,-1$. Dividing by determinant $1$ leaves the displayed matrix. Multiplication recovers $I_2$.
::::
:::

:::problem[Problem 2.19 — Detect a singular matrix]{difficulty=standard}
Use row reduction or the determinant formula to decide whether
$A=\begin{bmatrix}4&6\\2&3\end{bmatrix}$ is invertible.

::::solution[Solution]
**Answer:** $A$ is singular; no inverse exists.

1. Test invertibility by evaluating the two-by-two determinant, not by attempting to divide by a matrix with a missing pivot.

2. Calculate the next cofactor or determinant term with its indicated sign:

    $$
    \det A=4(3)-6(2)=12-12=0.
    $$

3. Therefore $A$ is singular and has no inverse. Equivalently, the second row is one-half of the first, so row reduction creates a zero row on the left of $[A\mid I]$.

4. Compute $4(3)-6(2)=12-12=0$. The second row equals one-half of the first, so row reduction leaves a zero row. There cannot be two pivots or an inverse.
::::
:::

:::problem[Problem 2.20 — Gauss–Jordan inversion]{difficulty=standard}
Find the inverse of $A=\begin{bmatrix}1&2\\3&7\end{bmatrix}$ by reducing $[A\mid I]$.

::::solution[Solution]
**Answer:** $A^{-1}=\begin{bmatrix}7&-2\\-3&1\end{bmatrix}$.

1. Attach $I_2$ to $A$ and perform each row operation on both halves. The goal is to turn the left block into the identity while tracking its effect on the right block.

2. Perform the next displayed row operation, applying it to every entry on both sides of the augmented matrix.

    $$
    \left[\begin{array}{rr|rr}1&2&1&0\\3&7&0&1\end{array}\right]
    \xrightarrow{R_2-3R_1}
    \left[\begin{array}{rr|rr}1&2&1&0\\0&1&-3&1\end{array}\right]
    \xrightarrow{R_1-2R_2}
    \left[\begin{array}{rr|rr}1&0&7&-2\\0&1&-3&1\end{array}\right].
    $$

3. Thus

4. Evaluate each displayed entry using the corresponding definition:

    $$
    A^{-1}=\begin{bmatrix}7&-2\\-3&1\end{bmatrix}.
    $$

5. First $R_2\leftarrow R_2-3R_1$ gives a unit pivot in column 2; then $R_1\leftarrow R_1-2R_2$ clears the upper entry. The right block becomes the claimed inverse.
::::
:::

:::problem[Problem 2.21 — Reverse the order]{difficulty=standard}
Suppose

$$
A^{-1}=\begin{bmatrix}1&-1\\0&2\end{bmatrix},
\qquad
B^{-1}=\begin{bmatrix}3&0\\4&1\end{bmatrix}.
$$

Find $(AB)^{-1}$.

::::solution[Solution]
**Answer:** $(AB)^{-1}=\begin{bmatrix}3&-3\\4&-2\end{bmatrix}$.

1. Apply the inverse-of-a-product rule before multiplying: $(AB)^{-1}=B^{-1}A^{-1}$. The reversal matters because matrix multiplication is not commutative.

2. The order reverses:

3. Evaluate each displayed entry using the corresponding definition:

    $$
    (AB)^{-1}=B^{-1}A^{-1}
    =\begin{bmatrix}3&0\\4&1\end{bmatrix}
    \begin{bmatrix}1&-1\\0&2\end{bmatrix}
    =\begin{bmatrix}3&-3\\4&-2\end{bmatrix}.
    $$

4. Check the product size before comparing the computed matrix entries.

5. Compute the first row of the product as $(3\cdot1+0\cdot0,\;3(-1)+0(2))=(3,-3)$ and the second as $(4,\,-4+2)=(4,-2)$.
::::
:::

:::problem[Problem 2.22 — Solve a square system]{difficulty=challenge}
Let

$$
A=\begin{bmatrix}2&1\\5&3\end{bmatrix},
\qquad
\mathbf{b}=\begin{bmatrix}1\\4\end{bmatrix}.
$$

Use an inverse to solve $A\mathbf{x}=\mathbf{b}$, and state the solution of $A\mathbf{x}=\mathbf{0}$.

::::solution[Solution]
**Answer:** $\mathbf{x}=\begin{bmatrix}-1\\3\end{bmatrix}$.

1. The determinant is $2(3)-1(5)=1$, so

2. Evaluate each displayed entry using the corresponding definition:

    $$
    A^{-1}=\begin{bmatrix}3&-1\\-5&2\end{bmatrix}.
    $$

3. Therefore

4. Evaluate each displayed entry using the corresponding definition:

    $$
    \mathbf{x}=A^{-1}\mathbf{b}
    =\begin{bmatrix}3&-1\\-5&2\end{bmatrix}
    \begin{bmatrix}1\\4\end{bmatrix}
    =\begin{bmatrix}-1\\3\end{bmatrix}.
    $$

5. For the homogeneous system,

6. Use the displayed equality to perform the next algebraic operation:

    $$
    \mathbf{x}=A^{-1}\mathbf{0}=\mathbf{0},
    $$

7. so the only solution is $(0,0)^T$.
::::
:::

## 2.3 Characterizations of Invertible Matrices

:::callout-intuition[Intuition first]
The Invertible Matrix Theorem (IMT) is one of the most important results in linear algebra.
 It says that for a **square** matrix $A$, a large number of seemingly different conditions
 are actually all *exactly equivalent* — they all mean the same thing. If you know
 any one of them, you know all of them. The list looks long, but there are really only a few
 ideas in it, and you already met all of them in Chapter 1. The theorem's job is to tell you that,
 once the matrix is square, those ideas are the same idea.
:::

:::callout-pitfall[Square matrices only]
**The IMT applies only to square matrices.** Every statement below begins "Let $A$ be an $n\times n$ matrix." If $A$ is $3\times2$, $2\times3$, $4\times5$, or any other non-square shape, the IMT says **nothing**. The statements do not all stand or fall together for such a matrix, and a conclusion drawn from the IMT about a non-square matrix is wrong. This is the most common way the theorem is tested: you are handed a non-square matrix and the correct answer is "the IMT does not apply."
:::

### The theorem

The statements are lettered (a)–(q) to match the instructor's handout, so you can read your sheet and this page side by side.

:::theorem[Theorem 2.4 — The Invertible Matrix Theorem (IMT)]
Let $A$ be a square $n\times n$ matrix. The following statements are *all equivalent* (for a given $A$, either all are true or all are false):

- (a) $A$ is an invertible matrix.
- (b) $A$ is row equivalent to the $n\times n$ identity matrix $I_n$.
- (c) $A$ has $n$ pivot positions.
- (d) The equation $A\mathbf{x} = \mathbf{0}$ has only the trivial solution.
- (e) The columns of $A$ form a linearly independent set.
- (f) The linear transformation $\mathbf{x} \mapsto A\mathbf{x}$ is one-to-one.
- (g) The equation $A\mathbf{x} = \mathbf{b}$ has at least one solution for each $\mathbf{b}$ in $\mathbb{R}^n$.
- (h) The columns of $A$ span $\mathbb{R}^n$.
- (i) The linear transformation $\mathbf{x} \mapsto A\mathbf{x}$ maps $\mathbb{R}^n$ onto $\mathbb{R}^n$.
- (j) There is an $n\times n$ matrix $C$ such that $CA = I$.
- (k) There is an $n\times n$ matrix $D$ such that $AD = I$.
- (l) $A^T$ is an invertible matrix.
- (m) The columns of $A$ form a basis of $\mathbb{R}^n$.
- (n) $\text{Col}\,A = \mathbb{R}^n$.
- (o) $\text{rank}\,A = n$.
- (p) $\dim\text{Nul}\,A = 0$.
- (q) $\text{Nul}\,A = \{\mathbf{0}\}$.
:::

### Why they are equivalent: one spine

Do not memorize seventeen statements. Understand one fact and the rest follow.

:::callout-intuition[The spine of the IMT]
An $n\times n$ matrix has $n$ rows and $n$ columns. Chapter 1 told you two things about pivots:

- **A pivot in every column** means no free variables, so $A\mathbf{x}=\mathbf{0}$ has only the trivial solution, the columns are independent, and $\mathbf{x}\mapsto A\mathbf{x}$ is **one-to-one** (uniqueness).
- **A pivot in every row** means no row of the form $[0\ \cdots\ 0\mid\text{nonzero}]$ can appear, so $A\mathbf{x}=\mathbf{b}$ is solvable for every $\mathbf{b}$, the columns span $\mathbb{R}^n$, and $\mathbf{x}\mapsto A\mathbf{x}$ is **onto** (existence).

For a general $m\times n$ matrix these are two *different* conditions. But a square matrix has as many rows as columns. $n$ pivots, each in its own row and its own column, is a pivot in every column **and** a pivot in every row at the same moment. Having one forces the other. So the uniqueness family and the existence family collapse into a single family, and that family is statement (c): $A$ has $n$ pivot positions.
:::

Here is how the statements sort themselves out.

**The pivot statement (c) is the hub.** Everything else is (c) in different words.

**The uniqueness family, (d), (e), (f), (q), says "a pivot in every column."**
- (d) $A\mathbf{x}=\mathbf{0}$ has only the trivial solution: no free variables.
- (e) The columns are linearly independent: this is the same statement as (d), by the definition of independence.
- (f) $\mathbf{x}\mapsto A\mathbf{x}$ is one-to-one: Chapter 1 showed one-to-one is equivalent to (d).
- (q) $\text{Nul}\,A=\{\mathbf{0}\}$: see the gloss below; it *is* (d).

**The existence family, (g), (h), (i), (n), says "a pivot in every row."**
- (g) $A\mathbf{x}=\mathbf{b}$ always has a solution: no row without a pivot.
- (h) The columns span $\mathbb{R}^n$: spanning *means* (g).
- (i) $\mathbf{x}\mapsto A\mathbf{x}$ is onto: onto *means* (g).
- (n) $\text{Col}\,A=\mathbb{R}^n$: see the gloss below; it is (h).

**Square size merges the two families.** Pivot in every column $\iff$ $n$ pivots $\iff$ pivot in every row. That one step is what makes (d)-(f) equivalent to (g)-(i). It uses squareness, which is why the theorem fails for non-square matrices.

**The matrix statements (a), (b), (j), (k), (l) connect to the pivots through row reduction.**
- (b) $\iff$ (c): $A$ reduces to $I_n$ exactly when every column has a pivot (Theorem 2.3G made this precise).
- (a) $\iff$ (b): Theorem 2.3G, from the elementary-matrices subsection of §2.2.
- (j) $CA=I$ $\Rightarrow$ (d): if $A\mathbf{x}=\mathbf{0}$ then $\mathbf{x}=CA\mathbf{x}=C\mathbf{0}=\mathbf{0}$. So a left inverse forces uniqueness.
- (k) $AD=I$ $\Rightarrow$ (g): for any $\mathbf{b}$, $\mathbf{x}=D\mathbf{b}$ solves $A\mathbf{x}=\mathbf{b}$, since $A(D\mathbf{b})=\mathbf{b}$. So a right inverse forces existence. Both lead back to (c), hence to (a), where the one-sided inverse becomes the full inverse.
- (l) $A^T$ is invertible: $(A^T)^{-1}=(A^{-1})^T$ if $A$ is invertible, and the reverse implication follows by applying the same fact to $A^T$.

**The last five, (m)-(q), are the same facts in new clothes.** They use words this chapter defines properly only in §2.8 and §2.9. You do not need to have read those sections to use these statements, because each one can be translated back into something you already know:

:::callout-key[Reading (m)–(q) without §2.8 and §2.9]
- **Nul $A$** (the *null space*) is just the **solution set of $A\mathbf{x}=\mathbf{0}$**. So (q) "$\text{Nul}\,A=\{\mathbf{0}\}$" says the only solution of $A\mathbf{x}=\mathbf{0}$ is $\mathbf{0}$. That is **(d) restated.**
- **dim Nul $A$** is the number of free variables in $A\mathbf{x}=\mathbf{0}$. So (p) "$\dim\text{Nul}\,A=0$" says there are no free variables. That is **(d) again** (and so (c)).
- **Col $A$** (the *column space*) is the **set of all linear combinations of the columns of $A$**, which is the span of the columns. So (n) "$\text{Col}\,A=\mathbb{R}^n$" says the columns span $\mathbb{R}^n$. That is **(h) restated.**
- **rank $A$** is the **number of pivot columns of $A$**. So (o) "$\text{rank}\,A=n$" says $n$ pivot columns in an $n\times n$ matrix. That is **(c) restated.**
- A **basis** of $\mathbb{R}^n$ is a set of vectors that is **linearly independent and spans $\mathbb{R}^n$**. So (m) "the columns form a basis of $\mathbb{R}^n$" is **(e) and (h) together**, and the IMT says that for square $A$ either one alone is enough.
:::

Nothing new is being claimed in (m)-(q). If you can recognize each as a relabeling, you will never be thrown by the new vocabulary on a quiz.

:::callout-key[How to use the IMT]
To show $A$ is invertible, you only need to verify *one* of the statements above, because the rest follow. To show $A$ is singular, you only need to find *one* that fails.
 The easiest check is usually (c): row-reduce and count pivots. Easy second choices: (d), by exhibiting a nonzero solution of $A\mathbf{x}=\mathbf{0}$ to prove singularity, or (e), by spotting one column that is a multiple or combination of the others.
:::

### Linear transformations and invertibility

The IMT already speaks about $\mathbf{x}\mapsto A\mathbf{x}$ in (f) and (i). The companion theorem describes what it means for the *transformation itself* to be invertible.

A linear transformation $T:\mathbb{R}^n\to\mathbb{R}^n$ is **invertible** if there is a function $S:\mathbb{R}^n\to\mathbb{R}^n$ with $S(T(\mathbf{x}))=\mathbf{x}$ and $T(S(\mathbf{x}))=\mathbf{x}$ for all $\mathbf{x}$. That is, $S$ undoes $T$ and $T$ undoes $S$.

:::theorem[Theorem 2.4A — Invertible linear transformations]
Let $T:\mathbb{R}^n\to\mathbb{R}^n$ be a linear transformation with standard matrix $A$. Then $T$ is invertible if and only if $A$ is an invertible matrix. In that case the inverse transformation is
$$
T^{-1}(\mathbf{x})=A^{-1}\mathbf{x},
$$
so the standard matrix of $T^{-1}$ is $A^{-1}$.
:::

Why this is true: $T$ is invertible exactly when $T$ is both one-to-one and onto. By (f) and (i) of the IMT, that happens exactly when $A$ is invertible. And $A^{-1}(A\mathbf{x})=\mathbf{x}$ shows that multiplication by $A^{-1}$ is the undoing transformation. Note the theorem is stated for $\mathbb{R}^n\to\mathbb{R}^n$ (same dimension on both sides), which is the square case again.

:::example[Example 2.22 — Invert a linear transformation]
Let $T:\mathbb{R}^2\to\mathbb{R}^2$ be given by $T(x_1,x_2)=(2x_1-3x_2,\;-x_1+2x_2)$. Show $T$ is invertible and find a formula for $T^{-1}$.

::::answer[Answer]
**Answer:** $T$ is invertible, and $T^{-1}(x_1,x_2)=(2x_1+3x_2,\;x_1+2x_2)$

1. $T$ is invertible, and $T^{-1}(x_1,x_2)=(2x_1+3x_2,\;x_1+2x_2)$.
The standard matrix is $A=\begin{bmatrix}2&-3\\-1&2\end{bmatrix}$. Its determinant is $ad-bc=4-3=1\neq0$, so $A$ is invertible, and by Theorem 2.4A so is $T$. By the $2\times2$ formula,

2. Evaluate each displayed entry using the corresponding definition:

    $$
    A^{-1}=\frac{1}{1}\begin{bmatrix}2&3\\1&2\end{bmatrix}=\begin{bmatrix}2&3\\1&2\end{bmatrix}.
    $$

3. Therefore $T^{-1}(\mathbf{x})=A^{-1}\mathbf{x}$, that is, $T^{-1}(x_1,x_2)=(2x_1+3x_2,\;x_1+2x_2)$.

4. Check: $T^{-1}(1,0)=(2,1)$ and $T(2,1)=(4-3,\,-2+2)=(1,0)$. The transformation $T$ returns the original input, as an inverse should.
::::
:::

:::example[Example 2.23 — A transformation that is not invertible]
Is $T(x_1,x_2)=(x_1+3x_2,\;2x_1+6x_2)$ invertible?

::::answer[Answer]
**Answer:** No.

1. An invertible linear transformation must map distinct inputs to distinct outputs and have a full-dimensional image. Test one of those requirements first.

2. The standard matrix is $A=\begin{bmatrix}1&3\\2&6\end{bmatrix}$ and $\det A=6-6=0$, so $A$ is singular and $T$ is not invertible. Concretely, $T(3,-1)=(0,0)=T(0,0)$, so $T$ sends two different inputs to the same output and is not one-to-one; its outputs all lie on the line $x_2=2x_1$, so it is not onto either.

3. The nonzero input $(3,-1)$ maps to zero, so the kernel is nontrivial; the linear transformation cannot have an inverse.
::::
:::

### Worked examples

:::example[Example 2.24 — Applying the IMT]
Without finding $A^{-1}$, determine whether $A = \begin{bmatrix}1&2&3\\0&1&4\\0&0&5\end{bmatrix}$ is invertible.

::::answer[Answer]
**Answer:** $A$ is invertible

1. The coefficient matrix is square, so it qualifies for the Invertible Matrix Theorem. Inspect the three diagonal pivots before attempting an inverse.

2. $A$ is invertible.
$A$ is upper triangular. Its diagonal entries are $1, 1, 5$ — all nonzero. An upper triangular matrix is invertible iff all diagonal entries are nonzero (each diagonal entry is a pivot). Since all three diagonals are nonzero, there are 3 pivot positions in a $3\times3$ matrix — satisfying condition (c) of the IMT.

3. A pivot in each of the three columns gives rank three and zero nullity. Every statement of the theorem then follows from invertibility.
::::
:::

:::example[Example 2.25 — One matrix, every statement]
Let $A=\begin{bmatrix}1&0&2\\2&1&3\\0&1&1\end{bmatrix}$. Decide whether $A$ is invertible, then say what that tells you about (d), (g), (h), (l) and (q).

::::answer[Answer]
**Answer:** $A$ is invertible, so (a)–(q) are all true for $A$

1. $A$ is invertible, so (a)–(q) are all true for $A$.
Row reduce: $R_2\to R_2-2R_1$ gives $\begin{bmatrix}1&0&2\\0&1&-1\\0&1&1\end{bmatrix}$, then $R_3\to R_3-R_2$ gives $\begin{bmatrix}1&0&2\\0&1&-1\\0&0&2\end{bmatrix}$. There are three pivots, in columns 1, 2, 3 and in rows 1, 2, 3. So (c) is true, and the IMT makes every other statement true at once:

2. Apply each listed property to the stated part of the question.

    - (d) $A\mathbf{x}=\mathbf{0}$ has only $\mathbf{x}=\mathbf{0}$, because no column lacks a pivot.
    - (g) $A\mathbf{x}=\mathbf{b}$ is solvable for every $\mathbf{b}\in\mathbb{R}^3$, because no row lacks a pivot.
    - (h) The three columns span $\mathbb{R}^3$.
    - (l) $A^T$ is invertible.
    - (q) $\text{Nul}\,A=\{\mathbf{0}\}$.
::::
:::

:::example[Example 2.26 — When a statement fails, all fail]
Let $A=\begin{bmatrix}1&2&3\\4&5&6\\7&8&9\end{bmatrix}$. Show $A$ is singular, and state what that means for (e), (g), (h) and (o).

::::answer[Answer]
**Answer:** $A$ is singular. Its columns are dependent, $A\mathbf{x}=\mathbf{b}$ fails for some $\mathbf{b}$, the columns do not span $\mathbb{R}^3$, and $\text{rank}\,A=2<3$

1. Identify pivot positions from an echelon form; select original columns for a column-space basis and free-variable special solutions for the null space.

2. $A$ is singular. Its columns are dependent, $A\mathbf{x}=\mathbf{b}$ fails for some $\mathbf{b}$, the columns do not span $\mathbb{R}^3$, and $\text{rank}\,A=2<3$.
Row reduce: $R_2\to R_2-4R_1$ gives $(0,-3,-6)$ and $R_3\to R_3-7R_1$ gives $(0,-6,-12)$. Then $R_3\to R_3-2R_2$ gives $(0,0,0)$. There are only two pivots, so (c) fails, and therefore **every** statement in the IMT is false for this $A$.

3. Concretely, $\mathbf{x}=(1,-2,1)^T$ satisfies $A\mathbf{x}=\mathbf{0}$ (check: $1-4+3=0$, $4-10+6=0$, $7-16+9=0$), so $A\mathbf{x}=\mathbf{0}$ has a nontrivial solution and (d) fails. Equivalently column 1 $-\,2\,$(column 2) $+$ column 3 $=\mathbf{0}$, so the columns are dependent, (e) fails. The rank is the number of pivot columns, which is $2$, so (o) fails. The columns span only a plane inside $\mathbb{R}^3$, so (h) and (g) fail: some $\mathbf{b}$ is unreachable.
::::
:::

:::example[Example 2.27 — A non-square matrix: the IMT does not apply]
Let $B=\begin{bmatrix}1&0\\0&1\\1&1\end{bmatrix}$ ($3\times2$) and $C=\begin{bmatrix}1&0&1\\0&1&1\end{bmatrix}$ ($2\times3$). What does the IMT say about them?

::::answer[Answer]
**Answer:** Nothing. Neither matrix is square, so the IMT does not apply. Indeed for these matrices the two families come apart.

1. $B$ has pivots in both columns, so $B\mathbf{x}=\mathbf{0}$ has only the trivial solution: the columns are independent and $\mathbf{x}\mapsto B\mathbf{x}$ is one-to-one. But $B$ has only 2 pivots in 3 rows, so its columns (two vectors) cannot span $\mathbb{R}^3$, and the map is **not** onto. Uniqueness holds and existence fails.

2. $C$ has a pivot in both rows, so its columns span $\mathbb{R}^2$ and $\mathbf{x}\mapsto C\mathbf{x}$ is onto. But there are 3 columns and only 2 pivots, so there is a free variable: $C\,(-1,-1,1)^T=\mathbf{0}$, a nontrivial solution. The map is **not** one-to-one. Existence holds and uniqueness fails.

3. Only when the matrix is square can a pivot in every row and a pivot in every column happen together.
::::
:::

### Practice problems

:::problem[Problem 2.23 — Check pivots and invertibility]{difficulty=easy}
Is $A = \begin{bmatrix}2&0\\0&0\end{bmatrix}$ invertible? Which IMT condition fails first?

::::solution[Solution]
**Answer:** Not invertible; the matrix has only one pivot.

1. The matrix is square, so the Invertible Matrix Theorem applies. Read its pivots directly from the diagonal form rather than doing unnecessary arithmetic.

2. **Not invertible. The matrix has only 1 pivot (column 1), not 2. Condition (c) fails. Equivalently, $A\mathbf{x}=\mathbf{0}$ has the nontrivial solution $\mathbf{x}=(0,1)^T$, so condition (d) fails.

3. Column 1 contains pivot $2$ but column 2 has no pivot. Thus the matrix has rank $1<2$, its columns are dependent, and it cannot have an inverse.
::::
:::

:::problem[Problem 2.24 — Dependent rows]{difficulty=standard}
Use the IMT to determine invertibility of $A = \begin{bmatrix}1&3\\2&6\end{bmatrix}$. State which condition reveals singularity.

::::solution[Solution]
**Answer:** Singular; the second row is twice the first.

1. For square matrices, a repeated or dependent row forces a missing pivot. Use the dependency to avoid computing an inverse.

2. Row 2 = $2\times$ row 1, so after $R_2 - 2R_1$ the matrix becomes $\begin{bmatrix}1&3\\0&0\end{bmatrix}$ — only 1 pivot. **Singular. Condition (e) fails: the columns $\binom{1}{2}$ and $\binom{3}{6}=3\binom{1}{2}$ are linearly dependent.

3. Subtract twice row 1 from row 2: $(2,6)-2(1,3)=(0,0)$. Only one nonzero pivot row remains, so the Invertible Matrix Theorem says the matrix is singular.
::::
:::

:::problem[Problem 2.25 — Right inverse and the IMT]{difficulty=challenge}
Suppose $AB = I_n$. Use the IMT to show that $A$ must be invertible, and that $B = A^{-1}$.

::::solution[Solution]
**Answer:** $A$ is invertible when $AB=I$ for square matrices.

1. Because $A$ and $B$ are both $n\times n$, a right inverse is enough: $AB=I_n$ means $A(B\mathbf b)=\mathbf b$ for every $\mathbf b$.

2. Since $AB = I$, for any $\mathbf{b}\in\mathbb{R}^n$ we can find a solution to $A\mathbf{x}=\mathbf{b}$: take $\mathbf{x} = B\mathbf{b}$, then $A(B\mathbf{b}) = (AB)\mathbf{b} = I\mathbf{b} = \mathbf{b}$. So condition (g) of the IMT holds — $A$ is invertible.

3. Since $A$ is invertible, multiply $AB = I$ on the left by $A^{-1}$: $B = A^{-1}I = A^{-1}$. $\square$

4. Consequently $A\mathbf x=\mathbf b$ is consistent for every right-hand side. The IMT makes $A$ invertible; multiplying $AB=I$ by $A^{-1}$ on the left then yields $B=A^{-1}$.
::::
:::

:::problem[Problem 2.26 — Consistency from the IMT]{difficulty=easy}
For $A=\begin{bmatrix}1&0&2\\2&1&3\\0&1&1\end{bmatrix}$, is the equation $A\mathbf{x}=\mathbf{b}$ solvable for every $\mathbf{b}\in\mathbb{R}^3$? Answer using one pivot count.

::::solution[Solution]
**Answer:** Yes, a solution exists for every right-hand side.

1. For a square $3\times3$ matrix, showing three pivots suffices to infer consistency for every $\mathbf b$ by the Invertible Matrix Theorem.

2. Row reduction (Example 2.5D) gives three pivots, so (c) holds, and by the IMT so does (g). Yes: $A\mathbf{x}=\mathbf{b}$ has a solution for every $\mathbf{b}\in\mathbb{R}^3$, in fact exactly one.

3. Use row elimination to identify one pivot in each column. With no free variables and no missing pivot row, the matrix maps $\mathbb R^3$ onto $\mathbb R^3$, so every right-hand side is attainable.
::::
:::

:::problem[Problem 2.27 — Equivalent IMT conditions]{difficulty=standard}
Let $A$ be a $4\times4$ matrix whose columns are linearly dependent. Which of the following must be true? (i) $A\mathbf{x}=\mathbf{b}$ has a solution for every $\mathbf{b}\in\mathbb{R}^4$. (ii) $A^T$ is invertible. (iii) $\text{Nul}\,A\neq\{\mathbf{0}\}$. (iv) $A$ has fewer than 4 pivot positions.

::::solution[Solution]
**Answer:** All invertibility conditions fail because $A$ is singular.

1. Dependent columns give a nonzero vector in $\operatorname{Nul}A$. The square-matrix IMT therefore classifies $A$ as singular.

2. $A$ is square and statement (e) is false, so by the IMT every statement is false and $A$ is singular.

3. (i) False: this is (g). (ii) False: this is (l). (iii) **True**: (q) fails, so $\text{Nul}\,A$ contains a nonzero vector. (iv) **True**: (c) fails.

4. Evaluate each statement through equivalence: consistency for every $\mathbf b$ is false; $A^T$ invertible is false; nontrivial null space is true; fewer than four pivots is true.
::::
:::

:::problem[Problem 2.28 — Parameter-dependent invertibility]{difficulty=standard}
Find all values of $h$ for which $A=\begin{bmatrix}1&1&0\\1&2&1\\0&1&h\end{bmatrix}$ is **not** invertible.

::::solution[Solution]
**Answer:** $A$ is noninvertible exactly when $h=1$.

1. Eliminate below the first pivot without changing invertibility; then subtract the new second row from the third. Inspect the final diagonal pivot as a function of $h$.

2. Row reduce: $R_2\to R_2-R_1$ gives $\begin{bmatrix}1&1&0\\0&1&1\\0&1&h\end{bmatrix}$, then $R_3\to R_3-R_2$ gives $\begin{bmatrix}1&1&0\\0&1&1\\0&0&h-1\end{bmatrix}$.

3. $A$ has three pivots exactly when $h-1\neq0$. So $A$ fails to be invertible only for $h=1$.

4. Check: for $h=1$, column 3 $=$ column 2 $-$ column 1, so the columns are dependent.

5. The pivots are $1,1,h-1$. A missing third pivot occurs exactly when $h-1=0$, so $h=1$ is the requested noninvertible value; all other real $h$ work.
::::
:::

:::problem[Problem 2.29 — A rectangular matrix and independence]{difficulty=standard}
Let $B=\begin{bmatrix}1&0\\0&1\\1&1\end{bmatrix}$. A student argues: "the columns of $B$ are linearly independent, so by the IMT $B$ is invertible." Is this correct?

::::solution[Solution]
**Answer:** No; the IMT does not apply to the nonsquare matrix.

1. Read the dimensions before applying the IMT. The matrix has three rows and only two columns; invertibility in the ordinary two-sided sense requires a square matrix.

2. **No. The IMT applies only to square matrices, and $B$ is $3\times2$. The columns of $B$ are independent (two pivots, one in each column), but two vectors cannot span $\mathbb{R}^3$, so $\mathbf{x}\mapsto B\mathbf{x}$ is not onto. The square-matrix collapse of "independent" into "spanning" does not occur here, and $B$ has no inverse because an inverse is only defined for square matrices.

3. The two columns can be independent without spanning $\mathbb R^3$. In fact their span has dimension at most $2$, so the student’s implication is invalid.
::::
:::

:::problem[Problem 2.30 — Rectangular surjectivity versus invertibility]{difficulty=standard}
Let $A$ be $3\times5$ with columns that span $\mathbb{R}^3$. Is $A$ invertible? Is $\mathbf{x}\mapsto A\mathbf{x}$ one-to-one?

::::solution[Solution]
**Answer:** $A$ is not invertible because it is nonsquare.

1. A $3\times5$ matrix can map onto $\mathbb R^3$ with rank $3$, but it cannot be invertible because it is not square.

2. The IMT does not apply because $A$ is not square, and $A$ is not invertible because inverses exist only for square matrices. Since the columns span $\mathbb{R}^3$ there is a pivot in all 3 rows, but there are 5 columns and at most 3 pivots, so at least 2 free variables. So $A\mathbf{x}=\mathbf{0}$ has nontrivial solutions and the map is **not** one-to-one (it is onto).

3. Rank-nullity gives nullity $5-3=2$. Thus the kernel contains nonzero vectors and the map is not one-to-one, despite the spanning hypothesis.
::::
:::

:::problem[Problem 2.31 — Inverse linear transformation]{difficulty=standard}
Let $T(x_1,x_2)=(x_1+3x_2,\;2x_1+5x_2)$. Show that $T$ is invertible and find $T^{-1}(x_1,x_2)$.

::::solution[Solution]
**Answer:** $A^{-1}=\begin{bmatrix}-5&3\\2&-1\end{bmatrix}$.

1. $A=\begin{bmatrix}1&3\\2&5\end{bmatrix}$ has $\det A=5-6=-1\neq0$, so $A$ and $T$ are invertible. Then

2. Evaluate each displayed entry using the corresponding definition:

    $$
    A^{-1}=\frac{1}{-1}\begin{bmatrix}5&-3\\-2&1\end{bmatrix}=\begin{bmatrix}-5&3\\2&-1\end{bmatrix},
    $$

3. so $T^{-1}(x_1,x_2)=(-5x_1+3x_2,\;2x_1-x_2)$.

4. Check: $T^{-1}(1,0)=(-5,2)$ and $T(-5,2)=(-5+6,\,-10+10)=(1,0)$.

5. Multiply the factors to verify $AA^{-1}=\begin{bmatrix}-5+6&3-3\\-10+10&6-5\end{bmatrix}=\begin{bmatrix}1&0\\0&1\end{bmatrix}$. Therefore the inverse also undoes the transformation on every input, not just the test vector.
::::
:::

:::problem[Problem 2.32 — Two consequences of invertibility]{difficulty=standard}
Let $A$ be $6\times6$. Suppose $A\mathbf{x}=\mathbf{0}$ has only the trivial solution. Must $A\mathbf{x}=\mathbf{b}$ be consistent for every $\mathbf{b}\in\mathbb{R}^6$? Must the columns of $A$ span $\mathbb{R}^6$?

::::solution[Solution]
**Answer:** Yes to both conditions.

1. For this square $6\times6$ matrix, only the trivial solution to $A\mathbf x=0$ means the columns are independent.

2. Yes to both. $A$ is square and (d) is true, so by the IMT $A$ is invertible and every other statement holds, including (g) and (h). The reasoning behind it: no free variables means 6 pivots in a $6\times6$ matrix, which puts a pivot in every row too.

3. There must be six pivots and hence rank $6$. By the Invertible Matrix Theorem the columns also span $\mathbb R^6$, so $A\mathbf x=\mathbf b$ is consistent for every $\mathbf b$.
::::
:::

:::problem[Problem 2.33 — Nilpotent matrix cannot invert]{difficulty=challenge}
Let $A$ be an $n\times n$ matrix with $A^2=0$ and $A\neq0$. Show $A$ is not invertible.

::::solution[Solution]
**Answer:** $A$ cannot be invertible when $A^2=0$ and $A\ne0$.

1. Assume for contradiction that $A$ is invertible. Multiplication by $A^{-1}$ is allowed on either side of the identity $A^2=0$.

2. Suppose $A$ were invertible. Multiply $A^2=0$ on the left by $A^{-1}$ twice: $A^{-1}(AA)=A$, and the right side stays $0$, so $A=0$. This contradicts $A\neq0$. Hence $A$ is not invertible.

3. (Another route: $A^2=0$ says $A$ times each column of $A$ is $\mathbf{0}$, so $\text{Nul}\,A$ contains every column of $A$. Some column is nonzero, so (q) fails.)

4. Multiplying on the left gives $A^{-1}A^2=A^{-1}0$, so $A=0$. This contradicts the stated nonzero hypothesis; hence the assumption of invertibility must fail.
::::
:::

:::problem[Problem 2.34 — Invertible matrix products]{difficulty=challenge}
Let $A$ and $B$ be $n\times n$ and suppose $AB$ is invertible. Show that $A$ and $B$ are both invertible.

::::solution[Solution]
**Answer:** Both $A$ and $B$ are invertible if $AB$ is invertible.

1. An invertible product $AB$ has an inverse $D=(AB)^{-1}$. Use its two identities to construct one-sided inverses of the square factors.

2. Let $D=(AB)^{-1}$. Then $(AB)D=I$, so $A(BD)=I$: the matrix $BD$ is a right inverse of $A$. By (k), $A$ is invertible.

3. Also $D(AB)=I$, so $(DA)B=I$: the matrix $DA$ is a left inverse of $B$. By (j), $B$ is invertible. $\square$

4. From $A(BD)=I$, $A$ has a right inverse, so it is invertible. From $(DA)B=I$, $B$ has a left inverse, so it is invertible. Both conclusions use the square-matrix IMT.
::::
:::

:::problem[Problem 2.35 — Fourteen IMT true-or-false statements]{difficulty=standard}
**True or false drill.** Let $A$ be a matrix as described in each statement. Mark each true or false and cite the IMT statement or the reason. Remember: first check whether the matrix is square.

1. If $A$ is $n\times n$ and $A\mathbf{x}=\mathbf{0}$ has a nontrivial solution, then the columns of $A$ span $\mathbb{R}^n$.
2. If the columns of a $4\times4$ matrix $A$ are linearly independent, then $A\mathbf{x}=\mathbf{b}$ is consistent for every $\mathbf{b}\in\mathbb{R}^4$.
3. If $A$ is $3\times5$ and its columns span $\mathbb{R}^3$, then $A$ is invertible.
4. If $A$ is $n\times n$ and $A\mathbf{x}=\mathbf{b}$ has a solution for each $\mathbf{b}$, then $A$ has $n$ pivot positions.
5. If $A$ is $5\times5$ with 4 pivot positions, then $\mathbf{x}\mapsto A\mathbf{x}$ is one-to-one.
6. If $A$ is invertible, then $A^T$ is invertible.
7. If $A$ is $n\times n$ and there is an $n\times n$ matrix $C$ with $CA=I$, then $A$ is invertible.
8. If $A$ is $4\times3$ with linearly independent columns, then $A$ is invertible.
9. If $A$ is $n\times n$ and $\mathbf{x}\mapsto A\mathbf{x}$ is onto, then it is also one-to-one.
10. If $A$ is $3\times3$ and $A\mathbf{x}=\mathbf{b}$ has a unique solution for some $\mathbf{b}$, then $A$ is invertible.
11. If $A$ is $4\times4$ and has a row of zeros, then $A$ is invertible.
12. If $A$ is $n\times n$ and $\text{Col}\,A\neq\mathbb{R}^n$, then $A\mathbf{x}=\mathbf{0}$ has a nontrivial solution.
13. If $A$ is $5\times5$ and $\dim\text{Nul}\,A=1$, then $\text{rank}\,A=4$ and $A$ is not invertible.
14. If $A$ is $2\times2$ and $A\mathbf{x}=\mathbf{b}$ has no solution for some $\mathbf{b}$, then $A\mathbf{x}=\mathbf{0}$ has only the trivial solution.

::::solution[Solution]
**Answer:** False, true, false, true, false, true, true, false, true, true, false, true, true, false (in question order).

1. **False.** $A$ is square and (d) fails, so every statement fails, including (h).

2. **True.** (e) holds, so $A$ is invertible, so (g) holds.

3. **False.** $A$ is not square, so the IMT does not apply; it has 5 columns but at most 3 pivots, so the matrix cannot be invertible (inverses exist only for square matrices).

4. **True.** (g) $\Rightarrow$ (c).

5. **False.** 4 pivots in 5 columns means a free variable, so (d) fails, so (f) fails.

6. **True.** (a) $\Rightarrow$ (l).

7. **True.** (j) $\Rightarrow$ (a).

8. **False.** $A$ is not square; the IMT does not apply. The columns are independent, but they cannot span $\mathbb{R}^4$.

9. **True.** (i) $\Rightarrow$ (a) $\Rightarrow$ (f).

10. **True. A unique solution for one $\mathbf{b}$ means no free variables, so (d) holds, so $A$ is invertible.

11. **False. A zero row means at most 3 pivots, so (c) fails: $A$ is singular.

12. **True.** $\text{Col}\,A\ne\mathbb{R}^n$ means (n) fails, so (q) fails, so $\text{Nul}\,A\ne\{\mathbf{0}\}$.

13. **True.** $\dim\text{Nul}\,A=1$ means one free variable, so 4 pivot columns, so $\text{rank}\,A=4<5$ and (o) fails.

14. **False.** (g) fails, so (d) fails: $A\mathbf{x}=\mathbf{0}$ has nontrivial solutions.

    1. **False.** $A$ is square and (d) fails, so every statement fails, including (h).
    2. **True.** (e) holds, so $A$ is invertible, so (g) holds.
    3. **False.** $A$ is not square, so the IMT does not apply; it has 5 columns but at most 3 pivots, so the matrix cannot be invertible (inverses exist only for square matrices).
    4. **True.** (g) $\Rightarrow$ (c).
    5. **False.** 4 pivots in 5 columns means a free variable, so (d) fails, so (f) fails.
    6. **True.** (a) $\Rightarrow$ (l).
    7. **True.** (j) $\Rightarrow$ (a).
    8. **False.** $A$ is not square; the IMT does not apply. The columns are independent, but they cannot span $\mathbb{R}^4$.
    9. **True.** (i) $\Rightarrow$ (a) $\Rightarrow$ (f).
    10. **True. A unique solution for one $\mathbf{b}$ means no free variables, so (d) holds, so $A$ is invertible.
    11. **False. A zero row means at most 3 pivots, so (c) fails: $A$ is singular.
    12. **True.** $\text{Col}\,A\ne\mathbb{R}^n$ means (n) fails, so (q) fails, so $\text{Nul}\,A\ne\{\mathbf{0}\}$.
    13. **True.** $\dim\text{Nul}\,A=1$ means one free variable, so 4 pivot columns, so $\text{rank}\,A=4<5$ and (o) fails.
    14. **False.** (g) fails, so (d) fails: $A\mathbf{x}=\mathbf{0}$ has nontrivial solutions.
::::
:::

:::problem[Problem 2.36 — Dependence prevents surjectivity]{difficulty=standard}
The matrix $A=\begin{bmatrix}1&0&2&1\\0&1&1&0\\1&1&3&1\\0&0&1&2\end{bmatrix}$ is $4\times4$. Without computing any inverse, decide whether $A\mathbf{x}=\mathbf{b}$ is solvable for every $\mathbf{b}\in\mathbb{R}^4$.

::::solution[Solution]
**Answer:** $A$ is not invertible because its rows are dependent.

1. Look for a linear dependence among the original rows before attempting elimination. The third row equals the first plus the second.

2. Row 3 equals row 1 plus row 2 (check: $(1,0,2,1)+(0,1,1,0)=(1,1,3,1)$). After $R_3\to R_3-R_1-R_2$ row 3 becomes zero, so $A$ has at most 3 pivots. Since $A$ is square, (c) fails, and so does (g): **no**, $A\mathbf{x}=\mathbf{b}$ is not solvable for every $\mathbf{b}$.

3. Subtract $R_1+R_2$ from $R_3$ to create a zero row. The $4\times4$ matrix then has fewer than four pivots, so its columns cannot span all of $\mathbb R^4$.
::::
:::

## 2.5 Solving Linear Systems by Matrix Factorizations

:::callout-intuition[Intuition first]
Suppose you need to solve $A\mathbf{x} = \mathbf{b}$ for 1000 different right-hand
 sides $\mathbf{b}_1, \mathbf{b}_2, \ldots$ with the *same* matrix $A$.
 Repeating full row reduction 1000 times is wasteful. LU factorization does the hard
 work once — it decomposes $A = LU$ into a lower triangular matrix $L$ and an
 upper triangular matrix $U$. Then each new right-hand side requires only two cheap
 triangular solves instead of full elimination. This is how numerical software (MATLAB,
 NumPy) solves linear systems in practice.
:::

:::definition[Definition 2.4 — LU Factorization]
An $m\times n$ matrix $A$ has an **LU factorization** if it can be written as

$$
A = LU,
$$

 where $L$ is an $m\times m$ *unit lower triangular* matrix (lower triangular with 1s on the diagonal) and $U$ is an $m\times n$ *upper triangular* matrix (the echelon form of $A$).
:::

### Building $L$ and $U$

Row-reduce $A$ to echelon form $U$ using only row replacement operations (no swaps, no scaling of pivot rows). The multipliers used in each step become the entries of $L$:

If step $k$ eliminates entry $(i,j)$ using the multiplier $m = a_{ij}/a_{jj}$ (i.e., $R_i \leftarrow R_i - m R_j$), then place $m$ at position $(i,j)$ in $L$. Fill the diagonal of $L$ with 1s.

### Solving $A\mathbf{x} = \mathbf{b}$ with LU

Once $A = LU$, split into two triangular systems:

1. **Forward substitution:** Solve $L\mathbf{y} = \mathbf{b}$ for $\mathbf{y}$ (easy — $L$ is lower triangular).
2. **Back substitution:** Solve $U\mathbf{x} = \mathbf{y}$ for $\mathbf{x}$ (easy — $U$ is upper triangular).

### Worked examples

:::example[Example 2.28 — Finding the LU factorization]
Find the LU factorization of $A = \begin{bmatrix}2&4&-2\\1&5&-1\\-1&3&4\end{bmatrix}$.

::::answer[Answer]
**Answer:** $L = \begin{bmatrix}1&0&0\\\frac{1}{2}&1&0\\-\frac{1}{2}&\frac{5}{3}&1\end{bmatrix}$, $U = \begin{bmatrix}2&4&-2\\0&3&0\\0&0&3\end{bmatrix}$.

1. $L = \begin{bmatrix}1&0&0\\\frac{1}{2}&1&0\\-\frac{1}{2}&\frac{5}{3}&1\end{bmatrix}$, $U = \begin{bmatrix}2&4&-2\\0&3&0\\0&0&3\end{bmatrix}$.
**Step 1:** Eliminate column 1 below the pivot (row 1).

2. $R_2 \leftarrow R_2 - \frac{1}{2}R_1$: multiplier $m_{21} = \frac{1}{2}$.

3. Evaluate each displayed entry using the corresponding definition:

    $$
    \begin{bmatrix}2&4&-2\\0&3&0\\-1&3&4\end{bmatrix}
    $$

4. $R_3 \leftarrow R_3 - (-\frac{1}{2})R_1 = R_3 + \frac{1}{2}R_1$: multiplier $m_{31} = -\frac{1}{2}$.

5. Evaluate each displayed entry using the corresponding definition:

    $$
    \begin{bmatrix}2&4&-2\\0&3&0\\0&5&3\end{bmatrix}
    $$

6. **Step 2:** Eliminate column 2 below the pivot (row 2).

7. $R_3 \leftarrow R_3 - \frac{5}{3}R_2$: multiplier $m_{32} = \frac{5}{3}$.

8. Evaluate each displayed entry using the corresponding definition:

    $$
    U = \begin{bmatrix}2&4&-2\\0&3&0\\0&0&3\end{bmatrix}
    $$

9. Checking that last step: $R_3$ after step 1 was $[0, 5, 3]$, and $R_3 - \tfrac{5}{3}R_2 = [0,\ 5-5,\ 3-0] = [0,0,3]$, which is the third row of $U$ above.

10. Assemble $L$ with the multipliers and 1s on the diagonal:

11. Evaluate each displayed entry using the corresponding definition:

    $$
    L = \begin{bmatrix}1&0&0\\\frac{1}{2}&1&0\\-\frac{1}{2}&\frac{5}{3}&1\end{bmatrix}
    $$

12. Verify: $LU = A$ (spot-check row 3 of $L$ times column 3 of $U$: $(-\frac{1}{2})(-2)+(\frac{5}{3})(0)+(1)(3) = 1+0+3=4\,\checkmark$).
::::
:::

:::example[Example 2.29 — Using LU to solve for two right-hand sides]
Using $A = LU$ with $L = \begin{bmatrix}1&0\\3&1\end{bmatrix}$, $U = \begin{bmatrix}2&1\\0&-2\end{bmatrix}$,
 solve $A\mathbf{x} = \begin{pmatrix}4\\6\end{pmatrix}$.

::::answer[Answer]
**Answer:** $\mathbf{x} = \begin{pmatrix}\frac{1}{2}\\3\end{pmatrix}$.

1. $\mathbf{x} = \begin{pmatrix}\frac{1}{2}\\3\end{pmatrix}$.
**Forward substitution** — solve $L\mathbf{y} = \mathbf{b}$:

2. Evaluate each displayed entry using the corresponding definition:

    $$
    \begin{bmatrix}1&0\\3&1\end{bmatrix}\begin{pmatrix}y_1\\y_2\end{pmatrix}=\begin{pmatrix}4\\6\end{pmatrix}
    $$

3. Row 1: $y_1 = 4$. Row 2: $3y_1 + y_2 = 6 \Rightarrow y_2 = 6-12 = -6$.

4. **Back substitution** — solve $U\mathbf{x} = \mathbf{y}$:

5. Evaluate each displayed entry using the corresponding definition:

    $$
    \begin{bmatrix}2&1\\0&-2\end{bmatrix}\begin{pmatrix}x_1\\x_2\end{pmatrix}=\begin{pmatrix}4\\-6\end{pmatrix}
    $$

6. Row 2: $-2x_2 = -6 \Rightarrow x_2 = 3$. Row 1: $2x_1 + 3 = 4 \Rightarrow x_1 = \frac{1}{2}$.

7. So $\mathbf{x} = \begin{pmatrix}\frac{1}{2}\\3\end{pmatrix}$. Verify by multiplying $A=LU=\begin{bmatrix}2&1\\6&1\end{bmatrix}$: $A\mathbf{x}=(1+3,3+3)^T=(4,6)^T$.

8. **Second right-hand side:** Reuse the same $L$ and $U$ for $A\mathbf z=(3,7)^T$. Forward substitution gives $y_1=3$, $3y_1+y_2=7$, so $y_2=-2$. Back substitution gives $-2z_2=-2$, hence $z_2=1$, and $2z_1+z_2=3$, hence $z_1=1$. The second solution is $\mathbf z=(1,1)^T$, and $A\mathbf z=(3,7)^T$. No second elimination was required.
::::
:::

:::callout-pitfall[Watch out for]
- **LU requires no row swaps.** If a zero pivot appears and you must swap rows, you need a *permuted* LU factorization $PA = LU$. In practice, software always uses permutations for numerical stability.
- **The multipliers go into $L$ with their *original* sign.** If $R_i \leftarrow R_i - m\cdot R_j$, then $L_{ij} = m$ (positive), not $-m$.
- **Forward substitution goes top-down; back substitution goes bottom-up.** Don't mix them up.
:::

### Practice problems

:::problem[Problem 2.37 — Forward substitution]{difficulty=easy}
Solve $L\mathbf{y} = \mathbf{b}$ by forward substitution, where $L = \begin{bmatrix}1&0&0\\2&1&0\\-1&3&1\end{bmatrix}$ and $\mathbf{b} = \begin{pmatrix}3\\1\\4\end{pmatrix}$.

::::solution[Solution]
**Answer:** $\mathbf{y}=(3,-5,22)^T$.

1. For a lower triangular $L$, solve $L\mathbf y=\mathbf b$ from top to bottom. The first row gives $y_1=3$ directly.

2. Row 1: $y_1 = 3$. Row 2: $2(3)+y_2=1 \Rightarrow y_2 = -5$. Row 3: $-1(3)+3(-5)+y_3 = 4 \Rightarrow y_3 = 4+3+15=22$.

3. $\mathbf{y} = (3,-5,22)^T$.

4. The second row gives $2(3)+y_2=1$, so $y_2=-5$. The third gives $-3+3(-5)+y_3=4$, hence $y_3=22$. Check each original row with these values.
::::
:::

:::problem[Problem 2.38 — LU factorization and substitution]{difficulty=standard}
Find the LU factorization of $A = \begin{bmatrix}1&2\\3&8\end{bmatrix}$ and use it to solve $A\mathbf{x} = \begin{pmatrix}2\\12\end{pmatrix}$.

::::solution[Solution]
**Answer:** $L=\begin{bmatrix}1&0\\3&1\end{bmatrix}$, $U=\begin{bmatrix}1&2\\0&2\end{bmatrix}$.

1. Eliminate the lower-left entry with multiplier $m_{21}=3/1=3$. Place that multiplier below the diagonal in $L$ and the resulting echelon entries in $U$.

2. $R_2 \leftarrow R_2 - 3R_1$, multiplier $m_{21}=3$. So $L=\begin{bmatrix}1&0\\3&1\end{bmatrix}$, $U=\begin{bmatrix}1&2\\0&2\end{bmatrix}$.

3. Forward: $y_1=2$, $3(2)+y_2=12\Rightarrow y_2=6$. Back: $2x_2=6\Rightarrow x_2=3$, $x_1+2(3)=2\Rightarrow x_1=-4$.

4. $\mathbf{x}=(-4,3)^T$.

5. Use $L\mathbf y=\mathbf b$ first, then $U\mathbf x=\mathbf y$. The two triangular solves give $\mathbf x=(-4,3)^T$; checking $A\mathbf x=(2,12)^T$ confirms the result.
::::
:::


### Why factoring once helps when the right-hand side changes

Suppose $A=LU$ and you have solved $A\mathbf x_1=\mathbf b_1$. A second right-hand side $\mathbf b_2$ does **not** require you to recompute the multipliers in $L$, the entries of $U$, or the pivots. Only the substitutions change. You solve $L\mathbf y_2=\mathbf b_2$ top-down and then $U\mathbf x_2=\mathbf y_2$ bottom-up. The matrix multiplication $LU$ remains the same, so the factorization can be checked once before either solve. A useful hand-work layout keeps $L,U$ above the page and writes two separate columns for $\mathbf y$ and $\mathbf x$ for each supplied $\mathbf b$.

Why do pivots matter? When $U$ has no zero diagonal entries, back substitution determines each variable uniquely. The pivots also give $\det U$, the product of its diagonal entries. For a square unit-lower $L$, $\det L=1$, so $\det A=\det L\det U$ equals the product of the pivots in $U$ **when no row swaps occur**. If row swaps are needed, each swap changes the determinant sign and must be accounted for by the permutation factor. This identity gives another check of an $LU$ computation, but it does not replace multiplying $LU$ when you are checking the full matrix.

### Elimination matrices and the order of operations

Every row replacement can also be written as left multiplication by an elementary matrix. For example, $R_2\leftarrow R_2-3R_1$ on a two-row matrix is accomplished by
$$
E=\begin{bmatrix}1&0\\-3&1\end{bmatrix},\qquad EA=U.
$$
The inverse $E^{-1}=\begin{bmatrix}1&0\\3&1\end{bmatrix}$ restores the original row, so $A=E^{-1}U$. In this simple example, $L=E^{-1}$. With several eliminations, $L$ combines the reverse elementary operations in the right order. This is why the multiplier recorded in $L$ has the same sign as the number $m$ in $R_i\leftarrow R_i-mR_j$, while the elimination matrix itself stores $-m$.

### Reading the multipliers without losing their signs

The factor $U$ remembers what remains after elimination. The factor $L$ remembers *how the eliminated entries used to depend on earlier rows*. For a three-row matrix, if the replacements are $R_2\leftarrow R_2-m_{21}R_1$, $R_3\leftarrow R_3-m_{31}R_1$, and then $R_3\leftarrow R_3-m_{32}R_2$, the factor is

$$
L=\begin{bmatrix}1&0&0\\m_{21}&1&0\\m_{31}&m_{32}&1\end{bmatrix}.
$$

Record each multiplier **at the time it is used**. It is not generally the entry currently shown in the matrix after several operations. If a multiplier is negative, it stays negative in $L$ even though the elimination operation subtracts that multiplier. To check a proposed factorization, multiply $LU$ using ordinary row-by-column multiplication. If one product entry disagrees with $A$, revisit the multiplier from that row.

No row swaps are permitted for this simple $LU$ procedure. A zero leading pivot may force a swap; then write $PA=LU$, where $P$ is a permutation matrix recording the swap. This is not merely a software detail: trying to divide by a zero pivot is undefined, and silently interchanging rows gives the factorization of a *different* matrix unless $P$ is recorded.

:::example[Example 2.30 — Two by two factorization and one right-hand side]
For $A=\begin{bmatrix}2&1\\4&5\end{bmatrix}$ find $L,U$, then solve $A\mathbf x=(4,14)^T$.

::::answer[Answer]
**Answer:** $L=\begin{bmatrix}1&0\\2&1\end{bmatrix}$, $U=\begin{bmatrix}2&1\\0&3\end{bmatrix}$ and $\mathbf x=(1,2)^T$.

1. $L=\begin{bmatrix}1&0\\2&1\end{bmatrix}$, $U=\begin{bmatrix}2&1\\0&3\end{bmatrix}$ and $\mathbf x=(1,2)^T$.

2. Eliminate the entry below the first pivot. The multiplier is $m_{21}=4/2=2$, so

3. Evaluate each displayed entry using the corresponding definition:

    $$
    \begin{bmatrix}2&1\\4&5\end{bmatrix}\xrightarrow{R_2\leftarrow R_2-2R_1}
    \begin{bmatrix}2&1\\0&3\end{bmatrix}=U.
    $$

4. Put the multiplier in $L$ below the diagonal. Check $LU=\begin{bmatrix}2&1\\4&2+3\end{bmatrix}=A$. Forward substitution gives $y_1=4$ and $2y_1+y_2=14$, so $y_2=14-8=6$. Back substitution gives $3x_2=6$, so $x_2=2$, and $2x_1+x_2=4$, so $x_1=(4-2)/2=1$. The check $A(1,2)^T=(4,14)^T$ completes the problem.
::::
:::

:::example[Example 2.31 — A zero pivot requires a permutation]
Can $A=\begin{bmatrix}0&1\\2&3\end{bmatrix}$ be factored without swaps as $LU$ with $L$ unit lower triangular? Find a correct permuted factorization.

::::answer[Answer]
**Answer:** Not without swapping rows. One factorization is $PA=LU$ with $P=\begin{bmatrix}0&1\\1&0\end{bmatrix}$, $L=I$ and $U=\begin{bmatrix}2&3\\0&1\end{bmatrix}$.

1. Not without swapping rows. One factorization is $PA=LU$ with $P=\begin{bmatrix}0&1\\1&0\end{bmatrix}$, $L=I$ and $U=\begin{bmatrix}2&3\\0&1\end{bmatrix}$.

2. The first potential pivot $a_{11}=0$ cannot eliminate the $2$ below it. In fact, an unswapped unit-lower $L=\begin{bmatrix}1&0\\\ell&1\end{bmatrix}$ and upper $U=\begin{bmatrix}u_{11}&u_{12}\\0&u_{22}\end{bmatrix}$ would force $(LU)_{11}=u_{11}=0$ and $(LU)_{21}=\ell u_{11}=0$, contradicting $a_{21}=2$. Swap the rows using $P$. Then $PA=\begin{bmatrix}2&3\\0&1\end{bmatrix}$ is already upper triangular, so $L=I$, $U=PA$, and $PA=LU$ is verified.
::::
:::

:::example[Example 2.32 — A three by three factorization and two substitutions]
For $A=\begin{bmatrix}1&2&1\\3&8&4\\2&5&4\end{bmatrix}$, factor $A=LU$ and solve $A\mathbf x=(3,11,10)^T$.

::::answer[Answer]
**Answer:** $L=\begin{bmatrix}1&0&0\\3&1&0\\2&\tfrac12&1\end{bmatrix}$, $U=\begin{bmatrix}1&2&1\\0&2&1\\0&0&\tfrac32\end{bmatrix}$ and $\mathbf x=(1,0,2)^T$.

1. $L=\begin{bmatrix}1&0&0\\3&1&0\\2&\tfrac12&1\end{bmatrix}$, $U=\begin{bmatrix}1&2&1\\0&2&1\\0&0&\tfrac32\end{bmatrix}$ and $\mathbf x=(1,0,2)^T$.

2. First eliminate below column 1. Use $R_2\leftarrow R_2-3R_1$, obtaining $(0,2,1)$, and $R_3\leftarrow R_3-2R_1$, obtaining $(0,1,2)$. The intermediate matrix is

3. Evaluate each displayed entry using the corresponding definition:

    $$
    \begin{bmatrix}1&2&1\\0&2&1\\0&1&2\end{bmatrix}.
    $$

4. Eliminate the second-column entry of row 3 with multiplier $m_{32}=1/2$:

5. Use the displayed equality to perform the next algebraic operation:

    $$
    R_3\leftarrow R_3-\tfrac12R_2:\quad(0,1,2)-(0,1,\tfrac12)=(0,0,\tfrac32).
    $$

6. The multipliers $3,2,1/2$ occupy positions $(2,1),(3,1),(3,2)$ in $L$. For $L\mathbf y=(3,11,10)^T$, the equations are $y_1=3$, $3y_1+y_2=11$ giving $y_2=2$, and $2y_1+\tfrac12y_2+y_3=10$ giving $y_3=3$. For $U\mathbf x=(3,2,3)^T$, bottom-up substitution gives $\tfrac32x_3=3\Rightarrow x_3=2$, $2x_2+x_3=2\Rightarrow x_2=0$, and $x_1+2x_2+x_3=3\Rightarrow x_1=1$. Check $A(1,0,2)^T=(3,11,10)^T$.
::::
:::

### Practice problems

:::problem[Problem 2.39 — Back substitution]{difficulty=easy}
Solve $\begin{bmatrix}2&1\\0&3\end{bmatrix}\mathbf x=(7,6)^T$ by back substitution.

::::solution[Solution]
**Answer:** $\mathbf x=(5/2,2)^T$. Bottom row: $3x_2=6\Rightarrow x_2=2$. Top row: $2x_1+x_2=7\Rightarrow2x_1=5\Rightarrow x_1=5/2$. Check $2(5/2)+2=7$.

1. Because $U$ is upper triangular, start with the last equation $3x_2=6$ and only then solve the first row for $x_1$.

2. $\mathbf x=(5/2,2)^T$. Bottom row: $3x_2=6\Rightarrow x_2=2$. Top row: $2x_1+x_2=7\Rightarrow2x_1=5\Rightarrow x_1=5/2$. Check $2(5/2)+2=7$.

3. After $x_2=2$, the first equation becomes $2x_1=7-2=5$. Thus $x_1=5/2$. Check both original rows: $2(5/2)+2=7$ and $3(2)=6$.
::::
:::

:::problem[Problem 2.40 — Factor a two-by-two matrix]{difficulty=standard}
Find $L,U$ for $A=\begin{bmatrix}3&2\\6&7\end{bmatrix}$ with no row swaps.

::::solution[Solution]
**Answer:** $L=\begin{bmatrix}1&0\\2&1\end{bmatrix}$ and $U=\begin{bmatrix}3&2\\0&3\end{bmatrix}$.

1. The first pivot is $3$, so the multiplier below it is $6/3=2$. Eliminate $R_2\leftarrow R_2-2R_1$.

2. $L=\begin{bmatrix}1&0\\2&1\end{bmatrix}$ and $U=\begin{bmatrix}3&2\\0&3\end{bmatrix}$. The multiplier is $6/3=2$. Replace $R_2$ by $R_2-2R_1=(0,3)$. Then $LU=\begin{bmatrix}3&2\\6&4+3\end{bmatrix}=A$.

3. The new second row is $(0,7-2(2))=(0,3)$, which belongs in $U$. Put $2$ in $L_{21}$. Multiplying the factors gives back $(6,7)$ as the second row of $A$.
::::
:::

:::problem[Problem 2.41 — Pivot and permutation matrices]{difficulty=challenge}
Explain why $A=\begin{bmatrix}0&1\\2&1\end{bmatrix}$ has no unit-lower $LU$ factorization without row exchanges, and give $P,L,U$ satisfying $PA=LU$.

::::solution[Solution]
**Answer:** $P=\begin{bmatrix}0&1\\1&0\end{bmatrix}$, $L=I$ and $U=\begin{bmatrix}2&1\\0&1\end{bmatrix}$.

1. A unit-lower $L$ has first diagonal entry $1$, so the first pivot of an unpermuted $LU$ factorization is the top-left entry of $A$.

2. $P=\begin{bmatrix}0&1\\1&0\end{bmatrix}$, $L=I$ and $U=\begin{bmatrix}2&1\\0&1\end{bmatrix}$. An unswapped decomposition would make both entries in column 1 equal zero because $u_{11}=0$, contradicting $a_{21}=2$. One row swap gives $PA=U$, which is already upper triangular.

3. Here that entry is zero although there is a nonzero entry below it. Swap the rows with $P$ before elimination, obtaining $PA=\begin{bmatrix}2&1\\0&1\end{bmatrix}=IU$.
::::
:::

:::problem[Problem 2.42 — Solve an LU system]{difficulty=standard}
Given $L=\begin{bmatrix}1&0\\-2&1\end{bmatrix}$, $U=\begin{bmatrix}2&0\\0&3\end{bmatrix}$, solve $LU\mathbf x=(4,-2)^T$.

::::solution[Solution]
**Answer:** $\mathbf x=(2,2)^T$.

1. Write $L\mathbf y=(4,-2)^T$ and solve downward: $y_1=4$ and $-2(4)+y_2=-2$, so $y_2=6$.

2. $\mathbf x=(2,2)^T$. First $L\mathbf y=(4,-2)^T$ gives $y_1=4$, $-2y_1+y_2=-2$, hence $y_2=6$. Next $U\mathbf x=(4,6)^T$ gives $2x_1=4\Rightarrow x_1=2$ and $3x_2=6\Rightarrow x_2=2$. Indeed $LU\mathbf x=(4,-2)^T$.

3. Then solve $U\mathbf x=(4,6)^T$ upward: $2x_1=4$ gives $x_1=2$ and $3x_2=6$ gives $x_2=2$. Both equations are satisfied.
::::
:::

:::problem[Problem 2.43 — Forward and back substitution]{difficulty=standard}
Use the $LU$ factors from Example 2.6 to solve $A\mathbf x=(4,5,6)^T$.

::::solution[Solution]
**Answer:** $\mathbf x=(1,1,1)^T$.

1. Using the given factors, first solve the lower triangular system for $\mathbf y$; substitute the values immediately into the next row instead of skipping fractions.

2. $\mathbf x=(1,1,1)^T$. For $L\mathbf y=(4,5,6)^T$, $y_1=4$, $\frac12(4)+y_2=5\Rightarrow y_2=3$, and $-\frac12(4)+\frac53(3)+y_3=6\Rightarrow-2+5+y_3=6\Rightarrow y_3=3$. Next $U\mathbf x=(4,3,3)^T$: $3x_3=3\Rightarrow x_3=1$, $3x_2=3\Rightarrow x_2=1$, and $2x_1+4(1)-2(1)=4\Rightarrow x_1=1$. Verify with the original $A$.

3. The displayed forward solve gives $\mathbf y=(4,3,3)^T$. Back substitution gives $x_3=3/3=1$, then $x_2=3/3=1$, and finally $x_1=1$ from the first upper row.
::::
:::

## 2.8 Subspaces of $\mathbb{R}^n$

:::callout-intuition[Why subspaces matter]
An arbitrary collection of vectors is difficult to describe. A **subspace** is a collection that never leaves itself when vectors are added or multiplied by scalars. That makes it suitable for solving linear equations. A line through the origin, a plane through the origin, and the entire $\mathbb R^n$ are subspaces; a parallel-shifted line is not. Two sets arise from every matrix: the outputs it can produce, $\operatorname{Col}A$, and the inputs it sends to zero, $\operatorname{Nul}A$. Written tests ask you to connect these descriptions to ordinary row reduction.
:::

:::definition[Definition 2.5 — Subspace]
A subset $H$ of $\mathbb R^n$ is a **subspace** if (1) $\mathbf0\in H$; (2) $\mathbf u+\mathbf v\in H$ whenever $\mathbf u,\mathbf v\in H$; and (3) $c\mathbf u\in H$ whenever $\mathbf u\in H$ and $c\in\mathbb R$. The last two conditions say that every linear combination of members of $H$ remains in $H$.
:::

A fast exam test is to try the zero vector first. If zero is missing, stop: the set is not a subspace. If zero is present, you still must check both kinds of closure. For a set defined by a **homogeneous** linear equation, all three properties follow from linearity. For an inequality such as $x\geq0$, a negative scalar often gives the counterexample. A span is always a subspace: adding two combinations of the same vectors merely adds their coefficients.

<figure class="fig">
<svg class="fig-hue-3" viewBox="0 0 440 240" role="img" aria-label="The line y equals x crosses the origin while its parallel shift y equals x plus one does not.">
<line class="fig-axis" x1="90" y1="130" x2="330" y2="130"/><line class="fig-axis" x1="210" y1="232" x2="210" y2="28"/>
<line class="fig-curve" x1="115" y1="225" x2="305" y2="35"/><line class="fig-curve-alt" x1="108" y1="198" x2="278" y2="28"/>
<text class="fig-label" x="265" y="50">y=x+1</text><text class="fig-label" x="260" y="104">y=x</text><text class="fig-label" x="214" y="146">0</text>
</svg>
<figcaption>The line $y=x$ passes through zero and is a subspace; $y=x+1$ misses zero, so it is not. Passing through zero is necessary, but closure still needs justification.</figcaption>
</figure>

:::example[Example 2.33 — Is a set a subspace?]
Is $H=\{(a,b,c)^T:a+b+c=0\}$ a subspace of $\mathbb R^3$?

::::answer[Answer]
**Answer:** Yes. It is the plane $a+b+c=0$ through the origin.

1. Identify pivot positions from an echelon form; select original columns for a column-space basis and free-variable special solutions for the null space.

2. Yes. It is the plane $a+b+c=0$ through the origin.

3. **Zero:** $0+0+0=0$, so $\mathbf0\in H$.

4. **Addition:** Suppose $\mathbf u=(a,b,c)^T$ and $\mathbf v=(d,e,f)^T$ belong to $H$. Then $a+b+c=0$ and $d+e+f=0$. Adding the coordinates of $\mathbf u+\mathbf v$ gives $(a+d)+(b+e)+(c+f)=0+0=0$. Therefore $\mathbf u+\mathbf v\in H$.

5. **Scalar multiplication:** If $k$ is any real number, then $ka+kb+kc=k(a+b+c)=k0=0$, so $k\mathbf u\in H$. All three conditions hold. In fact $H=\operatorname{Nul}\begin{bmatrix}1&1&1\end{bmatrix}$.

6. Check by substitution in $A\mathbf{x}=0$ and by the rank-nullity count, where applicable.
::::
:::

:::definition[Definition 2.6 — Column Space and Null Space]
For an $m\times n$ matrix $A=[\mathbf a_1\ \cdots\ \mathbf a_n]$,

$$
\operatorname{Col}A=\operatorname{Span}\{\mathbf a_1,\ldots,\mathbf a_n\}
=\{A\mathbf x:\mathbf x\in\mathbb R^n\}\subseteq\mathbb R^m,
$$

$$
\operatorname{Nul}A=\{\mathbf x\in\mathbb R^n:A\mathbf x=\mathbf0\}\subseteq\mathbb R^n.
$$

Both are subspaces. A vector $\mathbf b$ lies in $\operatorname{Col}A$ **if and only if** $A\mathbf x=\mathbf b$ is consistent. A vector $\mathbf x$ lies in $\operatorname{Nul}A$ **if and only if** multiplication yields $A\mathbf x=\mathbf0$.
:::

The different ambient spaces are not notation trivia. If $A$ has three rows and five columns, outputs $A\mathbf x$ have three entries and inputs $\mathbf x$ have five. Consequently $\operatorname{Col}A\subseteq\mathbb R^3$, while $\operatorname{Nul}A\subseteq\mathbb R^5$. **Membership in Col** is a consistency question, so augment $[A\mid\mathbf b]$. **Membership in Nul** is a direct substitution question, so multiply $A\mathbf x$ and compare against the zero vector.

<figure class="fig">
<svg class="fig-hue-4" viewBox="0 0 440 240" role="img" aria-label="Column space is a horizontal line in R2; null space is a plane in R3, using two separate coordinate systems.">
<line class="fig-axis" x1="12" y1="120" x2="188" y2="120"/><line class="fig-axis" x1="100" y1="184" x2="100" y2="56"/><line class="fig-curve" x1="26" y1="120" x2="174" y2="120"/>
<text class="fig-label" x="59" y="54">Col A in R²</text>
<line class="fig-axis" x1="270" y1="120" x2="390" y2="120"/><line class="fig-axis" x1="330" y1="180" x2="330" y2="60"/>
<path class="fig-fill" d="M302 165 L362 105 L358 75 L298 135 Z"/><path class="fig-guide" d="M302 165 L362 105 L358 75 L298 135 Z"/>
<text class="fig-label" x="268" y="54">Nul A in R³</text>
</svg>
<figcaption>For $A=\begin{bmatrix}1&1&0\\0&0&0\end{bmatrix}$, $\operatorname{Col}A=\operatorname{Span}\{(1,0)^T\}$ is a line in $\mathbb R^2$, but $\operatorname{Nul}A=\{(s,-s,t)^T\}$ is a plane in $\mathbb R^3$.</figcaption>
</figure>


### Why these two spaces are subspaces

You do not have to memorize two unrelated closure proofs. They both follow from $A(\mathbf u+\mathbf v)=A\mathbf u+A\mathbf v$ and $A(c\mathbf u)=cA\mathbf u$. For the null space, if $A\mathbf u=0$ and $A\mathbf v=0$, then $A(\mathbf u+\mathbf v)=0+0=0$. Also, $A(c\mathbf u)=c0=0$, and $A0=0$. Those are exactly the three subspace conditions. For the column space, suppose $\mathbf u=A\mathbf x$ and $\mathbf v=A\mathbf y$ for some input vectors. Their sum is $A(\mathbf x+\mathbf y)$, which is another possible output. Their scalar multiple is $A(c\mathbf x)$, likewise an output. Finally $A0=0$ proves that the zero output is present. The proofs also show why the column space is a **set of outputs**, not a list of input coefficient vectors.

A span is the same kind of object viewed from its generators. If $\mathbf v_1,\ldots,\mathbf v_p$ are given and $A=[\mathbf v_1\ \cdots\ \mathbf v_p]$, then $\operatorname{Span}\{\mathbf v_1,\ldots,\mathbf v_p\}=\operatorname{Col}A$. To decide whether a target $\mathbf b$ belongs to that span, you can always solve $A\mathbf x=\mathbf b$. This is exactly the column-space membership test even if the word "column space" never appears in the question.

### Why row reduction answers one question but changes the other space

Elementary row operations replace $A$ with $EA$ for an invertible matrix $E$. For null space, $EA\mathbf x=0$ if and only if $A\mathbf x=E^{-1}0=0$. Thus $\operatorname{Nul}(EA)=\operatorname{Nul}A$. That is why every intermediate echelon form can be used to compute special solutions. For column space, however, an output $A\mathbf x=\mathbf b$ becomes $EA\mathbf x=E\mathbf b$. The output is changed by $E$; in general the actual column space changes. Only the dependence relationships among columns survive. If column 3 is twice column 1 before elimination, it remains twice column 1 afterward, so **pivot positions** can be recovered from an echelon matrix, but the original vectors are still the basis candidates.


### What a nontrivial null space tells you

Suppose $A\mathbf x=\mathbf b$ has one solution $\mathbf x_0$. For every null-space vector $\mathbf h$,
$$
A(\mathbf x_0+\mathbf h)=A\mathbf x_0+A\mathbf h=\mathbf b+0=\mathbf b.
$$
Thus adding a null-space vector produces another solution. Conversely, if $\mathbf x_1$ is any other solution, subtracting gives $A(\mathbf x_1-\mathbf x_0)=\mathbf b-\mathbf b=0$, so $\mathbf x_1-\mathbf x_0\in\operatorname{Nul}A$. All solutions therefore have the form
$$
\mathbf x=\mathbf x_0+\mathbf h,\qquad \mathbf h\in\operatorname{Nul}A.
$$
The null space tells you **how many ways the inputs can differ while giving the same output**. This is also the connection to the one-to-one property from the Invertible Matrix Theorem: if the null space contains only zero, no two distinct inputs produce the same output. If it contains a nonzero vector, then $\mathbf x$ and $\mathbf x+\mathbf h$ always produce the same result.

For example, with $A=\begin{bmatrix}1&1\end{bmatrix}$ and $\mathbf b=(3)$, one solution is $\mathbf x_0=(3,0)^T$. The null space consists of $(-t,t)^T$. Therefore every solution is $(3,0)^T+(-t,t)^T=(3-t,t)^T$. Substitute directly: $A(3-t,t)^T=(3-t)+t=3$. The output belongs to $\operatorname{Col}A$, but the input producing it is not unique.

### A two-question exam workflow

When you read "Is $\mathbf b$ in Col $A$?", write $[A\mid\mathbf b]$ immediately. A pivot in the last augmented column with zeros to its left means an inconsistent row $0=c$ for $c\ne0$. No inconsistency means membership; if the question also asks for a representation, back-substitute to give the coefficients. When you read "Is $\mathbf x$ in Nul $A$?", first compare dimensions: the candidate must have as many entries as $A$ has **columns**. Then calculate $A\mathbf x$ row by row. A single nonzero entry proves nonmembership.

In a true/false question, beware of the statement "row operations do not affect linear dependence among columns." That statement is **true**, because multiplication by invertible $E$ preserves equations among column vectors. The superficially similar statement "row operations preserve the column space" is **false**: they act on every output vector. Recognizing the difference is more reliable than memorizing a letter from a review key.

:::example[Example 2.34 — Test membership in the column space]
For $A=\begin{bmatrix}1&2\\0&1\\1&3\end{bmatrix}$, determine whether $\mathbf b=(5,2,7)^T$ and $\mathbf c=(5,2,8)^T$ are in $\operatorname{Col}A$.

::::answer[Answer]
**Answer:** $\mathbf b\in\operatorname{Col}A$; $\mathbf c\notin\operatorname{Col}A$.

1. Identify pivot positions from an echelon form; select original columns for a column-space basis and free-variable special solutions for the null space.

2. $\mathbf b\in\operatorname{Col}A$; $\mathbf c\notin\operatorname{Col}A$.

3. Augment $A$ with $\mathbf b$ and row-reduce:

4. Perform the next displayed row operation, applying it to every entry on both sides of the augmented matrix.

    $$
    \left[\begin{array}{cc|c}1&2&5\\0&1&2\\1&3&7\end{array}\right]
    \xrightarrow{R_3\leftarrow R_3-R_1}
    \left[\begin{array}{cc|c}1&2&5\\0&1&2\\0&1&2\end{array}\right]
    \xrightarrow{R_3\leftarrow R_3-R_2}
    \left[\begin{array}{cc|c}1&2&5\\0&1&2\\0&0&0\end{array}\right].
    $$

5. There is no contradictory row. The equations are $x_2=2$ and $x_1+2x_2=5$. Thus $x_1=5-4=1$ and $A(1,2)^T=(5,2,7)^T$. For $\mathbf c$, only the last augmented entry changes:

6. Perform the next displayed row operation, applying it to every entry on both sides of the augmented matrix.

    $$
    \left[\begin{array}{cc|c}1&2&5\\0&1&2\\1&3&8\end{array}\right]
    \xrightarrow{R_3-R_1}
    \left[\begin{array}{cc|c}1&2&5\\0&1&2\\0&1&3\end{array}\right]
    \xrightarrow{R_3-R_2}
    \left[\begin{array}{cc|c}1&2&5\\0&1&2\\0&0&1\end{array}\right].
    $$

7. The last row states $0=1$, which is impossible. This proves nonmembership without guessing coefficients.

8. Check by substitution in $A\mathbf{x}=0$ and by the rank-nullity count, where applicable.
::::
:::

:::example[Example 2.35 — Test membership in the null space]
Let $A=\begin{bmatrix}1&2&-1\\0&1&1\end{bmatrix}$. Are $\mathbf u=(-3,1,-1)^T$ and $\mathbf v=(1,0,1)^T$ in $\operatorname{Nul}A$?

::::answer[Answer]
**Answer:** $\mathbf u\in\operatorname{Nul}A$ and $\mathbf v\notin\operatorname{Nul}A$.

1. Identify pivot positions from an echelon form; select original columns for a column-space basis and free-variable special solutions for the null space.

2. $\mathbf u\in\operatorname{Nul}A$ and $\mathbf v\notin\operatorname{Nul}A$.

3. Multiply, rather than augment:

4. Evaluate each displayed entry using the corresponding definition:

    $$
    A\mathbf u=\begin{bmatrix}(1)(-3)+(2)(1)+(-1)(-1)\\(0)(-3)+(1)(1)+(1)(-1)\end{bmatrix}
    =\begin{bmatrix}0\\0\end{bmatrix}.
    $$

5. For the second candidate,

6. Evaluate each displayed entry using the corresponding definition:

    $$
    A\mathbf v=\begin{bmatrix}(1)(1)+(2)(0)+(-1)(1)\\(0)(1)+(1)(0)+(1)(1)\end{bmatrix}
    =\begin{bmatrix}0\\1\end{bmatrix}\ne\mathbf0.
    $$

7. A nonzero output in even one component is enough to rule out null-space membership. We did not need an inverse or an RREF to answer either question.

8. Check by substitution in $A\mathbf{x}=0$ and by the rank-nullity count, where applicable.
::::
:::

:::theorem[Subspace and basis method]
The span of any finite set of vectors is a subspace. The columns of $A$ span $\operatorname{Col}A$; a basis is obtained by selecting the pivot-column **positions** from an echelon form and then taking those columns from the **original** $A$. The special-solution vectors obtained by assigning one free variable the value $1$ at a time form a basis for $\operatorname{Nul}A$.
:::

:::example[Example 2.36 — Both bases from one row reduction]
Find bases for $\operatorname{Col}A$ and $\operatorname{Nul}A$ where $A=\begin{bmatrix}1&2&0&3\\0&0&1&-1\\1&2&1&2\end{bmatrix}$.

::::answer[Answer]
**Answer:** $\operatorname{Col}A$ has basis $\{(1,0,1)^T,(0,1,1)^T\}$ and $\operatorname{Nul}A$ has basis $\{(-2,1,0,0)^T,(-3,0,1,1)^T\}$.

1. Identify pivot positions from an echelon form; select original columns for a column-space basis and free-variable special solutions for the null space.

2. $\operatorname{Col}A$ has basis $\{(1,0,1)^T,(0,1,1)^T\}$ and $\operatorname{Nul}A$ has basis $\{(-2,1,0,0)^T,(-3,0,1,1)^T\}$.

3. Subtract row 1 from row 3 and then row 2 from the new row 3:

4. Evaluate each displayed entry using the corresponding definition:

    $$
    \begin{bmatrix}1&2&0&3\\0&0&1&-1\\1&2&1&2\end{bmatrix}
    \xrightarrow{R_3\leftarrow R_3-R_1}
    \begin{bmatrix}1&2&0&3\\0&0&1&-1\\0&0&1&-1\end{bmatrix}
    \xrightarrow{R_3\leftarrow R_3-R_2}
    \begin{bmatrix}1&2&0&3\\0&0&1&-1\\0&0&0&0\end{bmatrix}.
    $$

5. Pivot positions: columns 1 and 3. Read **original** columns 1 and 3 to get the stated basis for $\operatorname{Col}A$. For null space, the equations are $x_1+2x_2+3x_4=0$ and $x_3-x_4=0$. Set $x_2=s$, $x_4=t$. Then $x_1=-2s-3t$ and $x_3=t$, so

6. Evaluate each displayed entry using the corresponding definition:

    $$
    \mathbf x=s\begin{bmatrix}-2\\1\\0\\0\end{bmatrix}+t\begin{bmatrix}-3\\0\\1\\1\end{bmatrix}.
    $$

7. There is one special solution per free variable. Both bases came from the same elimination, but they were extracted in two different ways.

8. Check by substitution in $A\mathbf{x}=0$ and by the rank-nullity count, where applicable.
::::
:::

:::callout-pitfall[Pitfalls in §2.8]
- **Membership is not the same as finding a basis:** $\mathbf b\in\operatorname{Col}A$ needs consistency of $[A\mid\mathbf b]$; $\mathbf x\in\operatorname{Nul}A$ needs $A\mathbf x=0$.
- **Never use the reduced columns as a basis for the original column space.** Row operations preserve pivot-column relationships, not the actual column-space vectors.
- **Do not test subspace closure on one convenient pair.** To prove closure, start with arbitrary members; to disprove it, one counterexample suffices.
:::

### Practice problems

:::problem[Problem 2.44 — Subspace test]{difficulty=easy}
Is $H=\{(x,y):x\geq0,\ y\geq0\}$ a subspace of $\mathbb R^2$?

::::solution[Solution]
**Answer:** No.

1. A subspace must contain $0$ and remain closed under every real scalar multiplication. The nonnegative quadrant contains $0$, so test a negative scalar.

2. No. The vector $(1,1)$ belongs to $H$, but multiplying by $-1$ gives $(-1,-1)$, whose coordinates do not satisfy either nonnegative restriction. Hence closure under scalar multiplication fails.

3. Check by substitution in $A\mathbf{x}=0$ and by the rank-nullity count, where applicable.

4. Take $(1,1)\in H$ and multiply by $-1$. The result $(-1,-1)\notin H$ because both coordinates violate the nonnegative restrictions. Hence scalar closure fails.
::::
:::

:::problem[Problem 2.45 — Null-space basis from free variables]{difficulty=standard}
Find a basis for $\operatorname{Nul}A$ where $A=\begin{bmatrix}1&2&-1&3\\0&0&1&-2\end{bmatrix}$.

::::solution[Solution]
**Answer:** $\{(-2,1,0,0)^T,(-1,0,2,1)^T\}$.

1. For $\operatorname{Nul}A$, solve $A\mathbf x=0$ and choose the nonpivot variables as parameters. There is one basis vector per free variable.

2. $\{(-2,1,0,0)^T,(-1,0,2,1)^T\}$.
The matrix is already in echelon form. Pivot columns are 1 and 3, with free variables $x_2=s$ and $x_4=t$. Row 2 gives $x_3-2x_4=0$, so $x_3=2t$. Row 1 gives $x_1+2s-x_3+3t=0$, hence $x_1=-2s+2t-3t=-2s-t$. Therefore

3. Evaluate each displayed entry using the corresponding definition:

    $$
    \mathbf x=s\begin{bmatrix}-2\\1\\0\\0\end{bmatrix}+t\begin{bmatrix}-1\\0\\2\\1\end{bmatrix}.
    $$

4. Setting $(s,t)=(1,0)$ and $(0,1)$ gives the two basis vectors.

5. Here $x_2=s$ and $x_4=t$. The second equation gives $x_3=2t$, and the first gives $x_1=-2s-t$. Set $(s,t)=(1,0)$ and $(0,1)$ to obtain the displayed basis.
::::
:::

:::problem[Problem 2.46 — Inconsistent column-space membership]{difficulty=standard}
Is $\mathbf b=(3,4,5)^T$ in $\operatorname{Col}A$ for $A=\begin{bmatrix}1&0&2\\0&1&1\\1&1&3\end{bmatrix}$?

::::solution[Solution]
**Answer:** No.

1. A vector lies in $\operatorname{Col}A$ exactly when $A\mathbf x=\mathbf b$ is consistent. Test this with an augmented matrix.

2. No. Augment and eliminate:

3. Perform the next displayed row operation, applying it to every entry on both sides of the augmented matrix.

    $$
    \left[\begin{array}{rrr|r}1&0&2&3\\0&1&1&4\\1&1&3&5\end{array}\right]
    \xrightarrow{R_3\leftarrow R_3-R_1}
    \left[\begin{array}{rrr|r}1&0&2&3\\0&1&1&4\\0&1&1&2\end{array}\right]
    \xrightarrow{R_3\leftarrow R_3-R_2}
    \left[\begin{array}{rrr|r}1&0&2&3\\0&1&1&4\\0&0&0&-2\end{array}\right].
    $$

4. The equation $0=-2$ is impossible, so the system $A\mathbf x=\mathbf b$ has no solution.

5. Row elimination forces the contradictory row $[0\ 0\ 0\mid-2]$, meaning the last equation is $0=-2$. No coefficients can produce $\mathbf b$, so the answer is no.
::::
:::

:::problem[Problem 2.47 — Test closure under scalar multiplication]{difficulty=easy}
Is $H=\{(x,y)^T:y=3x-2\}$ a subspace of $\mathbb R^2$? Give the shortest valid reason.

::::solution[Solution]
**Answer:** No.

1. Every linear subspace contains the origin. Test $(0,0)$ in the defining equation before spending time checking both closure laws.

2. No. At $(x,y)=(0,0)$, the defining condition becomes $0=3(0)-2=-2$, which is false. The zero vector is absent. There is no need to test closure.

3. Check the product size before comparing the computed matrix entries.

4. Substitution gives $0=3(0)-2=-2$, which is false. The set is an affine line that misses the origin; therefore it cannot be a subspace.
::::
:::

:::problem[Problem 2.48 — Null-space membership]{difficulty=standard}
For $A=\begin{bmatrix}1&2&1\\0&1&-1\end{bmatrix}$, decide whether $\mathbf x=(1,1,-3)^T$ is in $\operatorname{Nul}A$.

::::solution[Solution]
**Answer:** No.

1. A vector lies in $\operatorname{Nul}A$ if and only if direct multiplication gives the zero vector. Multiply each row by the proposed column.

2. No. Calculate

3. Evaluate each displayed entry using the corresponding definition:

    $$
    A\mathbf x=\begin{bmatrix}1(1)+2(1)+1(-3)\\0(1)+1(1)+(-1)(-3)\end{bmatrix}
    =\begin{bmatrix}0\\4\end{bmatrix}\ne\mathbf0.
    $$

4. The first coordinate being zero is not sufficient; **every** coordinate must be zero.

5. The first row yields $1+2(1)+(-3)=0$, but the second yields $1-(-3)=4$. Since $A\mathbf x=(0,4)^T\ne0$, null-space membership fails.
::::
:::

:::problem[Problem 2.49 — Column-space membership]{difficulty=standard}
For $A=\begin{bmatrix}1&1\\2&2\\0&0\end{bmatrix}$, does $\mathbf b=(3,6,0)^T$ belong to $\operatorname{Col}A$? Give coefficients.

::::solution[Solution]
**Answer:** Yes.

1. The two columns of $A$ are identical, namely $\mathbf a_1=\mathbf a_2=(1,2,0)^T$. The column space consists of all scalar multiples of that vector.

2. Yes. Augment:

3. Perform the next displayed row operation, applying it to every entry on both sides of the augmented matrix.

    $$
    \left[\begin{array}{cc|c}1&1&3\\2&2&6\\0&0&0\end{array}\right]
    \xrightarrow{R_2\leftarrow R_2-2R_1}
    \left[\begin{array}{cc|c}1&1&3\\0&0&0\\0&0&0\end{array}\right].
    $$

4. Set $x_2=0$, so $x_1=3$. Thus $A(3,0)^T=(3,6,0)^T$, proving membership.

5. Because $\mathbf b=3(1,2,0)^T$, choose coefficients $(3,0)^T$ or $(0,3)^T$. Either gives $A\mathbf x=\mathbf b$, proving membership.
::::
:::

:::problem[Problem 2.50 — Subspace and null-space proof]{difficulty=challenge}
True or false, with justification: (a) The columns of a $3\times5$ matrix belong to $\mathbb R^5$. (b) If $\mathbf0\in H$, then $H$ is a subspace. (c) $\operatorname{Nul}A$ is a subspace for every matrix $A$.

::::solution[Solution]
**Answer:** (a) False; each column has three entries, so columns live in $\mathbb R^3$. (b) False; $H=\{(0,0)^T,(1,1)^T\}$ contains zero but fails scalar closure because $2(1,1)^T\notin H$. (c) True; $A\mathbf0=0$, and linearity gives $A(\mathbf u+\mathbf v)=A\mathbf u+A\mathbf v=0$ and $A(c\mathbf u)=cA\mathbf

1. For (a), inspect the number of rows; for (b), remember that containing zero is necessary but not sufficient; for (c), use linearity of matrix multiplication.

2. (a) False; each column has three entries, so columns live in $\mathbb R^3$. (b) False; $H=\{(0,0)^T,(1,1)^T\}$ contains zero but fails scalar closure because $2(1,1)^T\notin H$. (c) True; $A\mathbf0=0$, and linearity gives $A(\mathbf u+\mathbf v)=A\mathbf u+A\mathbf v=0$ and $A(c\mathbf u)=cA\mathbf u=0$ for null-space vectors.

3. Closure of the null space follows because $A(\mathbf u+\mathbf v)=A\mathbf u+A\mathbf v=0$ and $A(c\mathbf u)=cA\mathbf u=0$ whenever $\mathbf u,\mathbf v$ are in the kernel.
::::
:::


## 2.9 Dimension and Rank

:::callout-intuition[How many independent directions survive?]
A line contains infinitely many vectors but has only **one independent direction**; a plane has two. That number is its **dimension**. The rank of a matrix counts independent output directions, while its nullity counts independent input directions that get sent to zero. Neither number measures how many entries are nonzero. They are counted by pivots and free variables, so the same row reduction answers both questions. A basis is also a coordinate ruler: it tells you how to describe a vector with a unique list of coefficients.
:::

:::definition[Definition 2.7 — Basis and Dimension]
A **basis** $\mathcal B=\{\mathbf b_1,\ldots,\mathbf b_p\}$ for a subspace $H$ is a set of vectors that is linearly independent and spans $H$. The **dimension** $\dim H=p$ is the number of vectors in a basis. Every basis for the same subspace has the same number of members. By definition, $\dim\{\mathbf0\}=0$ and $\dim\mathbb R^n=n$.
:::

Because basis vectors are independent, a vector has only one coefficient list in that basis. If $\sum c_i\mathbf b_i=\sum d_i\mathbf b_i$, subtracting gives $\sum(c_i-d_i)\mathbf b_i=0$. Independence forces $c_i-d_i=0$ for every index. This uniqueness is what ordinary Cartesian coordinates and nonstandard basis coordinates have in common.

:::definition[Coordinate vector relative to a basis]
For $\mathcal B=\{\mathbf b_1,\ldots,\mathbf b_p\}$, write $\mathbf x=c_1\mathbf b_1+\cdots+c_p\mathbf b_p$. Its **coordinate vector** is
$$
[\mathbf x]_{\mathcal B}=\begin{bmatrix}c_1\\\vdots\\c_p\end{bmatrix}.
$$
If $B=[\mathbf b_1\ \cdots\ \mathbf b_p]$, then $B[\mathbf x]_{\mathcal B}=\mathbf x$. When $B$ is square and invertible, $[\mathbf x]_{\mathcal B}=B^{-1}\mathbf x$; on a written exam, reducing $[B\mid\mathbf x]$ is often quicker than explicitly computing $B^{-1}$.
:::

<figure class="fig">
<svg class="fig-hue-5" viewBox="0 0 440 240" role="img" aria-label="Skew coordinate grid with basis b1 horizontal, b2 diagonal and x equal to b1 plus twice b2.">
<line class="fig-axis" x1="78" y1="192" x2="340" y2="192"/><line class="fig-axis" x1="90" y1="206" x2="90" y2="28"/>
<line class="fig-gridline" x1="90" y1="192" x2="207" y2="75"/><line class="fig-gridline" x1="129" y1="192" x2="246" y2="75"/><line class="fig-gridline" x1="168" y1="192" x2="285" y2="75"/><line class="fig-gridline" x1="207" y1="192" x2="324" y2="75"/>
<line class="fig-gridline" x1="129" y1="153" x2="285" y2="153"/><line class="fig-gridline" x1="168" y1="114" x2="324" y2="114"/><line class="fig-gridline" x1="207" y1="75" x2="363" y2="75"/>
<line class="fig-curve" x1="90" y1="192" x2="129" y2="192"/><line class="fig-curve-alt" x1="90" y1="192" x2="129" y2="153"/>
<line class="fig-curve" x1="90" y1="192" x2="207" y2="114"/><path class="fig-arrow" d="M195 115 L207 114 L201 125"/>
<path class="fig-guide" d="M90 192 L129 192 L207 114"/>
<text class="fig-label" x="130" y="214">b1</text><text class="fig-label" x="134" y="145">b2</text><text class="fig-label-em" x="210" y="107">x</text>
</svg>
<figcaption>With $\mathcal B=\{(1,0)^T,(1,1)^T\}$, $\mathbf x=(3,2)^T$ has coordinates $[\mathbf x]_{\mathcal B}=(1,2)^T$ because $\mathbf x=1\mathbf b_1+2\mathbf b_2$. The coefficients measure travel along a skewed grid.</figcaption>
</figure>

:::example[Example 2.37 — Coordinate representation]
Let $\mathcal B=\{(1,0)^T,(1,1)^T\}$ and $\mathbf x=(3,2)^T$. Find $[\mathbf x]_{\mathcal B}$.

::::answer[Answer]
**Answer:** $[\mathbf x]_{\mathcal B}=(1,2)^T$.

1. $[\mathbf x]_{\mathcal B}=(1,2)^T$.

2. Write $c_1(1,0)^T+c_2(1,1)^T=(3,2)^T$. Comparing coordinates gives $c_1+c_2=3$ and $c_2=2$. The augmented calculation is

3. Perform the next displayed row operation, applying it to every entry on both sides of the augmented matrix.

    $$
    \left[\begin{array}{cc|c}1&1&3\\0&1&2\end{array}\right]
    \xrightarrow{R_1\leftarrow R_1-R_2}
    \left[\begin{array}{cc|c}1&0&1\\0&1&2\end{array}\right].
    $$

4. Hence $c_1=1$ and $c_2=2$. Check: $(1,0)^T+2(1,1)^T=(3,2)^T$. Notice that the original vector and its coordinate vector are not generally equal.
::::
:::

:::definition[Definition 2.8 — Rank and Nullity]
For $A$ with $m$ rows and $n$ columns, $\operatorname{rank}A=\dim\operatorname{Col}A$ is the number of pivots. The **nullity** $\dim\operatorname{Nul}A$ is the number of free variables, namely the number of columns without pivots.
:::

:::theorem[Theorem 2.5 — Rank Theorem (Rank-Nullity)]
For every $m\times n$ matrix $A$,
$$
\operatorname{rank}A+\dim\operatorname{Nul}A=n.
$$
The right-hand side is the **number of columns**, not the number of rows. Each variable is either a pivot variable or a free variable, so the two counts necessarily add to $n$.
:::

:::theorem[Theorem 2.6 — Pivot columns, bases, and row space]
If pivot positions occur in columns $j_1,\ldots,j_r$ of an echelon form of $A$, the corresponding **original** columns $\mathbf a_{j_1},\ldots,\mathbf a_{j_r}$ form a basis for $\operatorname{Col}A$. The nonzero rows of any echelon form form a basis for the row space. Hence $\dim\operatorname{Row}A=\dim\operatorname{Col}A=r$, although the spaces need not live in the same ambient space.
:::

:::example[Example 2.38 — Rank, nullity, and bases]
For $A=\begin{bmatrix}1&2&0&4\\0&0&1&3\\0&0&0&0\end{bmatrix}$, find rank, nullity and bases for $\operatorname{Col}A$ and $\operatorname{Nul}A$.

::::answer[Answer]
**Answer:** rank $=2$, nullity $=2$; $\operatorname{Col}A$ basis $\{(1,0,0)^T,(0,1,0)^T\}$; $\operatorname{Nul}A$ basis $\{(-2,1,0,0)^T,(-4,0,-3,1)^T\}$.

1. Identify pivot positions from an echelon form; select original columns for a column-space basis and free-variable special solutions for the null space.

2. rank $=2$, nullity $=2$; $\operatorname{Col}A$ basis $\{(1,0,0)^T,(0,1,0)^T\}$; $\operatorname{Nul}A$ basis $\{(-2,1,0,0)^T,(-4,0,-3,1)^T\}$.

3. The matrix is in echelon form. Leading entries in row 1 and row 2 are in columns 1 and 3. Those are pivot columns, so rank $=2$. There are four columns total; therefore nullity $=4-2=2$. Take the original columns 1 and 3 as the column-space basis.

4. To obtain the null-space basis, solve $A\mathbf x=0$. Its nonzero equations are $x_1+2x_2+4x_4=0$ and $x_3+3x_4=0$. Let $x_2=s$ and $x_4=t$. Then $x_1=-2s-4t$ and $x_3=-3t$, so

5. Evaluate each displayed entry using the corresponding definition:

    $$
    \mathbf x=s\begin{bmatrix}-2\\1\\0\\0\end{bmatrix}+t\begin{bmatrix}-4\\0\\-3\\1\end{bmatrix}.
    $$

6. The two independent special solutions span all homogeneous solutions. Finally $\dim\operatorname{Col}A+\dim\operatorname{Nul}A=2+2=4$ agrees with the number of columns.

7. Check by substitution in $A\mathbf{x}=0$ and by the rank-nullity count, where applicable.
::::
:::


### The basis theorem and why the number of pivots matters

If a subspace has dimension $p$, a set of exactly $p$ independent vectors in the subspace must span it, and a spanning set of exactly $p$ vectors must be independent. This is the **basis theorem**. It is valuable when a problem gives many vectors and asks for a basis: you can reduce their column matrix, take the pivot columns, and know that the result both spans the same space and is independent. You do not have to solve a second, separate independence problem. If three vectors span a plane of dimension two, some vector in the list is redundant; if only one vector is offered for a two-dimensional plane, it cannot span that plane.

For a concrete check, let $\mathbf a_1=(1,2)^T$, $\mathbf a_2=(2,4)^T$, and $\mathbf a_3=(0,1)^T$. The matrix with these columns is

$$
A=\begin{bmatrix}1&2&0\\2&4&1\end{bmatrix}
\xrightarrow{R_2\leftarrow R_2-2R_1}
\begin{bmatrix}1&2&0\\0&0&1\end{bmatrix}.
$$

Columns 1 and 3 are pivot columns. Therefore $\{(1,2)^T,(0,1)^T\}$ is a basis of $\operatorname{Col}A=\mathbb R^2$. The column $(2,4)^T$ was redundant because it equals $2(1,2)^T$. The zero vector would also be redundant in a proposed basis: any set containing zero is dependent, even if it spans the intended space.

### The rank bound for rectangular matrices

A pivot must occupy a different row and a different column from every other pivot. Therefore $\operatorname{rank}A\leq\min(m,n)$ for any $m\times n$ matrix. Combining that bound with rank-nullity gives $\dim\operatorname{Nul}A=n-\operatorname{rank}A\geq n-m$ when $n>m$. As a consequence, any homogeneous system with more unknowns than equations has a nonzero solution. This does **not** imply that every nonhomogeneous equation $A\mathbf x=\mathbf b$ is consistent: consistency still depends on whether $\mathbf b$ is an output of $A$.

Use that inequality as an instant reasonableness check. A $3\times8$ matrix can never have rank $5$. Its nullity is at least $8-3=5$. If you obtain an answer with nullity $3$, you probably counted rows instead of columns or missed free variables.


### Three quick checks before submitting a rank answer

First confirm **where the spaces live**. The column space of an $m\times n$ matrix is a subspace of $\mathbb R^m$, and its null space is a subspace of $\mathbb R^n$. Second check the bound $0\leq\operatorname{rank}A\leq\min(m,n)$; your number of pivot columns cannot exceed either dimension. Third verify that rank plus nullity is exactly $n$ and that your null-space basis has one vector per free variable. These checks are almost free once the echelon form is written.

For a square matrix, the Invertible Matrix Theorem lets you reverse the reasoning: full rank means nullity zero, and nullity zero means independent columns. For a rectangular matrix, full **column** rank can still mean nullity zero without giving an inverse. For example, $A=\begin{bmatrix}1\\0\end{bmatrix}$ has rank one and nullity zero, but it is $2\times1$, so it cannot be invertible as a square matrix. Meanwhile a full **row** rank $1\times2$ matrix such as $B=\begin{bmatrix}1&0\end{bmatrix}$ has rank one and nullity one. These two shapes are a common true/false trap because they look nearly identical.

### Coordinates as an invertible map

For a basis $\mathcal B$ of $\mathbb R^n$, its column matrix $B$ is square and invertible. The two coordinate operations undo each other: $B[\mathbf x]_{\mathcal B}=\mathbf x$ and $[\mathbf x]_{\mathcal B}=B^{-1}\mathbf x$. They preserve addition and scaling. Indeed, if $\mathbf x=B\mathbf c$ and $\mathbf y=B\mathbf d$, then $\mathbf x+\mathbf y=B(\mathbf c+\mathbf d)$ and $t\mathbf x=B(t\mathbf c)$. Uniqueness of basis coordinates forces $[\mathbf x+\mathbf y]_{\mathcal B}=\mathbf c+\mathbf d$ and $[t\mathbf x]_{\mathcal B}=t\mathbf c$.

A basis for a *proper subspace* $H\subset\mathbb R^n$ has only $p<n$ vectors, so the matrix $B$ is $n\times p$ and cannot have an ordinary inverse. Its coordinates still exist and are unique for vectors **inside** $H$: solve the consistent system $B\mathbf c=\mathbf x$. If the augmented system is inconsistent, the vector is outside $H$ and $[\mathbf x]_{\mathcal B}$ is not defined.

:::example[Example 2.39 — Full elimination and the original-column trap]
Find the rank, nullity, and a basis for each space for $A=\begin{bmatrix}1&2&3&0\\2&4&6&1\\0&0&0&1\end{bmatrix}$.

::::answer[Answer]
**Answer:** rank $=2$, nullity $=2$; $\operatorname{Col}A$ basis $\{(1,2,0)^T,(0,1,1)^T\}$; $\operatorname{Nul}A$ basis $\{(-2,1,0,0)^T,(-3,0,1,0)^T\}$.

1. Identify pivot positions from an echelon form; select original columns for a column-space basis and free-variable special solutions for the null space.

2. rank $=2$, nullity $=2$; $\operatorname{Col}A$ basis $\{(1,2,0)^T,(0,1,1)^T\}$; $\operatorname{Nul}A$ basis $\{(-2,1,0,0)^T,(-3,0,1,0)^T\}$.

3. Row-reduce from the first row:

4. Evaluate each displayed entry using the corresponding definition:

    $$
    \begin{bmatrix}1&2&3&0\\2&4&6&1\\0&0&0&1\end{bmatrix}
    \xrightarrow{R_2\leftarrow R_2-2R_1}
    \begin{bmatrix}1&2&3&0\\0&0&0&1\\0&0&0&1\end{bmatrix}
    \xrightarrow{R_3\leftarrow R_3-R_2}
    \begin{bmatrix}1&2&3&0\\0&0&0&1\\0&0&0&0\end{bmatrix}.
    $$

5. The pivots occupy columns 1 and 4. **Return to $A$** to read those two columns, not $(1,0,0)^T$ and $(0,1,0)^T$ from the echelon form. For $A\mathbf x=0$, the equations are $x_1+2x_2+3x_3=0$ and $x_4=0$. Choose $x_2=s$, $x_3=t$, obtaining $x_1=-2s-3t$ and $x_4=0$. Thus the displayed null basis follows. Two pivots plus two free variables equals four columns.

6. Check by substitution in $A\mathbf{x}=0$ and by the rank-nullity count, where applicable.
::::
:::

:::example[Example 2.40 — Rectangular matrices and the rank theorem]
A $5\times7$ matrix has rank $3$. Find the nullity, dimensions of the spaces, and the largest possible rank of a $5\times7$ matrix.

::::answer[Answer]
**Answer:** nullity $=4$, $\dim\operatorname{Col}A=3$, $\dim\operatorname{Nul}A=4$; largest possible rank $=5$.

1. Identify pivot positions from an echelon form; select original columns for a column-space basis and free-variable special solutions for the null space.

2. nullity $=4$, $\dim\operatorname{Col}A=3$, $\dim\operatorname{Nul}A=4$; largest possible rank $=5$.

3. Seven columns mean seven unknowns in $A\mathbf x=0$. Exactly three variables are pivot variables, leaving $7-3=4$ free. Therefore $3+4=7$. Because the columns of a $5\times7$ matrix are vectors in $\mathbb R^5$, they cannot span more than five independent directions. Consequently $\operatorname{rank}A\leq\min(5,7)=5$. It is possible to have rank five, for example with the first five columns the $5\times5$ identity and the final two zero columns.

4. Check by substitution in $A\mathbf{x}=0$ and by the rank-nullity count, where applicable.
::::
:::

:::example[Example 2.41 — Basis coordinates inside a plane in three-space]
Let $\mathcal B=\{(1,0,1)^T,(0,1,1)^T\}$ and $\mathbf x=(2,3,5)^T$. Show $\mathbf x$ belongs to $H=\operatorname{Span}\mathcal B$ and find $[\mathbf x]_{\mathcal B}$.

::::answer[Answer]
**Answer:** $\mathbf x\in H$ and $[\mathbf x]_{\mathcal B}=(2,3)^T$.

1. Identify pivot positions from an echelon form; select original columns for a column-space basis and free-variable special solutions for the null space.

2. $\mathbf x\in H$ and $[\mathbf x]_{\mathcal B}=(2,3)^T$.

3. Set up one column for each basis vector:

4. Perform the next displayed row operation, applying it to every entry on both sides of the augmented matrix.

    $$
    \left[\begin{array}{cc|c}1&0&2\\0&1&3\\1&1&5\end{array}\right]
    \xrightarrow{R_3\leftarrow R_3-R_1}
    \left[\begin{array}{cc|c}1&0&2\\0&1&3\\0&1&3\end{array}\right]
    \xrightarrow{R_3\leftarrow R_3-R_2}
    \left[\begin{array}{cc|c}1&0&2\\0&1&3\\0&0&0\end{array}\right].
    $$

5. The coefficient solution is unique: $c_1=2$, $c_2=3$. Indeed $2(1,0,1)^T+3(0,1,1)^T=(2,3,5)^T$. The vector $\mathbf x$ is in $\mathbb R^3$, but its coordinate vector has only two entries because $H$ has dimension two.

6. Check by substitution in $A\mathbf{x}=0$ and by the rank-nullity count, where applicable.
::::
:::

:::callout-pitfall[Pitfalls in §2.9]
- **Rank plus nullity is the number of columns**, even when the matrix is rectangular.
- **Original columns for Col; special solutions for Nul.** Reduced columns generally do not span the original column space.
- **$[\mathbf x]_{\mathcal B}$ is not ordinarily $\mathbf x$.** It is a list of coefficients, with one entry per basis vector.
- **A nonzero single row is not automatically rank one:** count pivots after elimination, not merely nonzero entries in $A$.
:::

The Invertible Matrix Theorem adds a useful square-matrix shortcut: if $A$ is $n\times n$, then $\operatorname{rank}A=n$, $\operatorname{Nul}A=\{0\}$, and $\operatorname{Col}A=\mathbb R^n$ are equivalent. For a rectangular matrix, rank and nullity still obey the rank theorem, but you cannot conclude that a nonsquare matrix has an ordinary inverse.

### Practice problems

:::problem[Problem 2.51 — Rank-nullity]{difficulty=easy}
A $5\times7$ matrix $A$ has rank $3$. What is its nullity?

::::solution[Solution]
**Answer:** $4$.

1. The rank-nullity theorem counts the number of columns, not the number of rows: $\operatorname{rank}A+\operatorname{nullity}A=7$.

2. $4$. Rank plus nullity equals the number of columns. Thus $3+\operatorname{nullity}A=7$, so $\operatorname{nullity}A=7-3=4$.

3. Check by substitution in $A\mathbf{x}=0$ and by the rank-nullity count, where applicable.

4. Substitute the given rank $3$ and solve $3+\operatorname{nullity}A=7$, so nullity $=7-3=4$. This is possible because a $5\times7$ matrix can have rank $3$.
::::
:::

:::problem[Problem 2.52 — Column-space basis]{difficulty=standard}
Find a basis for the column space of $A=\begin{bmatrix}1&3&5&0\\2&6&10&0\\1&3&5&1\end{bmatrix}$.

::::solution[Solution]
**Answer:** $\{(1,2,1)^T,(0,0,1)^T\}$.

1. Use row operations to locate pivot columns, but return to the original matrix for the actual column-space basis vectors.

2. $\{(1,2,1)^T,(0,0,1)^T\}$.

3. Evaluate each displayed entry using the corresponding definition:

    $$
    \begin{bmatrix}1&3&5&0\\2&6&10&0\\1&3&5&1\end{bmatrix}
    \xrightarrow{R_2\leftarrow R_2-2R_1,\ R_3\leftarrow R_3-R_1}
    \begin{bmatrix}1&3&5&0\\0&0&0&0\\0&0&0&1\end{bmatrix}
    \xrightarrow{R_2\leftrightarrow R_3}
    \begin{bmatrix}1&3&5&0\\0&0&0&1\\0&0&0&0\end{bmatrix}.
    $$

4. Pivot columns 1 and 4 yield the two **original** columns in the answer, not the columns of this echelon matrix.

5. The second column is three times the first and the third is five times the first. Column 4 is independent of column 1, so columns 1 and 4 form the basis.
::::
:::

:::problem[Problem 2.53 — Find a basis]{difficulty=challenge}
If $A$ is $n\times n$ and $\operatorname{rank}A=n$, what does the Rank-Nullity Theorem tell you? Connect this to the Invertible Matrix Theorem.

::::solution[Solution]
**Answer:** nullity $=0$ and $A$ is invertible.

1. Rank $n$ means a pivot in every column of the square $n\times n$ matrix. Apply rank-nullity with the number of columns $n$.

2. nullity $=0$ and $A$ is invertible. The theorem gives $n+\operatorname{nullity}A=n$, so nullity $=0$. Hence $A\mathbf x=0$ has only $\mathbf x=0$. By the Invertible Matrix Theorem for **square** matrices, this is equivalent to invertibility.

3. Then $n+\operatorname{nullity}A=n$, so the kernel has dimension zero. Only the trivial homogeneous solution remains, which is equivalent to invertibility by the Invertible Matrix Theorem.
::::
:::

:::problem[Problem 2.54 — Use the rank theorem]{difficulty=easy}
If a $4\times6$ matrix has nullity $2$, what is its rank?

::::solution[Solution]
**Answer:** $4$.

1. A $4\times6$ matrix has six input variables, so rank-nullity reads $\operatorname{rank}A+\operatorname{nullity}A=6$.

2. $4$. With six columns, $\operatorname{rank}A+2=6$, giving rank $=4$. This equals the maximum possible rank for four rows.

3. Check by substitution in $A\mathbf{x}=0$ and by the rank-nullity count, where applicable.

4. Given nullity $2$, subtract to get rank $=6-2=4$. This is consistent with the upper bound of four pivots imposed by the four rows.
::::
:::

:::problem[Problem 2.55 — Bases of column and null spaces]{difficulty=standard}
For $A=\begin{bmatrix}1&1&0\\0&0&1\end{bmatrix}$, give bases for $\operatorname{Col}A$ and $\operatorname{Nul}A$, then find their dimensions.

::::solution[Solution]
**Answer:** Col basis $\{(1,0)^T,(0,1)^T\}$, Nul basis $\{(-1,1,0)^T\}$; dimensions $2$ and $1$.

1. Inspect the two pivot columns: column 1 gives $(1,0)^T$ and column 3 gives $(0,1)^T$. These span the entire column space.

2. Col basis $\{(1,0)^T,(0,1)^T\}$, Nul basis $\{(-1,1,0)^T\}$; dimensions $2$ and $1$.
Pivots lie in columns 1 and 3. Original columns 1 and 3 form the column-space basis. In $A\mathbf x=0$, the equations are $x_1+x_2=0$ and $x_3=0$. Let $x_2=t$. Then $x_1=-t$, $x_3=0$, and $\mathbf x=t(-1,1,0)^T$. Rank plus nullity gives $2+1=3$ columns.

3. The homogeneous equations are $x_1+x_2=0$ and $x_3=0$. Set $x_2=t$ to obtain $\mathbf x=t(-1,1,0)^T$. Hence the dimensions are $2$ and $1$.
::::
:::

:::problem[Problem 2.56 — Coordinates relative to a basis]{difficulty=standard}
With $\mathcal B=\{(2,1)^T,(1,1)^T\}$, find $[(5,3)^T]_{\mathcal B}$.

::::solution[Solution]
**Answer:** $(2,1)^T$.

1. Coordinates relative to $\mathcal B$ are the coefficients $c_1,c_2$ in $c_1(2,1)+c_2(1,1)=(5,3)$.

2. $(2,1)^T$. The coefficient equations are $2c_1+c_2=5$ and $c_1+c_2=3$. Subtract the second from the first: $c_1=2$. Substitute into $c_1+c_2=3$: $c_2=1$. Check $2(2,1)^T+1(1,1)^T=(5,3)^T$.

3. Solve $2c_1+c_2=5$ and $c_1+c_2=3$. Subtraction gives $c_1=2$, then $c_2=1$. Verify $2(2,1)+(1,1)=(5,3)$.
::::
:::

:::problem[Problem 2.57 — Rank and nullity true or false]{difficulty=challenge}
True or false: (a) A $4\times7$ matrix can have rank $5$. (b) If $\operatorname{rank}A=\operatorname{nullity}A$ for an $m\times6$ matrix, both must equal $3$. (c) Row-equivalent matrices have the same column space. (d) An invertible $n\times n$ matrix has nullity $0$.

::::solution[Solution]
**Answer:** (a) False because rank $\leq4$ rows. (b) True because the two equal integers add to $6$, so each is $3$. (c) False: row operations preserve pivot-column positions but can alter the actual column vectors and their span.

1. For each claim, check the rank bound $r\le\min(m,n)$ and the rank-nullity identity $r+\operatorname{nullity}A=n$.

2. (a) False because rank $\leq4$ rows. (b) True because the two equal integers add to $6$, so each is $3$. (c) False: row operations preserve pivot-column positions but can alter the actual column vectors and their span. For example $[1\ 0]^T$ and $[2\ 0]^T$ have the same span, but the column spaces of $\begin{bmatrix}1\\0\end{bmatrix}$ and $\begin{bmatrix}0\\1\end{bmatrix}$ are different, although swapping their rows makes the matrices row-equivalent. (d) True: invertibility forces a pivot in every column and therefore no free variables.

3. For (c), row operations may move the column-space vectors; for (d), an invertible square matrix has a pivot in every column and therefore no free variables or nontrivial kernel.
::::
:::


:::summary
## Chapter Summary

### Key results

#### Matrix operations

**The matrix product $AB$** is defined entry by entry as

$$
(AB)_{ij} = \sum_{k} a_{ik}b_{kj}
$$

that is, entry $(i,j)$ of $AB$ is the dot product of **row $i$ of $A$** with
 **column $j$ of $B$**. The product exists only when the number of columns of $A$ equals the
 number of rows of $B$: an $m \times n$ times an $n \times p$ gives an $m \times p$.

**Matrix multiplication is not commutative.** In general $AB \neq BA$ — often one of the two
 is not even defined. Nor can you cancel: $AB = AC$ does **not** give $B = C$, and $AB = 0$
 does **not** mean that $A = 0$ or $B = 0$.

**The transpose reverses the order of a product:**

$$
(AB)^T = B^T A^T
$$

#### Inverses

**A square matrix $A$ is invertible** when there is a matrix $A^{-1}$ with
 $AA^{-1} = A^{-1}A = I$. For $2 \times 2$ there is a formula:

$$
\begin{bmatrix}a & b\\ c & d\end{bmatrix}^{-1}
= \frac{1}{ad - bc}\begin{bmatrix}d & -b\\ -c & a\end{bmatrix}
\qquad \text{provided } ad - bc \neq 0
$$

Swap the diagonal entries, negate the off-diagonal ones, divide by the determinant. If
 $ad - bc = 0$ the matrix has no inverse.

**For larger matrices, row-reduce.** Form the augmented matrix $[\,A \mid I\,]$ and reduce
 until the left half is the identity:

$$
[\,A \mid I\,] \;\longrightarrow\; [\,I \mid A^{-1}\,]
$$

If the left half cannot be reduced to $I$, then $A$ is not invertible.

**Inverting a product also reverses the order:**

$$
(AB)^{-1} = B^{-1}A^{-1}, \qquad (A^{-1})^{-1} = A, \qquad (A^T)^{-1} = (A^{-1})^T
$$

**The Invertible Matrix Theorem.** For an $n \times n$ matrix $A$, the following are *all
 equivalent* — all true together, or all false together:

- (a) $A$ is invertible.
- (b) $A$ is row equivalent to $I_n$.
- (c) $A$ has $n$ pivot positions — one in every row and every column.
- (d) $A\mathbf{x} = \mathbf{0}$ has only the trivial solution.
- (e) The columns of $A$ are linearly independent.
- (f) The transformation $\mathbf{x} \mapsto A\mathbf{x}$ is one-to-one.
- (g) $A\mathbf{x} = \mathbf{b}$ has a solution for **every** $\mathbf{b} \in \mathbb{R}^n$.
- (h) The columns of $A$ span $\mathbb{R}^n$.
- (i) The transformation $\mathbf{x} \mapsto A\mathbf{x}$ is onto.
- (j) There is an $n \times n$ matrix $C$ with $CA = I$.
- (k) There is an $n \times n$ matrix $D$ with $AD = I$.
- (l) $A^T$ is invertible.
- (m) The columns of $A$ form a basis of $\mathbb{R}^n$.
- (n) $\text{Col}\,A = \mathbb{R}^n$.
- (o) $\text{rank}\,A = n$.
- (p) $\dim\text{Nul}\,A = 0$.
- (q) $\text{Nul}\,A = \{\mathbf{0}\}$.

**It applies only to square matrices.** For a square matrix one-to-one and onto stand or fall
 together; for a non-square one they come apart, and a matrix can be one without the other.

**LU factorization** writes $A = LU$ with $L$ lower triangular (ones on its diagonal) and $U$
 upper triangular. To solve $A\mathbf{x} = \mathbf{b}$, split it in two: solve
 $L\mathbf{y} = \mathbf{b}$ downward by forward substitution, then $U\mathbf{x} = \mathbf{y}$
 upward by back substitution. Worth doing when many different $\mathbf{b}$ share one $A$,
 since the factorization is computed once and reused.

#### Subspaces, bases and rank

**A subset $H$ of $\mathbb{R}^n$ is a subspace** when all three of these hold:

1. $\mathbf{0} \in H$;
2. $H$ is closed under addition — if $\mathbf{u}, \mathbf{v} \in H$ then
   $\mathbf{u} + \mathbf{v} \in H$;
3. $H$ is closed under scalar multiplication — if $\mathbf{u} \in H$ and $c$ is any scalar
   then $c\mathbf{u} \in H$.

Failing the first is the quickest disqualification: a line or plane that misses the origin is
 not a subspace.

**The column space $\text{Col}(A)$** is the span of the columns of $A$ — exactly those
 $\mathbf{b}$ for which $A\mathbf{x} = \mathbf{b}$ is consistent. **The null space
 $\text{Nul}(A)$** is the solution set of $A\mathbf{x} = \mathbf{0}$. Both are subspaces, but
 they live in different places: for an $m \times n$ matrix,
 $\text{Col}(A) \subseteq \mathbb{R}^m$ while $\text{Nul}(A) \subseteq \mathbb{R}^n$.

**A basis** is a linearly independent set that spans the subspace, and its size is the
 **dimension**. To find each one:

- **Basis for $\text{Col}(A)$:** row-reduce to find which columns hold pivots, then take
  those columns **of the original $A$**, not of the reduced matrix. Row operations change the
  column space, so the reduced columns are the wrong vectors — the reduction only tells you
  *which* columns to take.
- **Basis for $\text{Nul}(A)$:** solve $A\mathbf{x} = \mathbf{0}$ and write the answer in
  parametric vector form. The vectors attached to the free variables are the basis, one for
  each free variable.

**The Rank–Nullity Theorem.** Writing $\text{rank}(A) = \dim \text{Col}(A)$, the number of
 pivot columns, and $\text{nullity}(A) = \dim \text{Nul}(A)$, the number of free variables,
 then for any $m \times n$ matrix:

$$
\text{rank}(A) + \text{nullity}(A) = n
$$

where $n$ is the number of **columns**, not rows. Every column is either a pivot column or a
 free one, so the two counts have to add up to the total.

### If you remember nothing else

The Invertible Matrix Theorem is the central theorem of this chapter: for a square matrix,
 invertibility, full rank, independent columns, unique solutions, and surjectivity are all
 **the same condition**. Rank-Nullity then quantifies exactly how "far from
 invertible" a non-square or singular matrix is.
:::

## Mixed Practice

:::problem[Problem M.1 — Transpose a product]{difficulty=easy}
Compute $(AB)^T$ for $A=\begin{bmatrix}1&2\\0&3\end{bmatrix}$, $B=\begin{bmatrix}1&0\\2&1\end{bmatrix}$ two ways: (a) compute $AB$ then transpose; (b) compute $B^TA^T$. Verify they match.

::::solution[Solution]
**Answer:** $(AB)^T=B^TA^T=\begin{bmatrix}5&6\\2&3\end{bmatrix}$.

1. Compute $AB$ by row-column dot products and transpose the result. Then form $B^TA^T$ in the reversed order and multiply that pair independently.

2. $AB=\begin{bmatrix}5&2\\6&3\end{bmatrix}$, so $(AB)^T=\begin{bmatrix}5&6\\2&3\end{bmatrix}$.

3. $B^T=\begin{bmatrix}1&2\\0&1\end{bmatrix}$, $A^T=\begin{bmatrix}1&0\\2&3\end{bmatrix}$, $B^TA^T=\begin{bmatrix}5&6\\2&3\end{bmatrix}\,\checkmark$.

4. For the $(1,1)$ entry, $AB$ gives $1(1)+2(2)=5$; its transpose keeps $5$ in position $(1,1)$. All four entries match, confirming the transpose rule.

::::
:::

:::problem[Problem M.2 — Rank and invertibility]{difficulty=standard}
Suppose $A$ is $4\times4$ and the equation $A\mathbf{x}=\mathbf{b}$ has a unique solution for some specific $\mathbf{b}$. Must it have a unique solution for *every* $\mathbf{b}\in\mathbb{R}^4$? Explain using the IMT.

::::solution[Solution]
**Answer:** Yes; $A$ is invertible and every right-hand side has a unique solution.

1. Having a unique solution for even one right-hand side means the corresponding homogeneous system has no nontrivial solution; otherwise adding a null vector would produce another solution.

2. A unique solution means no free variables, which means all 4 columns are pivot columns, which means rank = 4. By the IMT, $A$ is invertible. And for an invertible $4\times4$ matrix, $A\mathbf{x}=\mathbf{b}$ has the unique solution $\mathbf{x}=A^{-1}\mathbf{b}$ for **every** $\mathbf{b}\in\mathbb{R}^4$. Yes.

3. Thus there are no free variables, all four columns pivot, and the square matrix is invertible. For every other $\mathbf b$, the unique solution is $A^{-1}\mathbf b$.
::::
:::

:::problem[Problem M.3 — LU elimination and solve]{difficulty=standard}
Find the LU factorization of $A=\begin{bmatrix}2&6&2\\-1&-3&2\\4&12&1\end{bmatrix}$ and solve $A\mathbf{x}=\begin{pmatrix}2\\0\\5\end{pmatrix}$.

::::solution[Solution]
**Answer:** $L=\begin{bmatrix}1&0&0\\-1/2&1&0\\2&-1&1\end{bmatrix}$, $U=\begin{bmatrix}2&6&2\\0&0&3\\0&0&0\end{bmatrix}$; $A\mathbf{x}=\mathbf b$ has **no solution**.

1. Use the first pivot $a_{11}=2$. To eliminate the entry $-1$ in row 2, the multiplier is $m_{21}=(-1)/2=-\frac12$. Apply $R_2\leftarrow R_2+\frac12R_1$: $[-1,-3,2]+\frac12[2,6,2]=[0,0,3]$.

2. For row 3, the multiplier is $m_{31}=4/2=2$. Apply $R_3\leftarrow R_3-2R_1$: $[4,12,1]-2[2,6,2]=[0,0,-3]$. The second column has no pivot, so the next pivot is $3$ in row 2, column 3.

3. To clear the $-3$ beneath that pivot, use $m_{32}=(-3)/3=-1$ and $R_3\leftarrow R_3-(-1)R_2=R_3+R_2$. Then $[0,0,-3]+[0,0,3]=[0,0,0]$, giving $U=\begin{bmatrix}2&6&2\\0&0&3\\0&0&0\end{bmatrix}$.

4. Record the three elimination multipliers below the diagonal: $L=\begin{bmatrix}1&0&0\\-\frac12&1&0\\2&-1&1\end{bmatrix}$. Check multiplication row by row: $1R_1(U)=[2,6,2]$; $-\frac12R_1(U)+R_2(U)=[-1,-3,2]$; $2R_1(U)-R_2(U)+R_3(U)=[4,12,1]$. Thus $LU=A$ exactly.

5. Solve $L\mathbf y=\mathbf b$ by forward substitution: $y_1=2$; $-\frac12(2)+y_2=0$ gives $y_2=1$; $2(2)-1(1)+y_3=5$ gives $y_3=2$. Therefore $\mathbf y=(2,1,2)^T$.

6. Back substitution in $U\mathbf x=\mathbf y$ starts with the final row $0x_1+0x_2+0x_3=2$, or $0=2$, a contradiction. Hence the original system is inconsistent and **has no solution**. Check directly: row 3 $-\frac32$ times row 1 $+$ row 2 has a zero coefficient row, but its right-hand side is $5-\frac32(2)+0=2\ne0$.
::::
:::

:::problem[Problem M.4 — Rank bound]{difficulty=challenge}
Let $A$ be $m\times n$ with $\text{rank}(A) = r$. What are the possible values of $\dim\,\text{Col}(A)$ and $\dim\,\text{Nul}(A)$? What constraints do $m$ and $n$ impose?

::::solution[Solution]
**Answer:** $\dim\operatorname{Col}(A)=r$, $\dim\operatorname{Nul}(A)=n-r$, with $0\le r\le\min(m,n)$.

1. Each pivot determines one basis direction in the column space, so $\dim\operatorname{Col}A=r$. The number of free variables equals the number of columns minus pivots.

2. $\dim\,\text{Col}(A) = r$ (number of pivot columns). Since pivots correspond to both rows and columns: $r \leq m$ (at most one pivot per row) and $r \leq n$ (at most one pivot per column), so $r \leq \min(m,n)$.

3. $\dim\,\text{Nul}(A) = n-r$ by Rank-Nullity. This is $\geq 0$, consistent with $r\leq n$.

4. So: $0 \leq r \leq \min(m,n)$, $\dim\,\text{Col}(A) = r$, $\dim\,\text{Nul}(A) = n-r$.

5. Consequently $\dim\operatorname{Nul}A=n-r$, with $0\le r\le\min(m,n)$. Check that these dimensions sum to $n$, as required by rank-nullity.
::::
:::

:::problem[Problem M.5 — Impossible nullity]{difficulty=challenge}
Is it possible for a $4\times 6$ matrix to have null space of dimension 1? Explain using the Rank-Nullity Theorem.

::::solution[Solution]
**Answer:** No; rank would be $5$, exceeding the four rows.

1. For a $4\times6$ matrix, there are six columns but only four rows. Therefore at most four columns can be pivot columns.

2. Rank-Nullity: $\text{rank}+\text{nullity}=6$. If nullity $=1$, then rank $=5$. But rank $\leq \min(4,6) = 4$. So rank $=5>4$ is impossible. **No**, the null space of a $4\times6$ matrix cannot have dimension 1.

3. If nullity were $1$, rank-nullity would force rank $6-1=5$. A rank-five matrix requires five pivots, impossible with only four rows; the proposed nullity cannot occur.
::::
:::

---

Chapter 2 · Linear Algebra · Based on MA 3113, Mississippi State University.
 Primary source: Dr. Seongjai Kim's lecture notes.
