---
title: "Determinants"
crumb: "Linear Algebra · Chapter 3"
meta:
  - "Est. study time: ~5–6 hours"
  - "MA 3113 · Mississippi State University"
  - "Lay 6e §§3.1–3.3 · sections 3.1 Introduction, 3.2 Properties, 3.3 Applications"
source: "markdown"
---

## Overview

The determinant condenses an entire square matrix into a single number that tells you
 whether the matrix is invertible and how it distorts area (or volume). It's the gatekeeper
 of the Invertible Matrix Theorem — $\det(A) \neq 0$ is equivalent to all the conditions
 you already know from Chapter 2. This chapter covers three sections: how to compute determinants
 (cofactor expansion and row-reduction shortcuts) and the elegant properties that make
 determinants useful in proofs and applications.

:::callout-key[What you'll learn]
- The recursive cofactor expansion formula for determinants of any size
- Shortcuts: triangular matrices, row operations, and when $\det = 0$
- The multiplicative property: $\det(AB) = \det(A)\det(B)$
- Cramer's Rule for solving $A\mathbf{x}=\mathbf{b}$
- Geometric interpretation: determinant = signed area/volume scaling factor
:::

:::callout-tip[Prerequisites]
Ch 2: matrix multiplication, the Invertible Matrix Theorem, row reduction.
:::

## 3.1 Introduction to Determinants

:::callout-intuition[Intuition first]
For a $2\times2$ matrix $\begin{bmatrix}a&b\\c&d\end{bmatrix}$, you already know the
 inverse formula involves $ad - bc$. That quantity is the *determinant*. Geometrically,
 it measures the signed area of the parallelogram formed by the two column vectors. For larger
 matrices, the determinant measures signed volume (or hypervolume), and the formula generalises
 via *cofactor expansion* — breaking a big determinant into smaller ones recursively.
:::

:::definition[Definition 3.1 — Determinant ($1\times1$ and $2\times2$)]
For a $1\times1$ matrix $[a]$, $\det[a] = a$.

For a $2\times2$ matrix:

$$
\det\begin{bmatrix}a&b\\c&d\end{bmatrix} = ad - bc.
$$
:::

### Cofactor expansion for $n\times n$ matrices

:::definition[Definition 3.2 — Minors and Cofactors]
For an $n\times n$ matrix $A$, the **$(i,j)$ minor** $M_{ij}$ is the
 determinant of the $(n-1)\times(n-1)$ matrix obtained by deleting row $i$ and column $j$.
 The **$(i,j)$ cofactor** is

$$
C_{ij} = (-1)^{i+j} M_{ij}.
$$

 The sign pattern $(-1)^{i+j}$ gives a checkerboard of $+$ and $-$:

$$
\begin{bmatrix}+&-&+&-&\cdots\\-&+&-&+\\+&-&+&-\\-&+&-&+\\\vdots&&&\ddots\end{bmatrix}
$$
:::

:::theorem[Theorem 3.1 — Cofactor Expansion]
The determinant of an $n\times n$ matrix $A$ can be computed by expanding along
 *any* row or column. Along row $i$:

$$
\det(A) = a_{i1}C_{i1} + a_{i2}C_{i2} + \cdots + a_{in}C_{in}.
$$

 Along column $j$:

$$
\det(A) = a_{1j}C_{1j} + a_{2j}C_{2j} + \cdots + a_{nj}C_{nj}.
$$
:::

:::callout-tip[Strategy: choose the row/column with the most zeros]
Since any entry multiplied by its cofactor contributes to the sum, entries that are zero
 contribute nothing. Expanding along the row or column with the most zeros minimises work.
:::

### Triangular matrices — the fast lane

:::theorem[Theorem 3.2 — Determinant of a Triangular Matrix]
If $A$ is upper or lower triangular, then $\det(A)$ equals the product of the
 diagonal entries:

$$
\det(A) = a_{11} \cdot a_{22} \cdots a_{nn}.
$$

 In particular, $\det(I_n) = 1$.
:::

### Read the determinant as a measurement, not a magic formula

A matrix $A$ represents a linear map $T(\mathbf{x})=A\mathbf{x}$. In two dimensions, the columns of $A$ are where $T$ sends the standard basis arrows $(1,0)$ and $(0,1)$. The square whose corners are $(0,0),(1,0),(0,1),(1,1)$ becomes a parallelogram whose edges are those columns. If that parallelogram covers six square units, the matrix multiplies **every** planar region's area by six. If it lies on a line, its area is zero and information has been lost: no inverse can rebuild the original square.

The **absolute value** of the determinant measures size. The **sign** answers a different question: whether the order of the column arrows preserves orientation. Moving from the first column to the second counterclockwise gives a positive determinant; reversing their orientation gives a negative one. A negative determinant does *not* mean negative physical area. It means the transformation reverses orientation, much like reflecting a drawing.

<figure class="fig">
<svg class="fig-hue-2" viewBox="0 0 480 190" width="480" height="190" role="img" aria-label="A unit square maps to a slanted parallelogram with area five">
<path class="fig-gridline" d="M20 30H205 M20 65H205 M20 100H205 M20 135H205 M20 170H205 M30 20V175 M65 20V175 M100 20V175 M135 20V175 M170 20V175 M250 30H465 M250 65H465 M250 100H465 M250 135H465 M250 170H465 M270 20V175 M305 20V175 M340 20V175 M375 20V175 M410 20V175 M445 20V175"/>
<path class="fig-axis" d="M30 170H205 M30 170V20 M270 170H470 M270 170V20"/>
<path class="fig-fill" d="M30 170L65 170L65 135L30 135Z"/>
<path class="fig-curve" d="M30 170L65 170L65 135L30 135Z M270 170L375 135L410 65L305 100Z"/>
<path class="fig-fill-alt" d="M270 170L375 135L410 65L305 100Z"/>
<path class="fig-arrow" d="M270 170L375 135 M270 170L305 100"/>
<text class="fig-label" x="55" y="190">unit square</text><text class="fig-label-em" x="340" y="185">area = 5</text><text class="fig-label" x="216" y="98">→</text>
</svg>
<figcaption>The unit square has area $1$; for the matrix with columns $(3,1)$ and $(1,2)$, its image has area $|3\cdot2-1\cdot1|=5$. The sketch shows the change of shape; the determinant, rather than visual counting, gives the exact area of the stated matrix.</figcaption>
</figure>

A quick hand calculation is $\det\begin{bmatrix}3&1\\1&2\end{bmatrix}=3(2)-1(1)=5$. The picture is a reminder of the geometric principle, not a ruler from which you should measure the numerical answer. It is safer to compute the determinant than to guess area from a drawing. For a $3\times3$ matrix, the three columns give three edges of a parallelepiped and $|\det A|$ gives volume. For dimensions larger than three, the same algebra describes higher-dimensional volume even though we cannot draw it.

### Why the $2\times2$ rule has a subtraction

Let $A=\begin{bmatrix}a&b\\c&d\end{bmatrix}$. The transformed horizontal arrow is $(a,c)$ and the transformed vertical arrow is $(b,d)$. The signed parallelogram area is $ad-bc$. In particular, exchanging the columns changes $ad-bc$ into $bc-ad$, its negative. If the second column is twice the first, then $b=2a$ and $d=2c$, so $ad-bc=2ac-2ac=0$. This algebra captures both orientation and dependence without needing a separate theorem every time.

For three or more rows, memorize **where to delete**, not a mysterious list of six products. A minor $M_{ij}$ asks you to remove *one whole row and one whole column*. The cofactor then applies the checkerboard sign. The words *minor* and *cofactor* are not interchangeable: the minor is the small determinant; the cofactor is that number after multiplying by $(-1)^{i+j}$.

<figure class="fig">
<svg class="fig-hue-4" viewBox="0 0 350 160" width="350" height="160" role="img" aria-label="In a three by three matrix cross out row two and column three to form minor M23">
<path class="fig-axis" d="M25 20H195V140H25Z"/>
<path class="fig-gridline" d="M25 60H195 M25 100H195 M82 20V140 M139 20V140"/>
<path class="fig-guide" d="M25 80H195 M168 20V140"/>
<text class="fig-label" x="44" y="48">a₁₁</text><text class="fig-label" x="100" y="48">a₁₂</text><text class="fig-label" x="152" y="48">a₁₃</text>
<text class="fig-label" x="44" y="86">a₂₁</text><text class="fig-label" x="100" y="86">a₂₂</text><text class="fig-label-em" x="152" y="86">a₂₃</text>
<text class="fig-label" x="44" y="126">a₃₁</text><text class="fig-label" x="100" y="126">a₃₂</text><text class="fig-label" x="152" y="126">a₃₃</text>
<text class="fig-label" x="220" y="53">keep rows 1,3</text><text class="fig-label" x="220" y="80">keep cols 1,2</text><text class="fig-label-em" x="220" y="110">sign = −</text>
</svg>
<figcaption>For $M_{23}$ delete row $2$ and column $3$, leaving entries $a_{11},a_{12},a_{31},a_{32}$; because $(-1)^{2+3}=-1$, the cofactor $C_{23}$ is the negative of that minor.</figcaption>
</figure>

### A no-calculator cofactor workflow

First inspect all rows and columns and count the zeros. Next circle the sparsest row or column, marking its *original* indices. Draw a small sign checkerboard if necessary. For each nonzero entry, multiply the entry by its sign, then by the determinant of the matrix left after deletion. Finally add those signed products. Say the signs aloud in your working: “row two, column three, negative.” A correct minor paired with a wrong checkerboard sign still produces a wrong answer.

When expanding a $4\times4$ determinant, each nonzero entry creates a $3\times3$ determinant. Expand that $3\times3$ along its own convenient row or column; its best choice may be different from the first expansion. This is the important recursive idea: *re-evaluate sparsity after every deletion*. Do not write an enormous fixed first-row formula when one row has three zeros.

A triangular matrix is even easier. Every cofactor expansion along its bottom or top row repeatedly peels off diagonal entries, so its determinant is the product of the diagonal entries. A zero diagonal in a triangular matrix immediately forces determinant zero. A nonzero diagonal product means no pivot is missing, hence the matrix is invertible. Note that a non-triangular matrix's diagonal product is generally **not** its determinant: the missing off-diagonal terms may change the value dramatically.

### Quick checks that save exam points

A determinant belongs to a **square** matrix only. For example, asking for $\det\begin{bmatrix}1&2&3\\4&5&6\end{bmatrix}$ is invalid, not zero. If two columns match, the determinant is zero; you should notice this before expanding. If the matrix is triangular, stop and multiply the diagonal. If a small matrix has a zero-rich column, do not row-reduce first merely out of habit. A good final check is to estimate the sign from a second, short expansion if the arithmetic seems suspicious. For a $2\times2$, writing $ad-bc$ visibly before substituting prevents the common error $ad+bc$.


### The six-product trick for $3\times3$, and its limitation

Some instructors teach Sarrus's rule as a memory device for a $3\times3$ determinant. For $A=\begin{bmatrix}a&b&c\\d&e&f\\g&h&i\end{bmatrix}$, it produces $aei+bfg+cdh-ceg-bdi-afh$. It is legitimate for exactly three rows and three columns. The common exam mistake is to extend those diagonals to a $4\times4$ and assume six, eight, or ten diagonal products will give the determinant; there is no analogous simple extension. Cofactor expansion, by contrast, works at every square size.

You can understand Sarrus from first-row expansion rather than memorizing a second formula:

$$
\det A=a(ei-fh)-b(di-fg)+c(dh-eg).
$$

Distribute each term and collect positives and negatives to recover the six products. This derivation is a safety net when you forget a diagonal. A reliable exam solution often shows the first-row cofactor structure even if you do the six little products mentally, because the signs are now unmistakable. If the matrix has a row or column with two zeros, a one-term cofactor expansion is still shorter than Sarrus.

### Determinants distinguish columns from equation right-hand sides

The square matrix $A$ contains the coefficients of $A\mathbf{x}=\mathbf{b}$; the vector $\mathbf{b}$ is not one of its columns unless the problem specifically constructs a replacement matrix. When asked only for $\det A$, do not augment $A$ with $\mathbf{b}$, because the resulting matrix usually has $n+1$ columns and no determinant. Row reduction of $A$ alone is appropriate. When asked for Cramer's Rule in §3.3, you will intentionally form a new *square* matrix by replacing one existing column with $\mathbf{b}$. This distinction prevents an easy but costly setup error.

### Worked examples

:::example[Example 3.1 — Determinant of a 3×3 by cofactor expansion]
Compute $\det(A)$ for $A = \begin{bmatrix}1&2&0\\3&-1&4\\2&0&5\end{bmatrix}$.

::::answer[Answer]
**Answer:** $\det(A) = -19$

1. The cofactor sign comes from $(-1)^{i+j}$; the adjugate is the transpose of the cofactor matrix.

2. Expand along row 1 (has a zero in position $(1,3)$, saving one cofactor):

3. Calculate the next cofactor or determinant term with its indicated sign:

    $$
    \det(A) = 1\cdot C_{11} + 2\cdot C_{12} + 0\cdot C_{13}
    $$

4. Cofactor $C_{11} = (+1)\det\begin{bmatrix}-1&4\\0&5\end{bmatrix} = (+1)((-1)(5)-(4)(0)) = -5$

5. Cofactor $C_{12} = (-1)\det\begin{bmatrix}3&4\\2&5\end{bmatrix} = (-1)((3)(5)-(4)(2)) = (-1)(7) = -7$

6. Calculate the next cofactor or determinant term with its indicated sign:

    $$
    \det(A) = 1(-5) + 2(-7) + 0 = -5 - 14 = -19
    $$

7. Check: expand along a different column
$C_{11} = +\det\begin{bmatrix}-1&4\\0&5\end{bmatrix} = (-5-0)=-5$.
 $C_{12} = -\det\begin{bmatrix}3&4\\2&5\end{bmatrix} = -(15-8)=-7$.
 Sum: $1(-5)+2(-7) = -19$.
 Now expand along column 3 to double-check: $\det = 0\cdot C_{13}+4\cdot C_{23}+5\cdot C_{33}$.
 $C_{23}=-\det\begin{bmatrix}1&2\\2&0\end{bmatrix}=-(0-4)=4$.
 $C_{33}=+\det\begin{bmatrix}1&2\\3&-1\end{bmatrix}=+(-1-6)=-7$.
 Check: $4(4)+5(-7)=16-35=-19$. Both expansions agree: $\det(A)=\mathbf{-19}$.
::::
:::

:::example[Example 3.2 — Triangular shortcut beats expansion]
Compute $\det\begin{bmatrix}4&0&0\\7&-2&0\\3&5&6\end{bmatrix}$.

::::answer[Answer]
**Answer:** $\det = -48$

1. The matrix is lower triangular because every entry above the diagonal is zero. Use the product-of-diagonal-entries rule instead of computing cofactors.

2. This is lower triangular. By Theorem 3.2, $\det = (4)(-2)(6) = -48$. Done in one step.

3. Multiply $4(-2)=-8$ and then $(-8)(6)=-48$. The negative result reflects the single negative diagonal factor.
::::
:::

:::example[Example 3.3 — 4×4 by expanding along a sparse row]
Compute $\det(A)$ for $A = \begin{bmatrix}3&0&0&1\\0&2&0&0\\0&0&-1&0\\2&0&0&4\end{bmatrix}$.

::::answer[Answer]
**Answer:** $\det(A) = -20$

1. Row 2 has three zeros — expand along it. Only the $(2,2)$ entry is nonzero:

2. Calculate the next cofactor or determinant term with its indicated sign:

    $$
    \det(A) = 2 \cdot C_{22} = 2 \cdot (+1)\det\begin{bmatrix}3&0&1\\0&-1&0\\2&0&4\end{bmatrix}
    $$

3. Now expand the $3\times3$ along its middle row (only $(2,2)$ nonzero):

4. Calculate the next cofactor or determinant term with its indicated sign:

    $$
    \det\begin{bmatrix}3&0&1\\0&-1&0\\2&0&4\end{bmatrix} = -1\cdot(+1)\det\begin{bmatrix}3&1\\2&4\end{bmatrix} = -1(12-2) = -10
    $$

5. Calculate the next cofactor or determinant term with its indicated sign:

    $$
    \det(A) = 2 \cdot (-10) = -20
    $$
::::
:::

:::example[Example 3.4 — Choose a column instead of the first row]
Compute $\det A$ for $A=\begin{bmatrix}2&0&1\\3&0&-2\\1&4&5\end{bmatrix}$ without row reduction.

::::answer[Answer]
**Answer:** $\det A=28$.

1. The cofactor sign comes from $(-1)^{i+j}$; the adjugate is the transpose of the cofactor matrix.

2. $\det A=28$. The second column has two zeros, so expand **down column 2**, not along row 1. Only $a_{32}=4$ survives. Its cofactor sign is $(-1)^{3+2}=-1$:

3. Calculate the next cofactor or determinant term with its indicated sign:

    $$
    \det A=4C_{32}=4(-1)\det\begin{bmatrix}2&1\\3&-2\end{bmatrix}.
    $$

4. The little determinant is $2(-2)-1(3)=-4-3=-7$. The cofactor is $-(-7)=7$. Therefore the result is $4(7)=28$, not $-28$. Both negatives must be accounted for. Always simplify the minor before deciding the final sign.

5. Check by multiplying $A\operatorname{adj}(A)$ and comparing it with $(\det A)I$.
::::
:::

:::callout-pitfall[Watch out for]
- **The sign pattern $(-1)^{i+j}$.** Position $(1,1)$ is $+$, $(1,2)$ is $-$, $(2,1)$ is $-$, $(2,2)$ is $+$, etc. Draw the checkerboard whenever unsure.
- **Delete the correct row AND column.** For $M_{23}$, delete row 2 and column 3. Students often delete only the row.
- **Expansion along any row/column gives the same answer.** If you get different answers, there's an arithmetic error — not a formula error.
:::

### Practice problems

:::problem[Problem 3.1 — Two-by-two determinant]{difficulty=easy}
Compute $\det\begin{bmatrix}5&-2\\3&4\end{bmatrix}$.

::::solution[Solution]
**Answer:** $\det A=26$.

1. The input is $2\times2$, so apply $ad-bc$, taking the main-diagonal product minus the other-diagonal product.

2. $\det = (5)(4)-(-2)(3) = 20+6 = 26$.

3. Compute $ad=5(4)=20$ and $bc=(-2)(3)=-6$. Subtract to get $20-(-6)=26$. The two minus signs create a positive contribution.

4. Check the subtraction: $20-(-6)=20+6=26$, so the off-diagonal product increases the determinant. Because $26\ne0$, the nonzero determinant also confirms the matrix is invertible.
::::
:::

:::problem[Problem 3.2 — Triangular determinant]{difficulty=easy}
Use the triangular rule to compute $\det\begin{bmatrix}2&7&-3\\0&5&1\\0&0&-4\end{bmatrix}$.

::::solution[Solution]
**Answer:** $\det A=-40$.

1. All entries below the diagonal are zero, so the matrix is upper triangular. For such a matrix the determinant equals the diagonal product.

2. Upper triangular: $\det = (2)(5)(-4) = -40$.

3. Read the diagonal in order: $2$, $5$, and $-4$. Multiply $2\cdot5=10$, then $10(-4)=-40$; no cofactor expansion or row operation is needed.
::::
:::

:::problem[Problem 3.3 — Cofactor expansion]{difficulty=standard}
Compute $\det\begin{bmatrix}0&1&2\\3&-1&0\\1&2&4\end{bmatrix}$ by expanding along the most convenient row or column.

::::solution[Solution]
**Answer:** $\det A=2$.

1. Choose row 1 because its leading entry is zero, saving a cofactor. The first-row signs are positive, negative, positive.

2. Row 1 has a zero at position $(1,1)$. Expand along row 1:

3. Calculate the next cofactor or determinant term with its indicated sign:

    $$
    \det = 0\cdot C_{11}+1\cdot C_{12}+2\cdot C_{13}
    $$

4. Calculate the next cofactor or determinant term with its indicated sign:

    $$
    C_{12}=-\det\begin{bmatrix}3&0\\1&4\end{bmatrix}=-(12-0)=-12
    $$

5. Calculate the next cofactor or determinant term with its indicated sign:

    $$
    C_{13}=+\det\begin{bmatrix}3&-1\\1&2\end{bmatrix}=+(6+1)=7
    $$

6. Calculate the next cofactor or determinant term with its indicated sign:

    $$
    \det = 0 + 1(-12)+2(7) = -12+14 = 2
    $$

7. Delete the first row and each chosen column carefully. The surviving contributions are $-12$ and $2\cdot7=14$, so $-12+14=2$.
::::
:::

:::problem[Problem 3.4 — Singular parameter]{difficulty=standard}
Find all values of $k$ for which $A = \begin{bmatrix}k&2\\3&k\end{bmatrix}$ is singular.

::::solution[Solution]
**Answer:** $k=\pm\sqrt6$.

1. A square matrix is singular exactly when its determinant is zero. Use the $2\times2$ rule before solving for $k$.

2. $\det(A) = k^2 - 6 = 0 \Rightarrow k = \pm\sqrt{6}$.

3. Compute $\det A=k\cdot k-2\cdot3=k^2-6$. Set this equal to zero: $k^2=6$, giving both real roots $k=\sqrt6$ and $k=-\sqrt6$.
::::
:::

:::problem[Problem 3.5 — Four-by-four triangular determinant]{difficulty=challenge}
Compute the determinant of the $4\times4$ matrix using the fastest valid method:

$$
A=\begin{bmatrix}1&0&0&0\\2&3&0&0\\4&5&6&0\\7&8&9&10\end{bmatrix}
$$

::::solution[Solution]
**Answer:** $\det A=180$.

1. Every entry above the main diagonal is zero, so the matrix is lower triangular. The determinant is the product of its four diagonal entries.

2. The cofactor sign comes from $(-1)^{i+j}$; the adjugate is the transpose of the cofactor matrix.

3. Lower triangular — apply the triangular rule directly:

4. $\det(A) = (1)(3)(6)(10) = 180$.

5. (No cofactor expansion needed at all!)

6. Check by multiplying $A\operatorname{adj}(A)$ and comparing it with $(\det A)I$.

7. Multiply stepwise: $1\cdot3=3$, $3\cdot6=18$, and $18\cdot10=180$. No signs change because no row swaps or negative diagonal entries occur.
::::
:::

:::problem[Problem 3.6 — Sparse 4×4 expansion]{difficulty=standard}
Use the fastest cofactor expansion for $A=\begin{bmatrix}2&0&0&1\\0&3&0&0\\0&0&-2&0\\1&0&0&2\end{bmatrix}$.

::::solution[Solution]
**Answer:** $\det A=-18$.

1. Use row 2, which has only the nonzero entry $3$ in column 2. That cofactor has sign $(-1)^{2+2}=+1$.

2. $\det A=-18$. Expand on row 2: $3\det\begin{bmatrix}2&0&1\\0&-2&0\\1&0&2\end{bmatrix}$. Expand the remaining determinant on row 2: $(-2)\det\begin{bmatrix}2&1\\1&2\end{bmatrix}=(-2)(4-1)=-6$. Thus $3(-6)=-18$.

3. The remaining $3\times3$ minor has an easy middle-row entry $-2$; the remaining $2\times2$ determinant is $2(2)-1(1)=3$. Thus $3(-2)(3)=-18$.
::::
:::

:::problem[Problem 3.7 — Find a singular parameter]{difficulty=standard}
For what $h$ does $A=\begin{bmatrix}1&2&0\\0&h&4\\0&1&2\end{bmatrix}$ have no inverse?

::::solution[Solution]
**Answer:** $h=2$.

1. No inverse exists exactly when $\det A=0$. Expand down column 1, where the entries are $1,0,0$.

2. $h=2$. Expand down column 1: $\det A=1\det\begin{bmatrix}h&4\\1&2\end{bmatrix}=2h-4$. No inverse means $2h-4=0$, so $h=2$.

3. This leaves $\det\begin{bmatrix}h&4\\1&2\end{bmatrix}=2h-4$. Set $2h-4=0$, add $4$, and divide by $2$ to get $h=2$.
::::
:::

## 3.2 Properties of Determinants

:::callout-intuition[Intuition first]
Cofactor expansion is correct but slow for large matrices. The real power of determinants
 comes from their properties: how they respond to row operations, how they multiply, and
 what they say about invertibility. These properties let you compute determinants quickly
 by first row-reducing to a triangular form, then reading off the product of pivots —
 adjusting for any row swaps along the way.
:::

### Effect of row operations on $\det$

:::theorem[Theorem 3.3 — Row Operations and Determinants]
Let $A$ be an $n\times n$ matrix.

1. **Row swap** $R_i \leftrightarrow R_j$: multiplies $\det$ by $-1$.
2. **Row scaling** $R_i \leftarrow c\,R_i$: multiplies $\det$ by $c$.
3. **Row replacement** $R_i \leftarrow R_i + c\,R_j$: $\det$ is **unchanged**.
:::

:::callout-key[Practical method: reduce to triangular form]
Row-reduce $A$ to an echelon (triangular) form $U$ using only row replacements and swaps.
 Track the number of swaps $s$. Then:

$$
\det(A) = (-1)^s \cdot (u_{11} \cdot u_{22} \cdots u_{nn})
$$

 where $u_{ii}$ are the diagonal entries of $U$. If you need to scale a row, factor
 the scalar out and divide it back at the end.
:::

### Special determinant facts

:::theorem[Theorem 3.4 — When $\det = 0$]
The following each force $\det(A) = 0$:

- Two identical rows (or columns).
- A row (or column) of all zeros.
- One row is a scalar multiple of another (linearly dependent rows).
- $A$ is singular (not invertible).

Equivalently: $\det(A) \neq 0 \Longleftrightarrow A$ is invertible.
:::

### The multiplicative property

:::theorem[Theorem 3.5 — Determinant of a Product]
For any $n\times n$ matrices $A$ and $B$:

$$
\det(AB) = \det(A)\cdot\det(B).
$$

Corollaries:

- $\det(A^{-1}) = \dfrac{1}{\det(A)}$ (when $A$ is invertible).
- $\det(A^T) = \det(A)$.
- $\det(A^k) = [\det(A)]^k$.
:::

### Think of row operations as changing a signed volume

Row reduction is not merely a way to make zeros. Each elementary operation changes the determinant by a precise factor, and those factors can be tracked backward. Geometrically, adding a multiple of one row to another shears a parallelogram without changing its area. Exchanging two rows reverses orientation, so the sign flips. Multiplying **one** row by $c$ stretches in one independent direction, so signed volume is multiplied by $c$. These are the three allowed operations, and there is no fourth hidden rule.

<figure class="fig">
<svg class="fig-hue-3" viewBox="0 0 480 180" width="480" height="180" role="img" aria-label="A square becomes a sheared parallelogram of the same area under row replacement">
<path class="fig-axis" d="M20 160H210 M20 160V15 M260 160H465 M260 160V15"/>
<path class="fig-fill" d="M40 145L100 145L100 85L40 85Z"/>
<path class="fig-curve" d="M40 145L100 145L100 85L40 85Z M280 145L360 145L415 85L335 85Z"/>
<path class="fig-fill-alt" d="M280 145L360 145L415 85L335 85Z"/>
<text class="fig-label" x="70" y="172">before</text><text class="fig-label" x="332" y="172">after shear</text><text class="fig-label-em" x="202" y="90">→</text>
</svg>
<figcaption>A row replacement changes the tilt of a region without changing its signed area; a row swap reverses the determinant's sign and scaling one row multiplies the determinant by the scaling factor.</figcaption>
</figure>

One of the easiest mistakes is to row-reduce all the way to the identity and conclude $\det A=1$. That ignores how you got there. If you replaced rows only, the determinant stayed fixed, so ending with the identity would indeed imply determinant one. If you swapped or scaled rows, you must undo their determinant effects. A record of the operations is therefore part of the calculation, not optional scratch work.

### A determinant ledger

Write each operation and its effect beside the matrix. For example, suppose the sequence is: swap $R_1,R_2$; multiply $R_3$ by $-2$; replace $R_2$ by $R_2+4R_1$. The determinant of the final matrix is $( -1)( -2)(1)\det A=2\det A$. If the final matrix is upper triangular with diagonal $1,3,-4$, its determinant is $-12$, hence $2\det A=-12$ and $\det A=-6$. **Work backward from the final determinant, do not blindly multiply your factors into it.**

Here is a paper-friendly tabulation that is also easy to narrate:

| Operation | Factor from old determinant to new | How to recover the old |
|---|---|---|
| $R_i\leftrightarrow R_j$ | $-1$ | negate the new determinant |
| $R_i\gets cR_i$ | $c$ | divide the new determinant by $c$ |
| $R_i\gets R_i+cR_j$ | $1$ | keep the new determinant unchanged |

The table has one point: accumulate the factors in the direction **$A\rightarrow U$**; then divide $\det U$ by their product. This approach also handles a chain with many swaps. If the factor product is negative, the determinant changes sign; if the product is a fraction, divide by that fraction at the end.

### Why you can stop at echelon form

To determine a determinant, full reduced row echelon form is wasted work. Once entries below the diagonal are zero, the matrix is upper triangular. Multiply its diagonal entries and adjust for the ledger. In Gaussian elimination, use replacement operations whenever possible because they leave the determinant unchanged. If a pivot is zero, a row swap may be necessary. Record every swap, including one made halfway through a calculation. If a pivot column contains no nonzero candidates below, the eventual triangular form has a zero diagonal, and the determinant vanishes.

A scalar multiplication of the **entire** matrix $cA$ is different from scaling a single row. The matrix has $n$ rows, so multiplying every entry by $c$ scales each row, resulting in $\det(cA)=c^n\det A$. For a $2\times2$, the factor is $c^2$; for a $3\times3$, it is $c^3$. A negative $c$ flips orientation only when $n$ is odd. Keep the matrix dimension beside any determinant property problem, because forgetting the exponent is a very common exam error.

### Products, transposes, and inverse matrices

The identity $\det(AB)=\det A\det B$ concerns **matrix multiplication**, not addition. Since $AA^{-1}=I$, taking determinants gives $\det A\det(A^{-1})=1$. So the reciprocal formula follows for invertible matrices. A transpose has the same determinant as the original matrix; conceptually, row and column versions of the volume formula agree. In contrast, there is no general simplification of $\det(A+B)$ into two separate determinants. For example, take $A=B=I_2$: $\det(A+B)=\det(2I_2)=4$ while $\det A+\det B=2$.

For powers, $\det(A^4)=(\det A)^4$, since $A^4=AAAA$. For $\det(3A^2B^{-1})$ with $n=3$, write $3^3(\det A)^2/\det B$. The exponent on $3$ is the **matrix dimension**; the exponent on $\det A$ is the **power of $A$**. This distinction is worth writing on the margin before substituting numbers.

### What determinant zero really says

A zero determinant means the columns are linearly dependent, not necessarily equal or visibly proportional. For example, in $\R^3$ the third column can be the sum of the first two without any pair being multiples. It also means $A\mathbf{x}=\mathbf{0}$ has a nonzero solution, the columns cannot span all of $\R^n$, and $A$ does not have an inverse. Conversely, a nonzero determinant guarantees the square system $A\mathbf{x}=\mathbf{b}$ has exactly one solution for **every** $\mathbf{b}$. These are multiple faces of the Invertible Matrix Theorem rather than separate facts to memorize.

A singularity parameter question such as “find $h$ so that $A$ is not invertible” is simply the equation $\det A=0$. Expand or eliminate using $h$ symbolically, factor the resulting polynomial, and list *all* real solutions. Avoid dividing by an expression containing $h$ before checking whether it could be zero: dividing by $h-2$ silently discards the very value you might need.

### Test-day verification habits

Before turning in a determinant answer, ask four questions. Was the input square? Did any row swaps occur? Did I scale one row or the whole matrix? Did I interpret the computed number as $\det A$ or $\det U$? If you used a determinant property for $AB$, check whether $A$ and $B$ have the same square size. If you used an inverse property, check that $\det A\ne0$. If a result is zero, attempt to explain it by dependence or a missing pivot. A short independent check is especially valuable for a determinant of $-1$, $0$, or $1$, where a sign mistake might otherwise look plausible.


### A complete reversal check with actual rows

Consider $A=\begin{bmatrix}1&2\\3&4\end{bmatrix}$. Its direct determinant is $1(4)-2(3)=-2$. Now perform $R_2\gets R_2-3R_1$, producing $B=\begin{bmatrix}1&2\\0&-2\end{bmatrix}$. This is a row replacement, so $\det B=-2$ without any adjustment. Swap the rows: $C=\begin{bmatrix}0&-2\\1&2\end{bmatrix}$, whose determinant is $0(2)-(-2)(1)=2$. Finally multiply row 1 by $3$: $D=\begin{bmatrix}0&-6\\1&2\end{bmatrix}$ with determinant $6$. If the exam gives only the last matrix and the operation chain, then

$$
\det D=(1)(-1)(3)\det A=-3\det A.
$$

Since $\det D=6$, solve $6=-3\det A$ and obtain $\det A=-2$. This agrees with the direct calculation. Notice why reversing the chain matters: multiplying $6$ by $-3$ would give $-18$, which is a different number and is not the original determinant. The equation $\det D=f\det A$ keeps the directions straight.

The same ledger handles an apparently complicated chain even if the rows themselves are never supplied. If the sequence includes several replacements, ignore their number for determinant purposes; each has factor $1$. Count each swap, multiply the scale factors of individual rows, and recover the original determinant from the final triangular product. If a question also asks for $\det(AB)$ or $\det(A^{-1})$, do not repeat elimination: first recover $\det A$ and then apply the appropriate identity.

### Worked examples

:::example[Example 3.5 — Computing det by row reduction]
Compute $\det(A)$ for $A = \begin{bmatrix}2&1&3\\4&5&7\\2&3&1\end{bmatrix}$ using row reduction.

::::answer[Answer]
**Answer:** $\det(A) = -16$

1. Use row replacements (which don't change $\det$):

2. Evaluate each displayed entry using the corresponding definition:

    $$
    A \xrightarrow{R_2-2R_1} \begin{bmatrix}2&1&3\\0&3&1\\2&3&1\end{bmatrix}
            \xrightarrow{R_3-R_1} \begin{bmatrix}2&1&3\\0&3&1\\0&2&-2\end{bmatrix}
    $$

3. Evaluate each displayed entry using the corresponding definition:

    $$
    \xrightarrow{R_3 - \frac{2}{3}R_2} \begin{bmatrix}2&1&3\\0&3&1\\0&0&-\frac{8}{3}\end{bmatrix} = U
    $$

4. Zero swaps, so $\det(A) = \det(U) = (2)(3)(-\tfrac{8}{3}) = -16$.

5. Check: cofactor expansion agrees
Expanding along row 1: $2\det\begin{bmatrix}5&7\\3&1\end{bmatrix}-1\det\begin{bmatrix}4&7\\2&1\end{bmatrix}+3\det\begin{bmatrix}4&5\\2&3\end{bmatrix}$
 $=2(5-21)-1(4-14)+3(12-10)=2(-16)-1(-10)+3(2)=-32+10+6=-16$. Both give $-16$.
::::
:::

:::example[Example 3.6 — Using the multiplicative property]
Given $\det(A)=3$ and $\det(B)=-2$ (both $3\times3$), find $\det(2AB^{-1})$.

::::answer[Answer]
**Answer:** $\det(2AB^{-1}) = -12$

1. Break it apart using the properties:

2. Calculate the next cofactor or determinant term with its indicated sign:

    $$
    \det(2AB^{-1}) = \det(2I)\cdot\det(A)\cdot\det(B^{-1})
    $$

3. $\det(2I)$ for a $3\times3$ matrix: scaling all 3 rows by 2 multiplies $\det$ by $2^3 = 8$. So $\det(2I_3)=8$.

4. Calculate the next cofactor or determinant term with its indicated sign:

    $$
    \det(B^{-1}) = \frac{1}{\det(B)} = \frac{1}{-2}
    $$

5. Calculate the next cofactor or determinant term with its indicated sign:

    $$
    \det(2AB^{-1}) = 8 \cdot 3 \cdot \frac{1}{-2} = \frac{24}{-2} = -12
    $$
::::
:::



:::example[Example 3.7 — Reverse a chain of determinant changes]
A $3\times3$ matrix $A$ becomes $U=\begin{bmatrix}2&1&0\\0&3&4\\0&0&-2\end{bmatrix}$ after these operations, in order: $R_1\leftrightarrow R_2$, $R_3\gets -2R_3$, $R_2\gets R_2+3R_1$. Find $\det A$, $\det(A^{-1})$, $\det(2A)$, $\det(A^T)$, and $\det(A^2)$.

::::answer[Answer]
**Answer:** $\det A=-6$, $\det(A^{-1})=-\tfrac16$, $\det(2A)=-48$, $\det(A^T)=-6$, $\det(A^2)=36$.

1. $\det A=-6$, $\det(A^{-1})=-\tfrac16$, $\det(2A)=-48$, $\det(A^T)=-6$, $\det(A^2)=36$.

2. Since $U$ is triangular, $\det U=(2)(3)(-2)=-12$. One swap contributes $-1$, one row scaling contributes $-2$, and replacement contributes $1$. Therefore $\det U=(-1)(-2)(1)\det A=2\det A$, giving $\det A=-12/2=-6$. Since this is nonzero, the inverse exists. The reciprocal is $-1/6$. The matrix is $3\times3$, so $\det(2A)=2^3(-6)=-48$. Transposing does not change the determinant, so $\det(A^T)=-6$. The determinant of the square is $(-6)^2=36$. Each result comes from the same recovered determinant; never confuse $-12$ (the final triangular matrix) with $-6$ (the original).
::::
:::

:::example[Example 3.8 — Parameter for a missing pivot]
Find all $h$ such that $A=\begin{bmatrix}1&2&0\\0&h&3\\0&2&6\end{bmatrix}$ is singular.

::::answer[Answer]
**Answer:** $h=1$.

1. A matrix loses invertibility when one of its pivots becomes zero. Row replacements preserve the solution to this pivot-condition question.

2. $h=1$. The first column is $(1,0,0)^T$, so expand along it: $\det A=1\cdot\det\begin{bmatrix}h&3\\2&6\end{bmatrix}=6h-6$. Setting this equal to zero gives $6(h-1)=0$ and therefore $h=1$. At that value, row 3 is twice row 2: $(0,2,6)=2(0,1,3)$, a direct reason for singularity. There is no need for division by $h$ or general row reduction.

3. Substituting $h=1$ makes the final two rows dependent; substituting any other value leaves a nonzero final pivot, so the singular parameter is unique.
::::
:::

:::callout-pitfall[Watch out for]
- **Row swap flips the sign.** Track every swap. One swap: $\times(-1)$. Two swaps: $\times(-1)^2=+1$. Easy to lose count.
- **$\det(A+B) \neq \det(A)+\det(B)$.** The determinant is multiplicative, not additive.
- **$\det(cA) = c^n\det(A)$ for $n\times n$ matrices.** Scaling a whole matrix by $c$ multiplies the determinant by $c^n$, not just $c$.
- **Cramer's Rule requires $\det(A)\neq0$.** Check invertibility first.
:::

### Practice problems

:::problem[Problem 3.8 — Repeated rows]{difficulty=easy}
Without any computation, explain why $\det\begin{bmatrix}1&2&3\\4&5&6\\1&2&3\end{bmatrix}=0$.

::::solution[Solution]
**Answer:** $\det A=0$ (repeated rows).

1. Rows 1 and 3 are identical. A determinant vanishes whenever two rows agree, because exchanging them would both negate and leave the determinant unchanged.

2. Rows 1 and 3 are identical. By Theorem 3.4, a matrix with two identical rows has determinant 0.

3. Thus $\det A=-\det A$ and $2\det A=0$, giving $\det A=0$. This property avoids all cofactor arithmetic.
::::
:::

:::problem[Problem 3.9 — Scaling a determinant]{difficulty=easy}
If $\det(A)=6$, find $\det(3A)$ for a $3\times3$ matrix $A$.

::::solution[Solution]
**Answer:** $\det(3A)=162$.

1. For a $3\times3$ matrix, multiplying the whole matrix by $3$ multiplies each of its three rows by $3$.

2. $\det(3A) = 3^3\det(A) = 27\cdot6 = 162$.

3. The determinant picks up one factor per row: $\det(3A)=3^3\det A=27(6)=162$. Multiplying by only $3$ would miss two row-scaling factors.
::::
:::

:::problem[Problem 3.10 — Elimination for a determinant]{difficulty=standard}
Use row reduction to compute $\det\begin{bmatrix}1&2&3\\2&5&7\\3&7&8\end{bmatrix}$.

::::solution[Solution]
**Answer:** $\det A=-2$.

1. Use row replacements $R_2\leftarrow R_2-2R_1$ and $R_3\leftarrow R_3-3R_1$; both preserve the determinant.

2. Evaluate each displayed entry using the corresponding definition:

    $$
    \xrightarrow{R_2-2R_1,\;R_3-3R_1}\begin{bmatrix}1&2&3\\0&1&1\\0&1&-1\end{bmatrix}
              \xrightarrow{R_3-R_2}\begin{bmatrix}1&2&3\\0&1&1\\0&0&-2\end{bmatrix}
    $$

3. No swaps. $\det=(1)(1)(-2)=-2$.

4. Then subtract the new second row from the third, giving an upper triangular matrix with diagonal $1,1,-2$. Their product is $-2$.
::::
:::


:::problem[Problem 3.11 — Determinant of an inverse]{difficulty=challenge}
Prove that if $A$ is invertible, then $\det(A^{-1})=1/\det(A)$.

::::solution[Solution]
**Answer:** $\det(A^{-1})=1/\det A$.

1. Invertibility guarantees $AA^{-1}=I$. Take determinants and use the product law instead of manipulating individual matrix entries.

2. Since $A$ is invertible, $AA^{-1}=I$. Taking determinants of both sides:

3. Calculate the next cofactor or determinant term with its indicated sign:

    $$
    \det(AA^{-1})=\det(I)=1.
    $$

4. By the multiplicative property: $\det(A)\cdot\det(A^{-1})=1$. Since $A$ is invertible, $\det(A)\neq0$, so we can divide:

5. Calculate the next cofactor or determinant term with its indicated sign:

    $$
    \det(A^{-1})=\frac{1}{\det(A)}.\quad\square
    $$

6. The identity has determinant $1$, so $(\det A)(\det A^{-1})=1$. Because $\det A\ne0$, divide both sides to obtain $\det(A^{-1})=1/\det A$.
::::
:::

:::problem[Problem 3.12 — Idempotent determinant]{difficulty=challenge}
If $A$ is $n\times n$ and $A^2=A$ (called an *idempotent* matrix), what are the possible values of $\det(A)$?

::::solution[Solution]
**Answer:** $\det A\in\{0,1\}$.

1. Take determinants of the idempotent equation $A^2=A$. The product rule gives $(\det A)^2=\det A$.

2. $A^2=A\Rightarrow\det(A^2)=\det(A)\Rightarrow[\det(A)]^2=\det(A)$.

3. Let $d=\det(A)$. Then $d^2-d=0\Rightarrow d(d-1)=0\Rightarrow d=0$ or $d=1$.

4. Both are achievable: $d=0$ for $A=O$ (zero matrix); $d=1$ for $A=I$. (Projections like $A=\begin{bmatrix}1&0\\0&0\end{bmatrix}$ also give $d=0$.)

5. Let $d=\det A$; then $d^2-d=0$. Factor $d(d-1)=0$, so $d=0$ or $d=1$. Both occur for the zero and identity matrices.
::::
:::

:::problem[Problem 3.13 — Determinant ledger]{difficulty=standard}
A $3\times3$ matrix $A$ is changed to $U=\begin{bmatrix}1&2&0\\0&-3&4\\0&0&2\end{bmatrix}$ by one row swap, one scaling $R_3\gets 3R_3$, and any number of row replacements. Determine $\det A$.

::::solution[Solution]
**Answer:** $\det A=2$.

1. Row replacements leave determinants unchanged. A single swap multiplies by $-1$, and scaling row 3 by $3$ multiplies by $3$.

2. $\det A=2$.** $\det U=(1)(-3)(2)=-6$. The total determinant factor is $(-1)(3)=-3$, so $-6=-3\det A$ and $\det A=2$.

3. The triangular target has determinant $(1)(-3)(2)=-6$. Thus $-6=(-1)(3)\det A=-3\det A$, so divide by $-3$ to obtain $\det A=2$.
::::
:::

:::problem[Problem 3.14 — Products and transposes]{difficulty=standard}
If $A,B$ are $2\times2$ with $\det A=-2$ and $\det B=3$, calculate $\det(AB)$, $\det(A^T)$, $\det(3A)$ and $\det(A^{-1})$.

::::solution[Solution]
**Answer:** $-6,-2,-18,-\tfrac12$ in that order. Product: $(-2)(3)=-6$. Transpose: $-2$. Whole-matrix scaling: $3^2(-2)=-18$. Inverse: $1/(-2)=-1/2$.

1. Use the determinant product law, the fact that transpose preserves determinant, the dimension-dependent scalar factor, and the reciprocal rule for inverses.

2. $-6,-2,-18,-\tfrac12$ in that order. Product: $(-2)(3)=-6$. Transpose: $-2$. Whole-matrix scaling: $3^2(-2)=-18$. Inverse: $1/(-2)=-1/2$.

3. Here $\det(AB)=(-2)(3)=-6$, $\det(A^T)=-2$, $\det(3A)=3^2(-2)=-18$, and $\det(A^{-1})=1/(-2)=-1/2$.
::::
:::

## 3.3 Cramer's Rule, Adjugates, and Determinants as Area/Volume

:::callout-intuition[Why one determinant can solve a whole system]
The equation $A\mathbf{x}=\mathbf{b}$ normally invites row reduction. But a nonzero determinant says the columns of $A$ form an independent coordinate frame. If we replace one column by the target vector $\mathbf{b}$, the signed volume changes in exactly the proportion of that column's coefficient in the solution. That ratio is Cramer's Rule. The same cofactors also build an inverse matrix called the **adjugate**, and the area/volume meaning explains why the ratios work. These are elegant tools for small, hand-friendly matrices; they are not a reason to compute dozens of large determinants on a test.
:::

:::definition[Definition 3.4 — Column replacement matrix]
For a square $n\times n$ matrix $A=[\mathbf{a}_1\ \cdots\ \mathbf{a}_n]$ and a vector $\mathbf{b}$, let $A_i(\mathbf{b})$ be the matrix obtained by replacing **column $i$** of $A$ with $\mathbf{b}$ while preserving the order of every other column. This is a column operation for constructing a new matrix, **not** the same as replacing a row during elimination.
:::

:::theorem[Theorem 3.7 — Cramer's Rule]
If $\det A\ne0$ and $A\mathbf{x}=\mathbf{b}$, the unique solution has components

$$
x_i=\frac{\det A_i(\mathbf{b})}{\det A},\qquad i=1,\ldots,n.
$$

If $\det A=0$, the displayed fractions are undefined: Cramer's Rule cannot distinguish no solution from infinitely many solutions in that case.
:::

### Derive the rule once so it becomes memorable

Let $A=[\mathbf{a}_1\ \mathbf{a}_2]$ and suppose $\mathbf{b}=x_1\mathbf{a}_1+x_2\mathbf{a}_2$. Replacing the first column gives $[\mathbf{b}\ \mathbf{a}_2]$. Determinants are linear in any one column while the other columns are held fixed:

$$
\begin{aligned}
\det[\mathbf{b}\ \mathbf{a}_2]
&=\det[x_1\mathbf{a}_1+x_2\mathbf{a}_2\ \mathbf{a}_2]\\
&=x_1\det[\mathbf{a}_1\ \mathbf{a}_2]+x_2\det[\mathbf{a}_2\ \mathbf{a}_2]\\
&=x_1\det A+x_2(0)=x_1\det A.
\end{aligned}
$$

The determinant with identical columns vanishes, leaving only the wanted coefficient. Divide by the nonzero $\det A$ and you get $x_1$. Replacing the second column produces $x_2$ in the same way. This is why the position of the replaced column matters; swapping columns later introduces an unwanted negative sign.

### The three-determinant layout for $2\times2$

For $a_{11}x+a_{12}y=b_1$ and $a_{21}x+a_{22}y=b_2$, first calculate $D=a_{11}a_{22}-a_{12}a_{21}$. Then write $D_x=b_1a_{22}-a_{12}b_2$ and $D_y=a_{11}b_2-b_1a_{21}$. The answers are $x=D_x/D$ and $y=D_y/D$. These three quantities should be visible on paper. An examiner can award method credit when the setup is correct even if the final arithmetic is not.

For $3\times3$, set up $A_1,A_2,A_3$ and use sparse cofactor expansions for all four determinants. When you can solve the system faster by elimination, it is still useful to know Cramer's Rule because a test may expressly require it. Use a quick substitution at the end to check the solution.

### Adjugate: arrange cofactors, then transpose

:::definition[Definition 3.5 — Cofactor matrix and adjugate]
For an $n\times n$ matrix $A$, its cofactor matrix is $C=[C_{ij}]$, where $C_{ij}=(-1)^{i+j}\det A_{ij}$. The **adjugate** is the *transpose* of that matrix:

$$
\operatorname{adj}(A)=C^T.
$$

It is **not** generally the cofactor matrix itself. The inverse formula, when $\det A\ne0$, is $A^{-1}=\operatorname{adj}(A)/\det A$.
:::

:::theorem[Theorem 3.8 — Adjugate identity and inverse]
For every square matrix $A$,

$$
A\operatorname{adj}(A)=\operatorname{adj}(A)A=(\det A)I.
$$

When $\det A\ne0$, division by $\det A$ gives $A^{-1}=\frac1{\det A}\operatorname{adj}(A)$. The identity itself still holds if $\det A=0$; only the inverse formula then fails.
:::

### Why the product $A\operatorname{adj}(A)$ becomes diagonal

The $(i,i)$ entry of the product is a cofactor expansion of row $i$ of $A$, so it equals $\det A$. An off-diagonal $(i,j)$ entry is the cofactor expansion of a matrix with two identical rows, so it equals zero. Every diagonal entry therefore equals $\det A$ and every off-diagonal entry equals zero. This proves the identity without laboriously multiplying symbolic matrices of arbitrary size. In a $2\times2$ example, it is worth multiplying actual entries as a numerical verification.

A reliable adjugate algorithm for a $3\times3$ has four stages. Draw the checkerboard signs. Compute each of the nine **minors** and apply its sign to get nine **cofactors**. Arrange them in the cofactor matrix *without moving their positions*. Then transpose to form the adjugate, divide by the original determinant, and, if required, multiply $A\operatorname{adj}(A)$ to check for $(\det A)I$. Skipping the transpose is the classic error. For $2\times2$, the shortcut $\operatorname{adj}\begin{bmatrix}a&b\\c&d\end{bmatrix}=\begin{bmatrix}d&-b\\-c&a\end{bmatrix}$ comes from exactly the same procedure.

### Determinant as a geometric unit converter

:::theorem[Theorem 3.9 — Signed volume scaling]
For a linear map $T(\mathbf{x})=A\mathbf{x}$ with square matrix $A$, the magnitude $|\det A|$ is the volume scaling factor. In $\R^2$ it scales area; in $\R^3$ it scales volume. If $A$ has determinant zero, the image has zero full-dimensional volume because the columns are dependent. The sign records orientation, not negative physical volume.
:::

<figure class="fig">
<svg class="fig-hue-5" viewBox="0 0 450 195" width="450" height="195" role="img" aria-label="A triangle is half a parallelogram spanned by two side vectors">
<path class="fig-axis" d="M30 172H425 M30 172V15"/>
<path class="fig-curve" d="M75 145L245 112L325 35L155 68Z"/>
<path class="fig-guide" d="M75 145L325 35"/>
<path class="fig-fill" d="M75 145L245 112L155 68Z"/>
<path class="fig-fill-alt" d="M245 112L325 35L155 68Z"/>
<path class="fig-point" d="M71 141h8v8h-8Z"/>
<text class="fig-label" x="63" y="160">P</text><text class="fig-label" x="248" y="133">P+u</text><text class="fig-label" x="125" y="60">P+v</text><text class="fig-label-em" x="205" y="75">½ × area</text>
</svg>
<figcaption>The triangle formed by two side vectors $\mathbf{u},\mathbf{v}$ has half the area of their parallelogram, so $\text{area}=\tfrac12|\det[\mathbf{u}\ \mathbf{v}]|$; subtract one common vertex before forming those columns.</figcaption>
</figure>

For a parallelogram in the plane, arrange the two **side vectors as columns** and take $|\det A|$. If the problem gives four corners, first choose a common corner and subtract it from two adjacent corners to obtain the side vectors. Using absolute coordinates for the corners without subtraction generally gives the wrong area. For a triangle, take *half* the parallelogram area. If the points are $(x_1,y_1),(x_2,y_2),(x_3,y_3)$, use columns $(x_2-x_1,y_2-y_1)^T$ and $(x_3-x_1,y_3-y_1)^T$.

For a solid in $\R^3$, assemble three edge vectors into columns of a $3\times3$ matrix and take $|\det A|$. The three edges must start at the same vertex. If one vector is a linear combination of the other two, the solid collapses into a plane and the determinant equals zero. A tetrahedron occupies one sixth the volume of the parallelepiped spanned by three edges, just as the planar triangle occupies one half its parallelogram.

### Which method should you choose on a handwritten exam?

Cramer's Rule is convenient when a $2\times2$ system asks for one coordinate, or the instructions explicitly require it. Cofactor/adjugate inversion is meaningful for understanding formulas and for tiny matrices with sparse cofactors. Ordinary row reduction is usually better for solving a medium-sized linear system or finding a matrix inverse by hand. Determinants are ideal for area/volume questions and invertibility tests. Do not spend twenty lines on an adjugate when a two-line elimination would solve a system, unless the assignment is testing cofactors specifically.

:::callout-pitfall[Three different operations you must not mix]
1. **Cramer's Rule changes a column:** replace the $i$th column by $\mathbf{b}$ and divide the new determinant by $\det A$.
2. **Adjugates transpose the cofactor matrix:** merely computing minors is not enough, and forgetting checkerboard signs is just as bad.
3. **Area takes an absolute value and triangles take a half:** the determinant may be negative, but physical area may not. When points are given, subtract a common vertex first.
:::


### A full $3\times3$ adjugate with every position visible

To see why the cofactor **transpose** is essential, work with the upper-triangular matrix

$$
A=\begin{bmatrix}1&1&0\\0&1&1\\0&0&1\end{bmatrix},\qquad \det A=1.
$$

Compute minors row by row. Along row 1, the minors are $M_{11}=1$, $M_{12}=0$, $M_{13}=0$. Along row 2, they are $M_{21}=1$, $M_{22}=1$, $M_{23}=0$. Along row 3, they are $M_{31}=1$, $M_{32}=1$, $M_{33}=1$. Apply checkerboard signs; the second-row first entry and third-row second entry become negative:

$$
C=\begin{bmatrix}1&0&0\\-1&1&0\\1&-1&1\end{bmatrix}.
$$

Now transpose **the whole cofactor matrix**, not the original matrix:

$$
\operatorname{adj}(A)=C^T=
\begin{bmatrix}1&-1&1\\0&1&-1\\0&0&1\end{bmatrix}.
$$

Multiply for the required identity, keeping the zero entries explicit. Row 1 of $A$ times the three adjugate columns gives $(1,\ -1+1,\ 1-1)=(1,0,0)$. Row 2 gives $(0,\ 1,\ -1+1)=(0,1,0)$. Row 3 gives $(0,0,1)$. Thus $A\operatorname{adj}(A)=I_3=(\det A)I_3$. Since $\det A=1$, the inverse is exactly this adjugate. The wrong, untransposed matrix $C$ would not pass the product check; multiplying is how you catch the mistake.

For a general $3\times3$ with determinant $d\ne0$, the same steps give $A^{-1}=\tfrac1dC^T$. A matrix can have many zero minors, and triangular examples often exploit that simplicity. If a problem provides $\operatorname{adj}(A)$ and asks whether an inverse exists, do not assume that an adjugate implies invertibility. The adjugate exists for singular matrices too; you still need $d\ne0$ before dividing.

### Worked examples

:::example[Example 3.9 — Cramer's Rule]
Use Cramer's Rule to solve $\;2x_1 + x_2 = 5$, $\;x_1 + 3x_2 = 7$.

::::answer[Answer]
**Answer:** $x_1 = \tfrac{8}{5},\quad x_2 = \tfrac{9}{5}$

1. Cramer’s rule uses column-replacement determinants only when the coefficient determinant is nonzero.

2. $A = \begin{bmatrix}2&1\\1&3\end{bmatrix}$, $\det(A) = 6-1=5$.

3. Replace column 1 with $\mathbf{b}=\binom{5}{7}$: $\det\begin{bmatrix}5&1\\7&3\end{bmatrix}=15-7=8$.

4. Replace column 2 with $\mathbf{b}$: $\det\begin{bmatrix}2&5\\1&7\end{bmatrix}=14-5=9$.

5. Use the displayed equality to perform the next algebraic operation:

    $$
    x_1 = \frac{8}{5}, \qquad x_2 = \frac{9}{5}
    $$

6. Check: $2(\tfrac{8}{5})+\tfrac{9}{5}=\tfrac{25}{5}=5\,\checkmark$ and $\tfrac{8}{5}+3(\tfrac{9}{5})=\tfrac{35}{5}=7\,\checkmark$.
::::
:::

:::example[Example 3.10 — Geometric: area of a parallelogram]
Find the area of the parallelogram with vertices at the origin, $(3,1)$, $(2,4)$, and their sum.

::::answer[Answer]
**Answer:** Area $= 10$

1. The parallelogram is spanned by $\mathbf{a}_1=(3,1)^T$ and $\mathbf{a}_2=(2,4)^T$. Form the matrix $A=\begin{bmatrix}3&2\\1&4\end{bmatrix}$.

2. Calculate the next cofactor or determinant term with its indicated sign:

    $$
    \text{Area} = |\det(A)| = |12-2| = 10.
    $$
::::
:::

:::example[Example 3.11 — Inverse from cofactors, checked by multiplication]
For $A=\begin{bmatrix}2&1\\1&1\end{bmatrix}$, compute $\operatorname{adj}(A)$ and $A^{-1}$, and check $A\operatorname{adj}(A)=(\det A)I$.

::::answer[Answer]
**Answer:** $\det A=1$, $\operatorname{adj}(A)=\begin{bmatrix}1&-1\\-1&2\end{bmatrix}$, $A^{-1}=\begin{bmatrix}1&-1\\-1&2\end{bmatrix}$.

1. The cofactor sign comes from $(-1)^{i+j}$; the adjugate is the transpose of the cofactor matrix.

2. $\det A=1$, $\operatorname{adj}(A)=\begin{bmatrix}1&-1\\-1&2\end{bmatrix}$, $A^{-1}=\begin{bmatrix}1&-1\\-1&2\end{bmatrix}$.

3. Compute $\det A=2(1)-1(1)=1$. The four minors are $1,1,1,2$ in row order. Apply the checkerboard $+,-,-,+$ to obtain $C=\begin{bmatrix}1&-1\\-1&2\end{bmatrix}$. Transpose: this matrix happens to be symmetric, so $\operatorname{adj}(A)=C^T=C$. Divide by determinant $1$ to get $A^{-1}=\operatorname{adj}(A)$. The requested check is

4. Calculate the next cofactor or determinant term with its indicated sign:

    $$
    A\operatorname{adj}(A)=\begin{bmatrix}2&1\\1&1\end{bmatrix}\begin{bmatrix}1&-1\\-1&2\end{bmatrix}=\begin{bmatrix}2-1&-2+2\\1-1&-1+2\end{bmatrix}=\begin{bmatrix}1&0\\0&1\end{bmatrix}=(\det A)I_2.
    $$

5. This specific symmetric case does not make the transpose step optional in general.

6. Check by multiplying $A\operatorname{adj}(A)$ and comparing it with $(\det A)I$.
::::
:::

:::example[Example 3.12 — Three-dimensional volume]
Three edges from one corner are $\mathbf{u}=(2,0,0)$, $\mathbf{v}=(1,3,0)$, and $\mathbf{w}=(0,1,-2)$. Find the parallelepiped volume.

::::answer[Answer]
**Answer:** $12$ cubic units.

1. The three edge vectors form the columns of a $3\times3$ matrix. Their parallelepiped volume is the absolute determinant.

2. $12$ cubic units. Put edges in columns: $A=\begin{bmatrix}2&1&0\\0&3&1\\0&0&-2\end{bmatrix}$. It is upper triangular, so $\det A=(2)(3)(-2)=-12$. The minus sign indicates reversed orientation, not negative volume. Thus $V=|-12|=12$ cubic units. If asked for a tetrahedron with the same three edges, its volume would be $12/6=2$.

3. The determinant is $-12$, so its absolute value is $12$. The sign only records orientation and cannot make physical volume negative.
::::
:::

### Practice problems

:::problem[Problem 3.15 — Solve with Cramer’s rule]{difficulty=standard}
Use Cramer's Rule to solve $3x+y=7$, $x-2y=0$.

::::solution[Solution]
**Answer:** $(x,y)=(2,1)$.

1. Cramer’s rule applies because the coefficient determinant is nonzero. Replace exactly one coefficient column by the right-hand side for each unknown.

2. $\det(A)=\det\begin{bmatrix}3&1\\1&-2\end{bmatrix}=-6-1=-7$.

3. $x=\frac{\det\begin{bmatrix}7&1\\0&-2\end{bmatrix}}{-7}=\frac{-14}{-7}=2$.

4. $y=\frac{\det\begin{bmatrix}3&7\\1&0\end{bmatrix}}{-7}=\frac{-7}{-7}=1$.

5. Check the determinant of the original coefficient matrix and substitute the computed coordinates into the equations.

6. The replacement determinants are $D_x=-14$ and $D_y=-7$, while $D=-7$. Divide to get $x=(-14)/(-7)=2$ and $y=(-7)/(-7)=1$; substitution checks both equations.
::::
:::

:::problem[Problem 3.16 — Cramer's Rule with integers]{difficulty=easy}
Use Cramer's Rule for $x+y=5$, $2x-y=1$.

::::solution[Solution]
**Answer:** $(x,y)=(2,3)$.

1. Set $A=\begin{bmatrix}1&1\\2&-1\end{bmatrix}$ and $\mathbf b=(5,1)^T$. Its determinant is $D=1(-1)-1(2)=-3\ne0$.

2. The solution is $(x,y)=(2,3)$. The coefficient matrix is $A=\begin{bmatrix}1&1\\2&-1\end{bmatrix}$ has $D=-1-2=-3$. Replace column 1: $D_x=\det\begin{bmatrix}5&1\\1&-1\end{bmatrix}=-6$. Replace column 2: $D_y=\det\begin{bmatrix}1&5\\2&1\end{bmatrix}=-9$. Thus $x=D_x/D=2$, $y=D_y/D=3$. Check $2+3=5$ and $4-3=1$.

3. Replace column 1: $D_x=5(-1)-1(1)=-6$. Replace column 2: $D_y=1(1)-5(2)=-9$. Thus $x=(-6)/(-3)=2$, $y=(-9)/(-3)=3$.

4. Check the two equations in the original system: $1(2)+1(3)=5$ and $2(2)-1(3)=1$. Both equal the right-hand-side entries, confirming that Cramer’s Rule found the stated solution.
::::
:::

:::problem[Problem 3.17 — A two-by-two adjugate]{difficulty=easy}
For $A=\begin{bmatrix}3&1\\2&1\end{bmatrix}$, give the adjugate and the inverse, and verify the adjugate identity.

::::solution[Solution]
**Answer:** $\det A=1$, $\operatorname{adj}(A)=\begin{bmatrix}1&-1\\-2&3\end{bmatrix}$ and $A^{-1}=\begin{bmatrix}1&-1\\-2&3\end{bmatrix}$.

1. For $A=\begin{bmatrix}a&b\\c&d\end{bmatrix}$, form $\operatorname{adj}(A)=\begin{bmatrix}d&-b\\-c&a\end{bmatrix}$ and calculate $\det A=ad-bc$.

2. $\det A=1$, $\operatorname{adj}(A)=\begin{bmatrix}1&-1\\-2&3\end{bmatrix}$ and $A^{-1}=\begin{bmatrix}1&-1\\-2&3\end{bmatrix}$. Check $A\operatorname{adj}(A)=\begin{bmatrix}3-2&-3+3\\2-2&-2+3\end{bmatrix}=I_2=(\det A)I_2$.

3. Here $\det A=3(1)-1(2)=1$, so the inverse equals the adjugate. Verify by multiplying: $A\operatorname{adj}(A)=\begin{bmatrix}3-2&-3+3\\2-2&-2+3\end{bmatrix}=I_2$.

4. Check the other product order: $\operatorname{adj}(A)A=\begin{bmatrix}1&-1\\-2&3\end{bmatrix}\begin{bmatrix}3&1\\2&1\end{bmatrix}=\begin{bmatrix}1&0\\0&1\end{bmatrix}$. This verifies that the proposed inverse works on both sides.
::::
:::

:::problem[Problem 3.18 — Triangle from three points]{difficulty=standard}
Compute the area of the triangle with vertices $(1,1)$, $(4,1)$ and $(2,5)$.

::::solution[Solution]
**Answer:** $6$.

1. Use $(1,1)$ as a common starting point and subtract coordinates to form the side vectors $(3,0)$ and $(1,4)$.

2. $6$. From $(1,1)$ the side vectors are $(3,0)$ and $(1,4)$. The determinant $\det\begin{bmatrix}3&1\\0&4\end{bmatrix}=12$. The triangle has half the parallelogram area: $\tfrac12|12|=6$.

3. The parallelogram determinant is $3(4)-1(0)=12$. A triangle spans half that parallelogram, so its area is $\frac12|12|=6$ square units.
::::
:::

:::problem[Problem 3.19 — Check a nonsymmetric adjugate]{difficulty=standard}
For $A=\begin{bmatrix}2&1\\0&3\end{bmatrix}$, calculate $\operatorname{adj}(A)$, $A^{-1}$ and $A\operatorname{adj}(A)$.

::::solution[Solution]
**Answer:** $\operatorname{adj}(A)=\begin{bmatrix}3&-1\\0&2\end{bmatrix}$, $A^{-1}=\frac16\begin{bmatrix}3&-1\\0&2\end{bmatrix}$ and $A\operatorname{adj}(A)=6I_2$.

1. The adjugate of a $2\times2$ matrix swaps its diagonal and negates its off-diagonal entries. This construction does not require the original matrix to be symmetric.

2. $\operatorname{adj}(A)=\begin{bmatrix}3&-1\\0&2\end{bmatrix}$, $A^{-1}=\frac16\begin{bmatrix}3&-1\\0&2\end{bmatrix}$ and $A\operatorname{adj}(A)=6I_2$. The determinant is $2(3)-1(0)=6$. The product is $\begin{bmatrix}6&-2+2\\0&6\end{bmatrix}=\begin{bmatrix}6&0\\0&6\end{bmatrix}$.

3. Compute $\det A=2(3)-1(0)=6$. Divide the adjugate by $6$ for the inverse; then multiply $A\operatorname{adj}(A)$ to obtain $6I_2$.
::::
:::

:::problem[Problem 3.20 — Interpret zero volume]{difficulty=challenge}
The edge vectors are $(1,2,0)$, $(0,1,3)$, and $(1,3,3)$. Determine the volume of the resulting parallelepiped and explain what the answer says geometrically.

::::solution[Solution]
**Answer:** $0$.

1. Put the three edge vectors in the columns of a $3\times3$ matrix. The volume is the absolute value of its determinant.

2. $0$. The third vector is the sum of the first two: $(1,2,0)+(0,1,3)=(1,3,3)$. Columns are dependent, so $\det\begin{bmatrix}1&0&1\\2&1&3\\0&3&3\end{bmatrix}=0$. All three edges lie in a plane, yielding zero three-dimensional volume.

3. The third edge is the sum of the first two, so the columns are linearly dependent and the determinant is zero. Geometrically the edges lie in a plane, giving zero three-dimensional volume.
::::
:::

:::problem[Problem 3.21 — Singular Cramer trap]{difficulty=challenge}
Suppose $A=\begin{bmatrix}1&2\\2&4\end{bmatrix}$ and $\mathbf{b}=(3,6)^T$. Can Cramer's Rule produce a unique solution? Describe the actual solution set.

::::solution[Solution]
**Answer:** no unique solution; $\mathbf{x}=(3-2t,t)^T$, $t\in\R$.

1. Cramer’s rule would require a nonzero coefficient determinant. Here $D=1(4)-2(2)=0$, so there is no unique Cramer quotient.

2. no unique solution; $\mathbf{x}=(3-2t,t)^T$, $t\in\R$. Here $D=4-4=0$, so Cramer's fractions cannot be formed. The equations are $x+2y=3$ and $2x+4y=6$, which are the same constraint. Let $y=t$, then $x=3-2t$. It has infinitely many solutions, not zero solutions.

3. Both equations reduce to $x+2y=3$. Set $y=t$ freely, then $x=3-2t$, giving the infinite family $\mathbf x=(3-2t,t)^T$. Substitution satisfies both rows.
::::
:::

:::summary
## Chapter Summary

### Key results

#### Computing a determinant

**The $2 \times 2$ determinant** is the difference of the two diagonal products:

$$
\det\begin{bmatrix}a & b\\ c & d\end{bmatrix} = ad - bc
$$

**Minors and cofactors.** The **minor** $M_{ij}$ is the determinant of the matrix left after
 deleting row $i$ and column $j$ of $A$. The **cofactor** attaches a sign to it:

$$
C_{ij} = (-1)^{i+j} M_{ij}
$$

The sign $(-1)^{i+j}$ alternates like a chequerboard, starting with $+$ at the top left.

**Cofactor expansion.** The determinant can be expanded along **any** row or column and the
 answer is the same. Along row $i$:

$$
\det(A) = \sum_{j} a_{ij}C_{ij} = a_{i1}C_{i1} + a_{i2}C_{i2} + \cdots + a_{in}C_{in}
$$

Choose the row or column with the most zeros — each zero entry kills a whole cofactor, so the
 choice can turn four sub-determinants into one.

**A triangular matrix** — upper or lower — has determinant equal to the product of its
 diagonal entries:

$$
\det(A) = a_{11}a_{22}\cdots a_{nn}
$$

This is why reducing to triangular form is the practical method for anything larger than
 $3 \times 3$.

#### How row operations change a determinant

Each of the three operations affects the determinant differently, and this is the part most
 often misremembered:

| operation | effect on $\det$ |
| --- | --- |
| **Replacement** $R_i \leftarrow R_i + cR_j$ | **unchanged** |
| **Interchange** $R_i \leftrightarrow R_j$ | multiplied by $-1$ |
| **Scaling** $R_i \leftarrow cR_i$ | multiplied by $c$ |

So the working method is: reduce to triangular form using **replacement only**, which costs
 nothing, multiply the diagonal, then apply $-1$ for each row swap you made and divide out
 any scaling you used.

#### Properties

$$
\det(AB) = \det(A)\det(B), \qquad
\det(A^T) = \det(A), \qquad
\det(cA) = c^n\det(A)
$$

for $A$ an $n \times n$ matrix. Note the third: scaling the **whole matrix** multiplies the
 determinant by $c^n$, not by $c$, because all $n$ rows are scaled. There is **no** rule for
 $\det(A + B)$ — it is not $\det(A) + \det(B)$.

**Invertibility.** A square matrix $A$ is invertible **if and only if** $\det(A) \neq 0$.
 This extends the Invertible Matrix Theorem of Chapter 2 by one more equivalent condition.
 It follows that $\det(A^{-1}) = 1/\det(A)$.

#### Applications

**Cramer's Rule.** If $A$ is an invertible $n \times n$ matrix and
 $\mathbf{b} \in \mathbb{R}^n$, the unique solution of $A\mathbf{x} = \mathbf{b}$ has
 components

$$
x_i = \frac{\det\big(A_i(\mathbf{b})\big)}{\det(A)}
$$

where $A_i(\mathbf{b})$ is **the matrix formed by replacing column $i$ of $A$ with
 $\mathbf{b}$**. One determinant per unknown, plus $\det(A)$ itself. It requires $A$ to be
 invertible, and for anything beyond $3 \times 3$ row reduction is far faster.

**Area and volume.** $|\det(A)|$ is the area of the parallelogram spanned by the columns of a
 $2 \times 2$ matrix, and the volume of the parallelepiped spanned by the columns of a
 $3 \times 3$ one. A determinant of zero then means the shape is flattened — the columns lie
 on a line or in a plane, which is the geometric reading of dependent columns.

**Adjugate inverse.** With $C_{ij}=(-1)^{i+j}M_{ij}$, form the cofactor matrix $C$, transpose it to obtain $\operatorname{adj}(A)=C^T$, and check $A\operatorname{adj}(A)=(\det A)I$. Only divide by $\det A$ when it is nonzero. For geometric problems use $|\det A|$ for parallelogram area or parallelepiped volume and half that area for a triangle.

### If you remember nothing else

$\det(A) \neq 0$ if and only if $A$ is invertible. Row operations let you reduce to triangular
 form and read off the determinant as a product of pivots — adjust sign for each row swap.
 The product rule $\det(AB)=\det(A)\det(B)$ does the rest.
:::

## Mixed Practice

:::problem[Problem M.1 — Solve a determinant parameter]{difficulty=easy}
For what value of $h$ is $\det\begin{bmatrix}2&h\\h&8\end{bmatrix}=0$?

::::solution[Solution]
**Answer:** $h=\pm4$.

1. A singular matrix must have determinant zero. Compute the two diagonal products in the $2\times2$ parameter matrix.

2. $\det=16-h^2=0\Rightarrow h=\pm4$.

3. The determinant is $2(8)-h(h)=16-h^2$. Setting it to zero gives $h^2=16$ and hence $h=4$ or $h=-4$.

4. Substitute both candidates into the determinant: when $h=4$, $16-4^2=0$; when $h=-4$, $16-(-4)^2=0$. Both make the matrix singular, and the quadratic has no other real roots.
::::
:::

:::problem[Problem M.2 — Determinant identities]{difficulty=standard}
Let $A$ be $4\times4$ with $\det(A)=-3$. Find $\det(2A)$, $\det(-A)$, $\det(A^2)$, and $\det(A^{-1})$.

::::solution[Solution]
**Answer:** $\det(2A)=-48$, $\det(-A)=-3$, $\det(A^2)=9$, $\det(A^{-1})=-1/3$.

1. For $4\times4$ matrices, whole-matrix scaling by $c$ multiplies the determinant by $c^4$, while transposition leaves it unchanged.

2. Apply each listed property to the stated part of the question.

    - $\det(2A)=2^4\det(A)=16(-3)=-48$
    - $\det(-A)=(-1)^4\det(A)=1\cdot(-3)=-3$
    - $\det(A^2)=[\det(A)]^2=9$
    - $\det(A^{-1})=1/\det(A)=-1/3$

3. Also use $\det(A^2)=(\det A)^2$ and $\det(A^{-1})=1/\det A$; each computation starts from the given $\det A=-3$, not from a guessed matrix.
::::
:::

:::problem[Problem M.3 — Triangular four-by-four]{difficulty=standard}
Compute by row reduction: $\det\begin{bmatrix}2&-1&3&1\\0&4&-2&0\\0&0&3&5\\0&0&0&-2\end{bmatrix}$.

::::solution[Solution]
**Answer:** $\det A=-48$.

1. The matrix is already upper triangular; row reduction is unnecessary. Multiply its diagonal entries, including both negative factors.

2. Already upper triangular. $\det=(2)(4)(3)(-2)=-48$.

3. First $2\cdot4=8$, then $8\cdot3=24$, and finally $24(-2)=-48$. The off-diagonal entries do not enter the triangular determinant formula.
::::
:::

:::problem[Problem M.4 — Swap-sign proof]{difficulty=standard}
Use cofactor expansion to show that swapping two rows of a $2\times2$ matrix negates its determinant.
 That is, show $\det\begin{bmatrix}c&d\\a&b\end{bmatrix}=-\det\begin{bmatrix}a&b\\c&d\end{bmatrix}$.

::::solution[Solution]
**Answer:** Swapping two rows negates the determinant: $\det\begin{bmatrix}c&d\\a&b\end{bmatrix}=-(ad-bc)$.

1. Write the original $2\times2$ determinant as $ad-bc$. After swapping rows, the new diagonal products appear in the reversed order.

2. $\det\begin{bmatrix}a&b\\c&d\end{bmatrix}=ad-bc$.

3. $\det\begin{bmatrix}c&d\\a&b\end{bmatrix}=cb-da=-(ad-bc)=-\det\begin{bmatrix}a&b\\c&d\end{bmatrix}.\quad\checkmark$

4. The swapped matrix has determinant $cb-da=bc-ad=-(ad-bc)$, exactly the negative of the original. This is an algebraic proof valid for arbitrary real entries.
::::
:::

:::problem[Problem M.5 — Adjugate identity]{difficulty=challenge}
The *adjugate* (classical adjoint) of a $2\times2$ matrix is $\text{adj}(A)=\begin{bmatrix}d&-b\\-c&a\end{bmatrix}$.
 Show that $A\,\text{adj}(A) = \det(A)\cdot I$, which gives another route to the inverse formula.

::::solution[Solution]
**Answer:** $A\operatorname{adj}(A)=\det(A)I_2$.

1. Multiply $\begin{bmatrix}a&b\\c&d\end{bmatrix}$ by its adjugate $\begin{bmatrix}d&-b\\-c&a\end{bmatrix}$ entry by entry.

2. Calculate the next cofactor or determinant term with its indicated sign:

    $$
    A\,\text{adj}(A)=\begin{bmatrix}a&b\\c&d\end{bmatrix}\begin{bmatrix}d&-b\\-c&a\end{bmatrix}
              =\begin{bmatrix}ad-bc&-ab+ab\\cd-cd&-bc+ad\end{bmatrix}
              =\begin{bmatrix}ad-bc&0\\0&ad-bc\end{bmatrix}=(ad-bc)I=\det(A)\cdot I.
    $$

3. If $\det(A)\neq0$, dividing both sides by $\det(A)$ gives $A\cdot\frac{\text{adj}(A)}{\det(A)}=I$, so $A^{-1}=\frac{1}{\det(A)}\text{adj}(A)$. $\square$

4. The off-diagonal entries cancel because $-ab+ab=0$ and $cd-dc=0$. Both diagonal entries are $ad-bc$, so the product equals $(ad-bc)I_2=\det(A)I_2$.
::::
:::

:::problem[Problem M.6 — Triangle area]{difficulty=challenge}
Find the area of the triangle with vertices $P_1=(1,2)$, $P_2=(4,3)$, $P_3=(2,6)$
 using a determinant formula. (Hint: the area of a triangle with two side vectors
 $\mathbf{u},\mathbf{v}$ is $\frac{1}{2}|\det[\mathbf{u}\ \mathbf{v}]|$.)

::::solution[Solution]
**Answer:** Area $=11/2$.

1. Subtract the coordinates of $P_1$ from the other vertices to obtain two side vectors: $P_2-P_1=(3,1)$ and $P_3-P_1=(1,4)$.

2. Translate so one vertex is at the origin: side vectors from $P_1$:

3. $\mathbf{u}=P_2-P_1=(3,1)^T$, $\mathbf{v}=P_3-P_1=(1,4)^T$.

4. Calculate the next cofactor or determinant term with its indicated sign:

    $$
    \det\begin{bmatrix}3&1\\1&4\end{bmatrix}=12-1=11.
    $$

5. $\text{Area}=\frac{1}{2}|11|=\frac{11}{2}=5.5$ square units.

6. The determinant $3(4)-1(1)=11$ gives signed parallelogram area. Divide its absolute value by $2$ to get triangle area $11/2$ square units.
::::
:::

---

Chapter 3 · Linear Algebra · Based on MA 3113, Mississippi State University.
 Primary source: Dr. Seongjai Kim's lecture notes.

:::problem[Problem M.7 — Detect a row-operation sign]{difficulty=easy}
$A$ has $\det A=5$. One row swap produces $B$. Find $\det B$.

::::solution[Solution]
**Answer:** $-5$.

1. A row exchange changes the orientation of the determinant, reversing its sign without changing its absolute magnitude.

2. $-5$. Exactly one row swap multiplies the determinant by $-1$, giving $-5$.

3. Thus $\det B=(-1)\det A=(-1)(5)=-5$. The answer is negative because precisely one swap, not two, was performed.
::::
:::

:::problem[Problem M.8 — Singular without expansion]{difficulty=easy}
Determine $\det\begin{bmatrix}1&0&2\\0&1&3\\1&1&5\end{bmatrix}$ and explain your shortcut.

::::solution[Solution]
**Answer:** $0$.

1. Check for an obvious linear dependence instead of expanding the determinant. The third row is the sum of the first two.

2. $0$. Row 3 equals row 1 plus row 2, so the rows are dependent. Alternatively $R_3\gets R_3-R_1-R_2$ creates a zero row without changing the determinant.

3. Apply $R_3\leftarrow R_3-R_1-R_2$ to get a zero row. This row replacement does not change the determinant; a matrix with a zero row has determinant zero.
::::
:::

:::problem[Problem M.9 — Work backward before properties]{difficulty=standard}
Row replacements and exactly two row swaps transform a $3\times3$ matrix $A$ into $U=\begin{bmatrix}1&4&0\\0&2&3\\0&0&-5\end{bmatrix}$. Find $\det A$, $\det(A^{-1})$ and $\det(-A)$.

::::solution[Solution]
**Answer:** $\det A=-10$, $\det(A^{-1})=-\tfrac1{10}$, $\det(-A)=10$.

1. Read the upper-triangular diagonal, then reverse the determinant effects of the row operations. Row replacements do nothing and two swaps cancel their signs.

2. $-10,-\tfrac1{10},10$. $\det U=(1)(2)(-5)=-10$. Two swaps produce $(-1)^2=1$, so $\det A=-10$. The inverse determinant is $-1/10$. Since $A$ is $3\times3$, $\det(-A)=(-1)^3(-10)=10$.

3. Thus $\det A=1\cdot2\cdot(-5)=-10$. Its inverse determinant is $-1/10$. Scaling all three rows by $-1$ gives $\det(-A)=(-1)^3(-10)=10$.
::::
:::

:::problem[Problem M.10 — A parameter in a 3×3]{difficulty=standard}
Find the values of $h$ such that $A=\begin{bmatrix}1&0&2\\0&h&1\\0&2&h\end{bmatrix}$ is singular.

::::solution[Solution]
**Answer:** $h=\pm\sqrt2$.

1. Expand along the first column, which contains two zeros. The only surviving cofactor is the lower-right $2\times2$ determinant.

2. $h=\pm\sqrt2$. Expand down column 1 to get $h^2-2$. Setting $h^2-2=0$ yields $h^2=2$ and $h=\pm\sqrt2$.

3. Evaluate $h\cdot h-1\cdot2=h^2-2$. Singularity means $h^2-2=0$, hence $h^2=2$ and $h=\pm\sqrt2$.
::::
:::

:::problem[Problem M.11 — Volume, then triangle]{difficulty=standard}
The planar vectors $\mathbf{u}=(-2,1)^T$ and $\mathbf{v}=(1,3)^T$ form two edges from the same point. Find their parallelogram area and the triangle area.

::::solution[Solution]
**Answer:** parallelogram $7$, triangle $7/2$. $\det\begin{bmatrix}-2&1\\1&3\end{bmatrix}=(-2)(3)-(1)(1)=-7$. Take absolute value $7$; take half for the triangle.

1. Use the two planar vectors as the columns of a $2\times2$ matrix. The absolute determinant gives the parallelogram area.

2. parallelogram $7$, triangle $7/2$. $\det\begin{bmatrix}-2&1\\1&3\end{bmatrix}=(-2)(3)-(1)(1)=-7$. Take absolute value $7$; take half for the triangle.

3. Compute $(-2)(3)-1(1)=-6-1=-7$. Its magnitude is $7$, and the triangle sharing those edges has half that area, $7/2$.
::::
:::

:::problem[Problem M.12 — When an inverse does not exist]{difficulty=challenge}
For $A=\begin{bmatrix}2&-1&3\\0&1&4\\0&0&0\end{bmatrix}$, decide whether $A^{-1}$ or $\operatorname{adj}(A)$ exists, and state $\det A$.

::::solution[Solution]
**Answer:** $\det A=0$, $A^{-1}$ does not exist, but $\operatorname{adj}(A)$ does exist.

1. The matrix is upper triangular, so its determinant is the product of its diagonal entries. One diagonal entry is zero.

2. $\det A=0$, $A^{-1}$ does not exist, but $\operatorname{adj}(A)$ does exist. The zero diagonal in this upper triangular matrix gives determinant zero. Cofactors and the adjugate are defined even when their matrix is singular; only division by the determinant is prohibited.

3. The product $2\cdot1\cdot0=0$ makes the matrix singular and prevents an inverse. The adjugate, however, is defined by cofactors even for singular square matrices.
::::
:::
