---
source: "markdown"
title: "Practice Quiz 1 C: Realistic Worst Case"
crumb: "Linear Algebra · Chapter 5 quiz prep"
meta:
  - "MA 3113 · Pant · no calculator"
  - "Time limit: 50 minutes"
  - "Chapter 5: 5.1–5.3, 5.5, 5.7, 5.9"
---

## Instructions

No calculator. Write enough arithmetic to justify every determinant, eigenspace, and conclusion. Choose exactly one option (A)–(E) on each multiple-choice question; (E) always means “I don't know.” For free response, show the shortest correct by-hand method, including a check when possible. Solutions are collapsed in Lectern; attempt the question before opening one.

### Multiple Choice

:::problem[Problem 1 — One zero coordinate and a false eigenpair]{difficulty=standard}

Decide whether the displayed nonzero vector is an eigenvector of $A$ for the stated eigenvalue. Give the decisive multiplication.

$$
A=\begin{bmatrix}2&1\\1&2\end{bmatrix}
$$

$$
\mathbf v=\begin{bmatrix}1\\0\end{bmatrix}
$$
Proposed $\lambda=2$.

(A) Yes; the proposed eigenpair works.

(B) No; only diagonal matrices have eigenvectors.

(C) Yes; checking the first coordinate alone is sufficient.

(D) No; the proposed eigenpair fails.

(E) I don't know

::::solution[Solution]
**Answer:** (D) No; the proposed eigenpair fails.

1. The proposed vector is nonzero, so it is eligible for the eigenvector definition $A\mathbf v=\lambda\mathbf v$.

2. Multiply one row at a time: 
   
   $$
   A\mathbf v=\begin{bmatrix}2\\1\end{bmatrix}
   $$
   
   
   The displayed entries come from the dot products of the rows with $\mathbf v$.

3. The proposed multiple is 
   
   $$
   2\mathbf v=\begin{bmatrix}2\\0\end{bmatrix}
   $$
   
   
   Compare both coordinates, including any zero component.

4. At least one coordinate differs, so the proposed eigenpair fails. A matching first coordinate is insufficient.

5. Check: direct multiplication is decisive; a characteristic-polynomial computation would be unnecessary for this question.

::::

:::
:::problem[Problem 2 — Sparse cofactor with the sign trap]{difficulty=challenge}

Compute $\det(A-\lambda I)$.

$$
A=\begin{bmatrix}2&1&0\\0&0&1\\0&4&0\end{bmatrix}
$$

(A) Characteristic polynomial: $- \lambda^{3} + 2 \lambda^{2} + 4 \lambda - 7$.

(B) Characteristic polynomial: $- \lambda^{3} + 2 \lambda^{2} + 4 \lambda - 9$.

(C) Characteristic polynomial: $- \lambda^{3} + 2 \lambda^{2} + 4 \lambda - 8$.

(D) Characteristic polynomial: $\lambda^{3} - 2 \lambda^{2} - 4 \lambda + 8$.

(E) I don't know

::::solution[Solution]
**Answer:** (C) Characteristic polynomial: $- \lambda^{3} + 2 \lambda^{2} + 4 \lambda - 8$.

1. Start by subtracting $\lambda$ from **every diagonal entry** and leaving the off-diagonal entries alone: 
   
   $$
   A-\lambda I=\begin{bmatrix}2 - \lambda&1&0\\0&- \lambda&1\\0&4&- \lambda\end{bmatrix}
   $$

2. Expand along column 1, where 2 entries vanish; the cofactor signs alternate across each row and column.

3. The surviving signed minors give 
   
   $$
   \det(A-\lambda I)=(2 - \lambda)\det\begin{bmatrix}- \lambda&1\\4&- \lambda\end{bmatrix}
   $$

4. Evaluate each $2\times2$ minor explicitly using $ad-bc$ before expanding: 
   
   $$
   +(2 - \lambda)\left[(- \lambda)(- \lambda)-(1)(4)\right]
   $$

5. Multiply and collect like powers of $\lambda$: 
   
   $$
   \det(A-\lambda I)=- \lambda^{3} + 2 \lambda^{2} + 4 \lambda - 8
   $$

6. Factor the polynomial and set it equal to zero: 
   
   $$
   - \left(\lambda - 2\right)^{2} \left(\lambda + 2\right)=0.
   $$
   
   
   Thus the roots, including their repetitions, are $-2,2,2$.

7. Check: the root sum is $2$, which matches $\operatorname{tr}(A)=2$; their product is $-8=\det A$.

::::

:::
:::problem[Problem 3 — A repeated root has only one direction]{difficulty=standard}

What is the geometric multiplicity of the indicated eigenvalue?

$$
A=\begin{bmatrix}4&1&0\\0&4&1\\0&0&4\end{bmatrix}
$$

Given $\lambda=4$.

(A) Geometric multiplicity: $0$.

(B) Geometric multiplicity: $1$.

(C) Geometric multiplicity: $2$.

(D) Geometric multiplicity: $3$.

(E) I don't know

::::solution[Solution]
**Answer:** (B) Geometric multiplicity: $1$.

1. Form $A-\lambda I$ with the **given** eigenvalue: 
   
   $$
   A-(4)I=\begin{bmatrix}0&1&0\\0&0&1\\0&0&0\end{bmatrix}
   $$

2. No row operation is necessary because the nonzero equations already show the pivot and free columns.

3. Pivot columns are 2, 3; free variables are $x_1$. Each free variable supplies one independent eigendirection.

4. Set one free variable at a time to one, and the others to zero; clear any denominators. A basis is 
   
   $$
   \begin{bmatrix}1\\0\\0\end{bmatrix}
   $$
   
   
   Therefore $\dim E_{4}=1$.

5. Check: $A\mathbf v_1=4\mathbf v_1$ for the displayed basis columns. They also solve the homogeneous equations.

::::

:::
:::problem[Problem 4 — Non-similarity hidden by a shared polynomial]{difficulty=challenge}

The matrices have the same eigenvalues, with multiplicity. Must they be similar? Decide for this specific pair using eigenspace dimensions.

$$
A=\begin{bmatrix}1&0&0\\0&1&0\\0&0&2\end{bmatrix}
$$

$$
B=\begin{bmatrix}1&1&0\\0&1&0\\0&0&2\end{bmatrix}
$$

(A) Not similar.

(B) Similar.

(C) Not similar because one matrix has more entries.

(D) Similar whenever their traces are equal.

(E) I don't know

::::solution[Solution]
**Answer:** (A) Not similar.

1. Both matrices have characteristic roots $1,1,2$. Equal eigenvalues are necessary for similarity, but **not sufficient**.

2. For each repeated root, compare null-space dimensions. In $A$, the eigenspace dimensions are $1: 2$, $2: 1$.

3. In $B$, they are $1: 1$, $2: 1$.

4. The dimensions differ, so these matrices cannot be similar. Similar matrices preserve nullity at every eigenvalue.

5. Check: trace and determinant can agree for two matrices that are still not similar. The eigenspace comparison supplies the missing evidence.

::::

:::
:::problem[Problem 5 — Oblique eigenspace directions]{difficulty=challenge}

Which statement gives a basis and dimension for the indicated eigenspace?

$$
A=\begin{bmatrix}3&1&0\\1&3&0\\0&0&2\end{bmatrix}
$$

Given $\lambda=4$.

(A) Basis for $E_{4}$: $(2,1,0)^T$; dimension $1$.

(B) Basis for $E_{4}$: $(3,1,0)^T$; dimension $1$.

(C) Basis for $E_{4}$: $(0,1,0)^T$; dimension $1$.

(D) Basis for $E_{4}$: $(1,1,0)^T$; dimension $1$.

(E) I don't know

::::solution[Solution]
**Answer:** (D) Basis for $E_{4}$: $(1,1,0)^T$; dimension $1$.

1. Form $A-\lambda I$ with the **given** eigenvalue: 
   
   $$
   A-(4)I=\begin{bmatrix}-1&1&0\\1&-1&0\\0&0&-2\end{bmatrix}
   $$

2. Divide row 1 by $-1$ to make its pivot $1$. 
   
   $$
   \begin{bmatrix}1&-1&0\\1&-1&0\\0&0&-2\end{bmatrix}
   $$

3. Use $R_2\leftarrow R_2-(1)R_1$ to clear column 1. 
   
   $$
   \begin{bmatrix}1&-1&0\\0&0&0\\0&0&-2\end{bmatrix}
   $$

4. Swap $R_2$ with $R_3$ to put a nonzero pivot first. 
   
   $$
   \begin{bmatrix}1&-1&0\\0&0&-2\\0&0&0\end{bmatrix}
   $$

5. Divide row 2 by $-2$ to make its pivot $1$. 
   
   $$
   \begin{bmatrix}1&-1&0\\0&0&1\\0&0&0\end{bmatrix}
   $$

6. Pivot columns are 1, 3; free variables are $x_2$. Each free variable supplies one independent eigendirection.

7. Set one free variable at a time to one, and the others to zero; clear any denominators. A basis is 
   
   $$
   \begin{bmatrix}1\\1\\0\end{bmatrix}
   $$
   
   
   Therefore $\dim E_{4}=1$.

8. Check: $A\mathbf v_1=4\mathbf v_1$ for the displayed basis columns. They also solve the homogeneous equations.

::::

:::
:::problem[Problem 6 — Use trace and determinant to detect complex roots]{difficulty=standard}

Find the (possibly complex) eigenvalues of $A$ exactly.

$$
A=\begin{bmatrix}3&-2\\2&3\end{bmatrix}
$$

(A) Eigenvalues: $3\pm 3i$.

(B) Eigenvalues: $4\pm 2i$.

(C) Eigenvalues: $3\pm 2i$.

(D) Eigenvalues: $3\pm 2$.

(E) I don't know

::::solution[Solution]
**Answer:** (C) Eigenvalues: $3\pm 2i$.

1. Start with $A-\lambda I$ and its $2\times2$ determinant: 
   
   $$
   \begin{bmatrix}3 - \lambda&-2\\2&3 - \lambda\end{bmatrix}
   $$
   
   
   The polynomial is $\lambda^{2} - 6 \lambda + 13$.

2. Complete the square or use the quadratic equation. The equation $\lambda^{2} - 6 \lambda + 13=0$ has a negative discriminant, so its roots have nonzero imaginary parts.

3. The complex roots are $3\pm 2i$. Because the matrix is real, one conjugate root always accompanies the other.

4. Check: the roots sum to $6$ and their product is $13$, matching the trace and determinant.

::::

:::
:::problem[Problem 7 — Real-block angle and direction]{difficulty=standard}

Treat $A$ as the real rotation–scaling block. State the scale and the direction of rotation.

$$
A=\begin{bmatrix}0&2\\-2&0\end{bmatrix}
$$

(A) Scale $2$; counterclockwise rotation.

(B) Scale $2$; clockwise rotation.

(C) Scale $0$; clockwise rotation.

(D) Scale $3$; clockwise rotation.

(E) I don't know

::::solution[Solution]
**Answer:** (B) Scale $2$; clockwise rotation.

1. Identify the real block: 
   
   $$
   A=\begin{bmatrix}0&2\\-2&0\end{bmatrix}
   $$
   
   
   It has the form 
   
   $$
   \begin{bmatrix}a&-b\\b&a\end{bmatrix}
   $$
   
   
   with $a=0$ and $b=-2$.

2. The length scale is $r=\sqrt{a^2+b^2}=\sqrt{0+4}=2$. It is not just the diagonal entry $a$.

3. Because $b<0$, the orientation is clockwise. The sine and cosine of the angle are $b/r$ and $a/r$.

4. Check: the determinant is $4=r^2$, as expected for a rotation followed by a uniform stretch.

::::

:::
:::problem[Problem 8 — Zero eigenvalue does not imply a saddle]{difficulty=challenge}

Classify the trajectories near the origin of $\mathbf{x}\prime=A\mathbf{x}$. Do not solve for coefficients.

$$
A=\begin{bmatrix}0&0\\0&-2\end{bmatrix}
$$

(A) Trajectory: Line of equilibria with transverse decay.

(B) Trajectory: Saddle.

(C) Trajectory: Stable node.

(D) Trajectory: Unstable node.

(E) I don't know

::::solution[Solution]
**Answer:** (A) Trajectory: Line of equilibria with transverse decay.

1. Inspect the eigenvalues without solving for constants: $-2,0$. For a diagonal or triangular matrix, they are its diagonal entries.

2. Positive real parts make exponential modes grow; negative real parts make them decay. A nonzero imaginary part adds rotation.

3. Applying those signs to **both** modes gives line of equilibria with transverse decay. A trajectory type cannot be inferred from only one eigenvalue.

4. Check: with a zero eigenvalue, the equilibrium is nonisolated or otherwise degenerate; avoid mislabelling it as a saddle.

::::

:::
:::problem[Problem 9 — A periodic Markov chain]{difficulty=challenge}

Is this column-stochastic matrix regular? Does its regularity guarantee convergence from every initial probability vector?

$$
P=\begin{bmatrix}0&1\\1&0\end{bmatrix}
$$

(A) Regular; convergence is guaranteed.

(B) Not regular because it has a steady state.

(C) Not regular; convergence is not guaranteed by regularity.

(D) Regular because its columns sum to $1$.

(E) I don't know

::::solution[Solution]
**Answer:** (C) Not regular; convergence is not guaranteed by regularity.

1. First verify column stochasticity: the columns sum to one and every entry is nonnegative.

2. Regular means **some positive integer power** has every entry strictly positive. Test successive powers, not just whether a steady vector exists.

3. For this alternating two-state matrix, 
   
   $$
   P^2=\begin{bmatrix}1&0\\0&1\end{bmatrix},\qquad P^3=\begin{bmatrix}0&1\\1&0\end{bmatrix}
   $$
   
   
   The powers alternate, and each has zero entries, so no positive power is all-positive.

4. Check the failure of convergence explicitly: starting from the first state, successive distributions alternate between the two states. A steady vector can exist without attracting every initial distribution.

::::

:::
:::problem[Problem 10 — Negative entries break stochasticity]{difficulty=standard}

Is this a valid column-stochastic transition matrix?

$$
P=\begin{bmatrix}2&1\\-1&0\end{bmatrix}
$$

(A) Valid column-stochastic matrix.

(B) Not column-stochastic.

(C) Valid because some columns sum to $1$.

(D) Valid because it is a square matrix.

(E) I don't know

::::solution[Solution]
**Answer:** (B) Not column-stochastic.

1. A column-stochastic matrix must have nonnegative entries, and every **column** must sum to one. The rows do not need to sum to one.

2. The column sums are $1$, $1$. Check every entry separately for a negative probability.

3. At least one condition fails; therefore this is not a valid column-stochastic matrix.

4. Check: a sum of one alone does not rescue a negative entry. The definition requires **both** conditions.

::::

:::
### Written Free Response

:::problem[Problem 11 — Cofactor roots plus a deficient eigenspace]{difficulty=challenge}

Determine whether $A$ is diagonalizable. Justify using eigenvalues and eigenspace dimensions.

$$
A=\begin{bmatrix}2&1&0\\0&3&1\\0&1&3\end{bmatrix}
$$

::::solution[Solution]
**Answer:** Not diagonalizable.

1. Compute the characteristic polynomial and factor it: 
   
   $$
   - \left(\lambda - 4\right) \left(\lambda - 2\right)^{2}=0.
   $$
   
   
   The eigenvalues, counted with algebraic multiplicity, are $2,2,4$.

2. For $\lambda=4$, 
   
   $$
   A-\lambda I=\begin{bmatrix}-2&1&0\\0&-1&1\\0&1&-1\end{bmatrix}
   $$
   
   
   Its null-space dimension is $1$, whereas its algebraic multiplicity is $1$.

3. Divide row 1 by $-2$ to make its pivot $1$. 
   
   $$
   \begin{bmatrix}1&- \frac{1}{2}&0\\0&-1&1\\0&1&-1\end{bmatrix}
   $$

4. Divide row 2 by $-1$ to make its pivot $1$. 
   
   $$
   \begin{bmatrix}1&- \frac{1}{2}&0\\0&1&-1\\0&1&-1\end{bmatrix}
   $$

5. Use $R_1\leftarrow R_1-(- \frac{1}{2})R_2$ to clear column 2. 
   
   $$
   \begin{bmatrix}1&0&- \frac{1}{2}\\0&1&-1\\0&1&-1\end{bmatrix}
   $$

6. Use $R_3\leftarrow R_3-(1)R_2$ to clear column 2. 
   
   $$
   \begin{bmatrix}1&0&- \frac{1}{2}\\0&1&-1\\0&0&0\end{bmatrix}
   $$

7. The shifted matrix has 2 pivot columns and 1 free variables. The free-variable count is the eigenspace dimension.

8. For $\lambda=2$, 
   
   $$
   A-\lambda I=\begin{bmatrix}0&1&0\\0&1&1\\0&1&1\end{bmatrix}
   $$
   
   
   Its null-space dimension is $1$, whereas its algebraic multiplicity is $2$.

9. Use $R_2\leftarrow R_2-(1)R_1$ to clear column 2. 
   
   $$
   \begin{bmatrix}0&1&0\\0&0&1\\0&1&1\end{bmatrix}
   $$

10. Use $R_3\leftarrow R_3-(1)R_1$ to clear column 2. 
   
   $$
   \begin{bmatrix}0&1&0\\0&0&1\\0&0&1\end{bmatrix}
   $$

11. Use $R_3\leftarrow R_3-(1)R_2$ to clear column 3. 
   
   $$
   \begin{bmatrix}0&1&0\\0&0&1\\0&0&0\end{bmatrix}
   $$

12. The shifted matrix has 2 pivot columns and 1 free variables. The free-variable count is the eigenspace dimension.

13. The dimensions of the eigenspaces do **not** add to the matrix size; no invertible matrix of eigenvectors $P$ exists.

14. Check: compare geometric multiplicity to algebraic multiplicity for **each** repeated root. The repeated root alone does not decide the verdict.

**What earns the points:**

- [ ] Characteristic roots and multiplicities.
- [ ] A null-space dimension count.
- [ ] A specific reason for success or failure.

::::

:::
:::problem[Problem 12 — Repeated eigenvalue with enough eigenvectors]{difficulty=challenge}

Diagonalize $A$ by finding $P,D$ with $A=PDP^{-1}$, or show that it is impossible. Check $AP=PD$.

$$
A=\begin{bmatrix}2&1&0\\1&2&0\\0&0&1\end{bmatrix}
$$

::::solution[Solution]
**Answer:** Columns of $P$: $(-1,1,0)^T,(0,0,1)^T,(1,1,0)^T$; diagonal of $D$: $1,1,3$.

1. Find the characteristic roots first: 
   
   $$
   - \left(\lambda - 3\right) \left(\lambda - 1\right)^{2}=0.
   $$
   
   
   The roots are $1,1,3$.

2. Solve $\operatorname{Nul}(A-(1)I)$; one basis set for this eigenspace is 
   
   $$
   \begin{bmatrix}-1\\1\\0\end{bmatrix},\qquad\begin{bmatrix}0\\0\\1\end{bmatrix}
   $$

3. The shifted system begins with 
   
   $$
   A-(1)I=\begin{bmatrix}1&1&0\\1&1&0\\0&0&0\end{bmatrix}
   $$

4. Use $R_2\leftarrow R_2-(1)R_1$ to clear column 1. 
   
   $$
   \begin{bmatrix}1&1&0\\0&0&0\\0&0&0\end{bmatrix}
   $$

5. There are 2 free variables. Set them independently to obtain the displayed eigenbasis.

6. Solve $\operatorname{Nul}(A-(3)I)$; one basis set for this eigenspace is 
   
   $$
   \begin{bmatrix}1\\1\\0\end{bmatrix}
   $$

7. The shifted system begins with 
   
   $$
   A-(3)I=\begin{bmatrix}-1&1&0\\1&-1&0\\0&0&-2\end{bmatrix}
   $$

8. Divide row 1 by $-1$ to make its pivot $1$. 
   
   $$
   \begin{bmatrix}1&-1&0\\1&-1&0\\0&0&-2\end{bmatrix}
   $$

9. Use $R_2\leftarrow R_2-(1)R_1$ to clear column 1. 
   
   $$
   \begin{bmatrix}1&-1&0\\0&0&0\\0&0&-2\end{bmatrix}
   $$

10. Swap $R_2$ with $R_3$ to put a nonzero pivot first. 
   
   $$
   \begin{bmatrix}1&-1&0\\0&0&-2\\0&0&0\end{bmatrix}
   $$

11. Divide row 2 by $-2$ to make its pivot $1$. 
   
   $$
   \begin{bmatrix}1&-1&0\\0&0&1\\0&0&0\end{bmatrix}
   $$

12. There are 1 free variables. Set them independently to obtain the displayed eigenbasis.

13. There are 3 independent eigenvectors. Put them in columns of $P$; put their eigenvalues in the **matching** order on the diagonal of $D$: 
   
   $$
   P=\begin{bmatrix}-1&0&1\\1&0&1\\0&1&0\end{bmatrix},\qquad D=\begin{bmatrix}1&0&0\\0&1&0\\0&0&3\end{bmatrix}
   $$

14. Check multiplication directly, without wasting time finding $P^{-1}$: 
   
   $$
   AP=\begin{bmatrix}-1&0&3\\1&0&3\\0&1&0\end{bmatrix}=PD=\begin{bmatrix}-1&0&3\\1&0&3\\0&1&0\end{bmatrix}
   $$
   
   
   Since $\det P=2\ne0$, $P$ is invertible and $A=PDP^{-1}$.

**What earns the points:**

- [ ] Eigenvalues and basis columns.
- [ ] Consistent order in $P,D$.
- [ ] The check $AP=PD$ and invertibility of $P$.

::::

:::
:::problem[Problem 13 — A nonstandard complex eigenvector basis]{difficulty=challenge}

The real vectors $\mathbf p,\mathbf q$ are the real and imaginary parts of a complex eigenvector for $A$. Form $P=[\mathbf p\ \mathbf q]$, compute $C=P^{-1}AP$ by the relation $AP=PC$, and identify the corresponding eigenvalue $a-bi$.

$$
A=\begin{bmatrix}2&-2\\4&-2\end{bmatrix}
$$

$$
\mathbf p=\begin{bmatrix}1\\1\end{bmatrix},\qquad\mathbf q=\begin{bmatrix}0\\1\end{bmatrix}
$$

::::solution[Solution]
**Answer:** Real block diagonals $0,0$; off-diagonals $-2,2$.

1. Split the given complex eigenvector as $\mathbf v=\mathbf p+i\mathbf q$. The stated real column order is $P=[\mathbf p\ \mathbf q]$: 
   
   $$
   P=\begin{bmatrix}1&0\\1&1\end{bmatrix}
   $$

2. Compute how $A$ acts on these two real columns: 
   
   $$
   A\mathbf p=\begin{bmatrix}0\\2\end{bmatrix},\qquad A\mathbf q=\begin{bmatrix}-2\\-2\end{bmatrix}
   $$

3. Express those images in the basis $\mathbf p,\mathbf q$. The coefficient columns give 
   
   $$
   C=\begin{bmatrix}0&-2\\2&0\end{bmatrix}
   $$
   
   
   so $AP=PC$.

4. With this convention, 
   
   $$
   C=\begin{bmatrix}a&-b\\b&a\end{bmatrix}
   $$
   
   
   The corresponding complex eigenvalue is $a-bi=- 2 i$. This sign follows by expanding $A(\mathbf p+i\mathbf q)$.

5. Check: 
   
   $$
   AP=\begin{bmatrix}0&-2\\2&-2\end{bmatrix}=PC=\begin{bmatrix}0&-2\\2&-2\end{bmatrix}
   $$
   
   
   Also $\det P=1\ne0$, so this is a genuine real change of basis.

**What earns the points:**

- [ ] Real and imaginary eigenvector parts.
- [ ] The signed real block.
- [ ] The equality $AP=PC$.

::::

:::
:::problem[Problem 14 — Coupled saddle IVP with fractional constants]{difficulty=challenge}

Solve $\mathbf{x}\prime(t)=A\mathbf{x}(t)$ with the specified initial vector. Give the qualitative trajectory type and check the initial condition.

$$
A=\begin{bmatrix}2&1\\0&-1\end{bmatrix}
$$

$$
\mathbf{x}(0)=\begin{bmatrix}1\\2\end{bmatrix}
$$

::::solution[Solution]
**Answer:** Solution: $\mathbf{x}(t)=(\frac{5 e^{2 t}}{3} - \frac{2 e^{- t}}{3},2 e^{- t})^T$; saddle.

1. The eigenvalues are $-1,2$. Solve their homogeneous systems and choose eigenvector columns: 
   
   $$
   P=\begin{bmatrix}-1&1\\3&0\end{bmatrix},\qquad D=\begin{bmatrix}-1&0\\0&2\end{bmatrix}
   $$

2. Because each eigenvector satisfies $A\mathbf v_j=\lambda_j\mathbf v_j$, a solution along it has factor $e^{\lambda_jt}$. Add these modes: 
   
   $$
   \mathbf x(t)=c_1e^{-1t}\begin{bmatrix}-1\\3\end{bmatrix} + c_2e^{2t}\begin{bmatrix}1\\0\end{bmatrix}
   $$

3. At $t=0$, every exponential equals one, so $P\mathbf c=\mathbf x_0$. Substitute the initial vector and solve the ordinary linear equations; the constants are 
   
   $$
   \mathbf c=\begin{bmatrix}\frac{2}{3}\\\frac{5}{3}\end{bmatrix}
   $$

4. Insert those coefficients into the exponential modes and combine components: 
   
   $$
   \mathbf x(t)=\begin{bmatrix}\frac{5 e^{2 t}}{3} - \frac{2 e^{- t}}{3}\\2 e^{- t}\end{bmatrix}
   $$
   
   
   The eigenvalue signs identify the trajectory as saddle.

5. Check: at zero this becomes 
   
   $$
   \mathbf x(0)=\begin{bmatrix}1\\2\end{bmatrix}
   $$
   
   
   which equals the stated starting vector. Differentiating each eigenmode gives $\mathbf x\prime=A\mathbf x$.

**What earns the points:**

- [ ] Eigenmodes and correct exponentials.
- [ ] Initial-condition equations for coefficients.
- [ ] Solution and verification.

::::

:::
:::problem[Problem 15 — Three-state Markov dynamics and equilibrium]{difficulty=challenge}

Find the normalized steady-state probability vector of the column-stochastic matrix $P$. Also compute the distribution after two steps from the supplied starting state.

$$
P=\begin{bmatrix}\frac{1}{2}&\frac{1}{3}&0\\\frac{1}{2}&\frac{1}{3}&\frac{1}{4}\\0&\frac{1}{3}&\frac{3}{4}\end{bmatrix}
$$

$$
\mathbf{x}_0=\begin{bmatrix}1\\0\\0\end{bmatrix}
$$

::::solution[Solution]
**Answer:** Steady state: $(\frac{2}{9},\frac{1}{3},\frac{4}{9})^T$. After two steps: $(\frac{5}{12},\frac{5}{12},\frac{1}{6})^T$.

1. Check the column convention: every entry is nonnegative, and the columns of $P$ sum to one. Seek a probability vector satisfying $P\mathbf q=\mathbf q$.

2. Move all terms to the same side: 
   
   $$
   (P-I)\mathbf q=\mathbf0,\qquad P-I=\begin{bmatrix}- \frac{1}{2}&\frac{1}{3}&0\\\frac{1}{2}&- \frac{2}{3}&\frac{1}{4}\\0&\frac{1}{3}&- \frac{1}{4}\end{bmatrix}
   $$

3. Divide row 1 by $- \frac{1}{2}$ to make its pivot $1$. 
   
   $$
   \begin{bmatrix}1&- \frac{2}{3}&0\\\frac{1}{2}&- \frac{2}{3}&\frac{1}{4}\\0&\frac{1}{3}&- \frac{1}{4}\end{bmatrix}
   $$

4. Use $R_2\leftarrow R_2-(\frac{1}{2})R_1$ to clear column 1. 
   
   $$
   \begin{bmatrix}1&- \frac{2}{3}&0\\0&- \frac{1}{3}&\frac{1}{4}\\0&\frac{1}{3}&- \frac{1}{4}\end{bmatrix}
   $$

5. Divide row 2 by $- \frac{1}{3}$ to make its pivot $1$. 
   
   $$
   \begin{bmatrix}1&- \frac{2}{3}&0\\0&1&- \frac{3}{4}\\0&\frac{1}{3}&- \frac{1}{4}\end{bmatrix}
   $$

6. Use $R_1\leftarrow R_1-(- \frac{2}{3})R_2$ to clear column 2. 
   
   $$
   \begin{bmatrix}1&0&- \frac{1}{2}\\0&1&- \frac{3}{4}\\0&\frac{1}{3}&- \frac{1}{4}\end{bmatrix}
   $$

7. Use $R_3\leftarrow R_3-(\frac{1}{3})R_2$ to clear column 2. 
   
   $$
   \begin{bmatrix}1&0&- \frac{1}{2}\\0&1&- \frac{3}{4}\\0&0&0\end{bmatrix}
   $$

8. The null-space equations give a direction 
   
   $$
   \mathbf v=\begin{bmatrix}\frac{1}{2}\\\frac{3}{4}\\1\end{bmatrix}
   $$
   
   
   This direction is not yet a probability vector unless its coordinates add to one.

9. Divide the nonnegative direction by the sum of its coordinates. The normalized steady state is 
   
   $$
   \mathbf q=\begin{bmatrix}\frac{2}{9}\\\frac{1}{3}\\\frac{4}{9}\end{bmatrix}
   $$

10. From the supplied starting distribution, perform the two matrix multiplications separately: 
   
   $$
   \mathbf x_1=\begin{bmatrix}\frac{1}{2}\\\frac{1}{2}\\0\end{bmatrix},\qquad\mathbf x_2=\begin{bmatrix}\frac{5}{12}\\\frac{5}{12}\\\frac{1}{6}\end{bmatrix}
   $$

11. Check: 
   
   $$
   P\mathbf q=\begin{bmatrix}\frac{2}{9}\\\frac{1}{3}\\\frac{4}{9}\end{bmatrix}=\mathbf q,\qquad\sum q_i=1.
   $$
   
   
   All coordinates are nonnegative, which completes the probability requirement.

**What earns the points:**

- [ ] $(P-I)\mathbf q=0$ and null-space algebra.
- [ ] Nonnegative sum-to-one normalization.
- [ ] Direct $P\mathbf q=\mathbf q$ check.

::::

:::
